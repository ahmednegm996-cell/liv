import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final p = state.profile;

    return Scaffold(
      appBar: AppBar(
        title: const Text('حسابي'),
        actions: [
          IconButton(
            icon: Icon(state.isDarkMode ? Icons.light_mode : Icons.dark_mode),
            onPressed: () => state.toggleDarkMode(),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 40),
        children: [
          // Profile header
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 36,
                  backgroundColor: AppTheme.primary.withOpacity(0.15),
                  child: Text(
                    p.name.isNotEmpty ? p.name[0].toUpperCase() : 'L',
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.primary,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.name, style: Theme.of(context).textTheme.titleLarge),
                      Text(
                        'Level ${p.level}  •  ${p.points} نقطة',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Hearts & Stats
          _section(context, 'الإحصائيات', [
            _tile(Icons.favorite, 'القلوب', '${p.hearts}/3'),
            _tile(Icons.star, 'المستوى', '${p.level}'),
            _tile(Icons.emoji_events, 'النقاط', '${p.points}'),
          ]),

          // Health
          _section(context, 'الصحة', [
            ListTile(
              leading: const Icon(Icons.monitor_weight_outlined),
              title: const Text('الوزن'),
              trailing: Text(p.weight > 0 ? '${p.weight} كجم' : '—'),
              onTap: () => _editNumber(context, 'الوزن', p.weight, (v) {
                p.weight = v;
                state.notifyListeners();
                // force save via any method
                state.addPoints(0);
              }),
            ),
            ListTile(
              leading: const Icon(Icons.height),
              title: const Text('الطول'),
              trailing: Text(p.height > 0 ? '${p.height} سم' : '—'),
              onTap: () => _editNumber(context, 'الطول', p.height, (v) {
                p.height = v;
                state.addPoints(0);
              }),
            ),
            ListTile(
              leading: const Icon(Icons.bedtime),
              title: const Text('ساعات النوم'),
              trailing: Text('${p.sleepHours} ساعة'),
              onTap: () => _editSleep(context),
            ),
          ]),

          // Job
          _section(context, 'الشغل', [
            ListTile(
              leading: const Icon(Icons.work_outline),
              title: const Text('نوع الشغل'),
              trailing: Text(p.jobType ?? 'غير محدد'),
              onTap: () => _selectJob(context),
            ),
            if (p.jobType != null) ..._jobStats(context, p),
          ]),

          // Subscriptions
          _section(context, 'الاشتراكات', [
            ...state.subscriptions.map((s) => ListTile(
                  leading: const Icon(Icons.subscriptions_outlined),
                  title: Text(s.name),
                  subtitle: Text('${s.price} ج.م / شهر'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline, color: AppTheme.danger),
                    onPressed: () => state.removeSubscription(s.id),
                  ),
                )),
            ListTile(
              leading: const Icon(Icons.add),
              title: const Text('إضافة اشتراك'),
              onTap: () => _addSub(context),
            ),
          ]),

          // Settings
          _section(context, 'الإعدادات', [
            SwitchListTile(
              secondary: const Icon(Icons.language),
              title: const Text('اللغة'),
              subtitle: Text(state.locale.languageCode == 'ar' ? 'عربي' : 'English'),
              value: state.locale.languageCode == 'ar',
              onChanged: (v) {
                state.setLocale(Locale(v ? 'ar' : 'en'));
              },
            ),
            SwitchListTile(
              secondary: const Icon(Icons.dark_mode),
              title: const Text('الوضع الداكن'),
              value: state.isDarkMode,
              onChanged: (_) => state.toggleDarkMode(),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _section(BuildContext context, String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 4),
          child: Text(title, style: Theme.of(context).textTheme.titleMedium),
        ),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          decoration: BoxDecoration(
            color: Theme.of(context).cardTheme.color,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(children: children),
        ),
      ],
    );
  }

  Widget _tile(IconData icon, String title, String value) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
    );
  }

  List<Widget> _jobStats(BuildContext context, UserProfile p) {
    if (p.jobType == 'uber') {
      return [
        ListTile(
          title: const Text('رحلات النهاردة'),
          trailing: Text('${p.jobStats['rides'] ?? 0}'),
          onTap: () {
            final current = (p.jobStats['rides'] ?? 0) as int;
            context.read<AppState>().updateJobStat('rides', current + 1);
          },
        ),
        ListTile(
          title: const Text('المبلغ المجموع'),
          trailing: Text('${p.jobStats['earnings'] ?? 0} ج.م'),
        ),
      ];
    }
    if (p.jobType == 'student') {
      return [
        ListTile(
          title: const Text('ساعات المذاكرة'),
          trailing: Text('${p.jobStats['studyHours'] ?? 0}'),
          onTap: () {
            final current = (p.jobStats['studyHours'] ?? 0) as num;
            context.read<AppState>().updateJobStat('studyHours', current + 1);
          },
        ),
      ];
    }
    return [];
  }

  void _editNumber(BuildContext context, String label, double current,
      Function(double) onSave) {
    final ctrl = TextEditingController(text: current > 0 ? current.toString() : '');
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(label),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(hintText: label),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () {
              final v = double.tryParse(ctrl.text) ?? 0;
              onSave(v);
              Navigator.pop(context);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  void _editSleep(BuildContext context) {
    final state = context.read<AppState>();
    int hours = state.profile.sleepHours;
    double quality = state.profile.sleepQuality;

    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).cardTheme.color,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModal) {
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('تحديث النوم',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 20),
                  Text('الساعات: $hours'),
                  Slider(
                    value: hours.toDouble(),
                    min: 3,
                    max: 12,
                    divisions: 9,
                    label: '$hours',
                    onChanged: (v) => setModal(() => hours = v.round()),
                  ),
                  Text('الجودة: ${(quality * 100).toInt()}%'),
                  Slider(
                    value: quality,
                    min: 0,
                    max: 1,
                    divisions: 10,
                    onChanged: (v) => setModal(() => quality = v),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      state.updateSleep(hours, quality);
                      Navigator.pop(ctx);
                    },
                    child: const Text('حفظ'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _selectJob(BuildContext context) {
    final jobs = {
      'uber': 'أوبر / توصيل',
      'realestate': 'عقارات',
      'student': 'طالب',
      'freelance': 'فريلانس',
      'office': 'مكتب',
      'other': 'أخرى',
    };
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).cardTheme.color,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return ListView(
          shrinkWrap: true,
          children: jobs.entries
              .map((e) => ListTile(
                    title: Text(e.value),
                    onTap: () {
                      context.read<AppState>().setJobType(e.key);
                      Navigator.pop(ctx);
                    },
                  ))
              .toList(),
        );
      },
    );
  }

  void _addSub(BuildContext context) {
    final nameCtrl = TextEditingController();
    final priceCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('اشتراك جديد'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(hintText: 'الاسم (نتفلكس...)'),
            ),
            TextField(
              controller: priceCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(hintText: 'السعر الشهري'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () {
              if (nameCtrl.text.isEmpty) return;
              context.read<AppState>().addSubscription(Subscription(
                    name: nameCtrl.text.trim(),
                    price: double.tryParse(priceCtrl.text) ?? 0,
                    nextBilling: DateTime.now().add(const Duration(days: 30)),
                  ));
              Navigator.pop(context);
            },
            child: const Text('إضافة'),
          ),
        ],
      ),
    );
  }
}
