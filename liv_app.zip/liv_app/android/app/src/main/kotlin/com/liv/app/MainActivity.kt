package com.liv.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
