import 'package:uuid/uuid.dart';

const _uuid = Uuid();

enum TaskPriority { low, medium, high }
enum HabitType { good, bad }
enum GoalCategory { personal, career, health, finance, learning, social }

class Task {
  final String id;
  String title;
  String? description;
  bool isCompleted;
  DateTime createdAt;
  DateTime? completedAt;
  TaskPriority priority;
  int points;
  String? category; // daily, weekly, monthly

  Task({
    String? id,
    required this.title,
    this.description,
    this.isCompleted = false,
    DateTime? createdAt,
    this.completedAt,
    this.priority = TaskPriority.medium,
    this.points = 10,
    this.category = 'daily',
  })  : id = id ?? _uuid.v4(),
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'isCompleted': isCompleted,
        'createdAt': createdAt.toIso8601String(),
        'completedAt': completedAt?.toIso8601String(),
        'priority': priority.index,
        'points': points,
        'category': category,
      };

  factory Task.fromJson(Map<String, dynamic> json) => Task(
        id: json['id'],
        title: json['title'],
        description: json['description'],
        isCompleted: json['isCompleted'] ?? false,
        createdAt: DateTime.parse(json['createdAt']),
        completedAt: json['completedAt'] != null
            ? DateTime.parse(json['completedAt'])
            : null,
        priority: TaskPriority.values[json['priority'] ?? 1],
        points: json['points'] ?? 10,
        category: json['category'] ?? 'daily',
      );
}

class Habit {
  final String id;
  String title;
  HabitType type;
  int streak;
  int totalCompletions;
  DateTime createdAt;
  List<String> completedDates; // yyyy-MM-dd
  int pointsPerDay;
  bool isMonster; // العادة الوحشة الشهرية

  Habit({
    String? id,
    required this.title,
    required this.type,
    this.streak = 0,
    this.totalCompletions = 0,
    DateTime? createdAt,
    List<String>? completedDates,
    this.pointsPerDay = 15,
    this.isMonster = false,
  })  : id = id ?? _uuid.v4(),
        createdAt = createdAt ?? DateTime.now(),
        completedDates = completedDates ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'type': type.index,
        'streak': streak,
        'totalCompletions': totalCompletions,
        'createdAt': createdAt.toIso8601String(),
        'completedDates': completedDates,
        'pointsPerDay': pointsPerDay,
        'isMonster': isMonster,
      };

  factory Habit.fromJson(Map<String, dynamic> json) => Habit(
        id: json['id'],
        title: json['title'],
        type: HabitType.values[json['type'] ?? 0],
        streak: json['streak'] ?? 0,
        totalCompletions: json['totalCompletions'] ?? 0,
        createdAt: DateTime.parse(json['createdAt']),
        completedDates: List<String>.from(json['completedDates'] ?? []),
        pointsPerDay: json['pointsPerDay'] ?? 15,
        isMonster: json['isMonster'] ?? false,
      );
}

class Goal {
  final String id;
  String title;
  String? description;
  GoalCategory category;
  double progress; // 0.0 - 1.0
  DateTime? targetDate;
  DateTime createdAt;
  bool isDream;
  List<String> steps; // خطوات تحقيق الحلم بالـ AI

  Goal({
    String? id,
    required this.title,
    this.description,
    this.category = GoalCategory.personal,
    this.progress = 0.0,
    this.targetDate,
    DateTime? createdAt,
    this.isDream = false,
    List<String>? steps,
  })  : id = id ?? _uuid.v4(),
        createdAt = createdAt ?? DateTime.now(),
        steps = steps ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'category': category.index,
        'progress': progress,
        'targetDate': targetDate?.toIso8601String(),
        'createdAt': createdAt.toIso8601String(),
        'isDream': isDream,
        'steps': steps,
      };

  factory Goal.fromJson(Map<String, dynamic> json) => Goal(
        id: json['id'],
        title: json['title'],
        description: json['description'],
        category: GoalCategory.values[json['category'] ?? 0],
        progress: (json['progress'] ?? 0.0).toDouble(),
        targetDate: json['targetDate'] != null
            ? DateTime.parse(json['targetDate'])
            : null,
        createdAt: DateTime.parse(json['createdAt']),
        isDream: json['isDream'] ?? false,
        steps: List<String>.from(json['steps'] ?? []),
      );
}

class UserProfile {
  String name;
  int points;
  int hearts; // 3 قلوب يومياً
  int level;
  double weight;
  double height;
  List<String> hobbies;
  String? jobType; // uber, realestate, student, etc.
  Map<String, dynamic> jobStats;
  int sleepHours;
  double sleepQuality;
  DateTime? lastHeartReset;
  String? monthlyMonsterHabitId;

  UserProfile({
    this.name = '',
    this.points = 0,
    this.hearts = 3,
    this.level = 1,
    this.weight = 0,
    this.height = 0,
    List<String>? hobbies,
    this.jobType,
    Map<String, dynamic>? jobStats,
    this.sleepHours = 7,
    this.sleepQuality = 0.7,
    this.lastHeartReset,
    this.monthlyMonsterHabitId,
  })  : hobbies = hobbies ?? [],
        jobStats = jobStats ?? {};

  Map<String, dynamic> toJson() => {
        'name': name,
        'points': points,
        'hearts': hearts,
        'level': level,
        'weight': weight,
        'height': height,
        'hobbies': hobbies,
        'jobType': jobType,
        'jobStats': jobStats,
        'sleepHours': sleepHours,
        'sleepQuality': sleepQuality,
        'lastHeartReset': lastHeartReset?.toIso8601String(),
        'monthlyMonsterHabitId': monthlyMonsterHabitId,
      };

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        name: json['name'] ?? '',
        points: json['points'] ?? 0,
        hearts: json['hearts'] ?? 3,
        level: json['level'] ?? 1,
        weight: (json['weight'] ?? 0).toDouble(),
        height: (json['height'] ?? 0).toDouble(),
        hobbies: List<String>.from(json['hobbies'] ?? []),
        jobType: json['jobType'],
        jobStats: Map<String, dynamic>.from(json['jobStats'] ?? {}),
        sleepHours: json['sleepHours'] ?? 7,
        sleepQuality: (json['sleepQuality'] ?? 0.7).toDouble(),
        lastHeartReset: json['lastHeartReset'] != null
            ? DateTime.parse(json['lastHeartReset'])
            : null,
        monthlyMonsterHabitId: json['monthlyMonsterHabitId'],
      );
}

class Subscription {
  final String id;
  String name;
  double price;
  DateTime nextBilling;
  bool isActive;

  Subscription({
    String? id,
    required this.name,
    required this.price,
    required this.nextBilling,
    this.isActive = true,
  }) : id = id ?? _uuid.v4();

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'price': price,
        'nextBilling': nextBilling.toIso8601String(),
        'isActive': isActive,
      };

  factory Subscription.fromJson(Map<String, dynamic> json) => Subscription(
        id: json['id'],
        name: json['name'],
        price: (json['price'] ?? 0).toDouble(),
        nextBilling: DateTime.parse(json['nextBilling']),
        isActive: json['isActive'] ?? true,
      );
}
