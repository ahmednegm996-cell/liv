
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/audio_service.dart';
import '../theme/app_theme.dart';

class AIChatScreen extends StatefulWidget {
  final bool active;
  const AIChatScreen({super.key, this.active = true});
  @override
  State<AIChatScreen> createState() => _AIChatScreenState();
}

class _AIChatScreenState extends State<AIChatScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final List<Map<String, String>> _messages = [];
  bool _sending = false;
  bool _historyLoaded = false;

  @override
  void initState() {
    super.initState();
    if (widget.active) {
      AudioService.instance.playLoop('assets/audio/ai_ambient.wav');
    }
  }

  @override
  void didUpdateWidget(covariant AIChatScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.active && !oldWidget.active) {
      AudioService.instance.playLoop('assets/audio/ai_ambient.wav');
    } else if (!widget.active && oldWidget.active) {
      AudioService.instance.stop();
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_historyLoaded) return;
    _historyLoaded = true;
    final saved = context.read<AppState>().profile.chatHistory;
    if (saved.isNotEmpty) {
      _messages.addAll(saved.map((e) => Map<String, String>.from(e)));
    } else {
      _messages.add({
        'role': 'assistant',
        'text':
            'أهلًا 👋 أنا Liv. اعتبرني المساحة اللي تقدر ترتب فيها دماغك من غير حكم.\nعايز نبدأ بإيه؟'
      });
    }
  }

  @override
  void dispose() {
    AudioService.instance.stop();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _persist() async {
    final state = context.read<AppState>();
    final copy = _messages
        .map((m) => {'role': m['role'] ?? '', 'text': m['text'] ?? ''})
        .toList();
    // keep last 40
    final trimmed = copy.length > 40 ? copy.sublist(copy.length - 40) : copy;
    await state.updateProfile((p) {
      p.chatHistory = trimmed;
      return p;
    });
  }

  Future<void> _send([String? preset]) async {
    final text = (preset ?? _input.text).trim();
    if (text.isEmpty || _sending) return;
    _input.clear();
    setState(() {
      _messages.add({'role': 'user', 'text': text});
      _sending = true;
    });
    _scrollToEnd();
    await _persist();

    final state = context.read<AppState>();
    try {
      final reply = await state.ai.chat(
        userMessage: text,
        context: state.aiContext,
        history: _messages
            .map((m) => {'role': m['role']!, 'text': m['text']!})
            .toList(),
      );
      setState(() {
        _messages.add({'role': 'assistant', 'text': reply});
        _sending = false;
      });
    } catch (e) {
      setState(() {
        _messages.add({'role': 'assistant', 'text': '⚠️ $e'});
        _sending = false;
      });
    }
    await _persist();
    _scrollToEnd();
  }

  void _scrollToEnd() {
    Future.delayed(const Duration(milliseconds: 120), () {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final danger = state.profile.hearts <= 0;
    final accent = AppColors.accentFrom(state.profile.accentColor);

    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 450),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: danger
                      ? const [Color(0xFF2A0A12), Color(0xFF1A0508), Color(0xFF3B0D16)]
                      : isDark
                          ? const [Color(0xFF171A2D), Color(0xFF10131C), Color(0xFF182323)]
                          : const [Color(0xFFEFF4FF), Color(0xFFF8F5FF), Color(0xFFEFFBF8)],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _header(state, accent, danger),
                Expanded(
                  child: ListView(
                    controller: _scroll,
                    padding: const EdgeInsets.fromLTRB(18, 10, 18, 18),
                    children: [
                      _quickPrompts(),
                      ..._messages.map((m) => _bubble(m, accent)),
                      if (_sending)
                        const Padding(
                          padding: EdgeInsets.all(12),
                          child: Align(
                            alignment: Alignment.centerRight,
                            child: _Typing(),
                          ),
                        ),
                    ],
                  ),
                ),
                _composer(accent),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _header(AppState state, Color accent, bool danger) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: danger
                      ? [AppColors.danger, AppColors.dangerDark]
                      : [accent, accent.withOpacity(0.7)],
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.auto_awesome, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    danger ? 'Liv AI — وضع خطر' : 'Liv AI',
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
                  ),
                  Text(
                    state.ai.isConfigured
                        ? 'متصل • ${state.profile.aiProvider}'
                        : 'حط API Key من البروفايل',
                    style: TextStyle(fontSize: 12, color: secondaryText(context)),
                  ),
                ],
              ),
            ),
            if (_messages.length > 1)
              IconButton(
                tooltip: 'مسح الشات',
                onPressed: () async {
                  setState(() {
                    _messages
                      ..clear()
                      ..add({
                        'role': 'assistant',
                        'text': 'تم مسح المحادثة. نبدأ من جديد؟'
                      });
                  });
                  await _persist();
                },
                icon: const Icon(Icons.delete_outline),
              ),
          ],
        ),
      );

  Widget _quickPrompts() => SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.only(bottom: 12),
        child: Row(
          children: [
            for (final t in [
              'حلل يومي',
              'حفزني',
              'خطة لع عادة',
              'نصيحة نوم',
              'رتّب أولوياتي',
            ])
              Padding(
                padding: const EdgeInsets.only(left: 8),
                child: ActionChip(
                  label: Text(t),
                  onPressed: () => _send(t),
                ),
              ),
          ],
        ),
      );

  Widget _bubble(Map<String, String> m, Color accent) {
    final isUser = m['role'] == 'user';
    return Align(
      alignment: isUser ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.8,
        ),
        decoration: BoxDecoration(
          color: isUser ? accent : Theme.of(context).cardColor.withOpacity(0.9),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18),
            topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(isUser ? 4 : 18),
            bottomRight: Radius.circular(isUser ? 18 : 4),
          ),
        ),
        child: Text(
          m['text'] ?? '',
          style: TextStyle(
            color: isUser ? Colors.white : null,
            height: 1.45,
          ),
        ),
      ),
    );
  }

  Widget _composer(Color accent) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _input,
                  minLines: 1,
                  maxLines: 4,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _send(),
                  decoration: const InputDecoration(
                    hintText: 'اكتب لـ Liv...',
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () => _send(),
                child: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: accent,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(Icons.send_rounded, color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      );
}

class _Typing extends StatelessWidget {
  const _Typing();
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: const Text('بيفكر...'),
    );
  }
}
