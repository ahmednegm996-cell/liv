import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/ai_service.dart';
import '../theme/app_theme.dart';

class AiChatScreen extends StatefulWidget {
  const AiChatScreen({super.key});

  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<AiChatScreen> {
  final _controller = TextEditingController();
  final _scroll = ScrollController();
  bool _loading = false;
  final List<Map<String, String>> _messages = [];

  @override
  void initState() {
    super.initState();
    // load previous from state
    final hist = context.read<AppState>().aiChatHistory;
    for (final e in hist) {
      if (e.startsWith('user:')) {
        _messages.add({'role': 'user', 'text': e.substring(5)});
      } else if (e.startsWith('ai:')) {
        _messages.add({'role': 'ai', 'text': e.substring(3)});
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send([String? preset]) async {
    final text = (preset ?? _controller.text).trim();
    if (text.isEmpty || _loading) return;
    _controller.clear();

    setState(() {
      _messages.add({'role': 'user', 'text': text});
      _loading = true;
    });
    _scrollToEnd();

    final state = context.read<AppState>();
    final profile = state.profile;
    final system = AiService.buildSystemPrompt(
      name: profile.name.isEmpty ? 'صديق' : profile.name,
      points: profile.points,
      level: profile.level,
      hearts: profile.hearts,
      tasksDone: state.tasks.where((t) => t.isCompleted).length,
      tasksTotal: state.tasks.length,
      habitsCount: state.habits.length,
      sleepHours: profile.sleepHours,
    );

    final history = _messages
        .where((m) => m['role'] != 'ai' || m != _messages.last)
        .map((m) => {'role': m['role']!, 'text': m['text']!})
        .toList();

    final reply = await AiService.chat(
      userMessage: text,
      systemContext: system,
      history: history,
    );

    setState(() {
      _messages.add({'role': 'ai', 'text': reply});
      _loading = false;
    });

    // persist
    state.aiChatHistory.add('user:$text');
    state.aiChatHistory.add('ai:$reply');
    if (state.aiChatHistory.length > 40) {
      state.aiChatHistory =
          state.aiChatHistory.sublist(state.aiChatHistory.length - 40);
    }
    // trigger save via points noop
    state.addPoints(0);
    _scrollToEnd();
  }

  void _scrollToEnd() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final hasKey = AiService.hasKey;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 8, height: 8,
              decoration: BoxDecoration(
                color: hasKey ? AppTheme.success : AppTheme.warning,
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 8),
            const Text('مساعد liv'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.tune_rounded),
            tooltip: 'إعدادات AI',
            onPressed: () => _showAiSettings(context),
          ),
        ],
      ),
      body: Column(
        children: [
          if (!hasKey)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.purple.withOpacity(0.12),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppTheme.purple.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.key_rounded, color: AppTheme.purple, size: 20),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text(
                      'حط Gemini API Key المجاني عشان AI حقيقي',
                      style: TextStyle(fontSize: 13),
                    ),
                  ),
                  TextButton(
                    onPressed: () => _showAiSettings(context),
                    child: const Text('إعدادات'),
                  ),
                ],
              ),
            ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: [
                _chip('نقاطي كام؟'),
                _chip('حلل يومي'),
                _chip('خطة لع عادة'),
                _chip('نصيحة نوم'),
                _chip('حفيزني'),
                _chip('خطة لحلم'),
              ],
            ),
          ),
          Expanded(
            child: _messages.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 72, height: 72,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  AppTheme.purple.withOpacity(0.2),
                                  AppTheme.purpleLight.withOpacity(0.15),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(22),
                            ),
                            child: const Icon(Icons.auto_awesome_rounded,
                                size: 36, color: AppTheme.purple),
                          ),
                          const SizedBox(height: 20),
                          Text(
                            'أهلاً، أنا مساعد liv',
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            hasKey
                                ? 'اسألني أي حاجة عن يومك وأهدافك'
                                : 'حط API Key من الإعدادات عشان أرد بذكاء حقيقي',
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                    itemCount: _messages.length + (_loading ? 1 : 0),
                    itemBuilder: (context, i) {
                      if (_loading && i == _messages.length) {
                        return Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 10),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 12),
                            decoration: BoxDecoration(
                              color: isDark
                                  ? AppTheme.darkCardAlt
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SizedBox(
                                  width: 16, height: 16,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: AppTheme.purple,
                                  ),
                                ),
                                SizedBox(width: 10),
                                Text('بيفكر...', style: TextStyle(fontSize: 13)),
                              ],
                            ),
                          ),
                        );
                      }
                      final m = _messages[i];
                      final isUser = m['role'] == 'user';
                      return Align(
                        alignment: isUser
                            ? Alignment.centerRight
                            : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 12),
                          constraints: BoxConstraints(
                            maxWidth: MediaQuery.of(context).size.width * 0.78,
                          ),
                          decoration: BoxDecoration(
                            gradient: isUser
                                ? const LinearGradient(
                                    colors: [AppTheme.purple, AppTheme.purpleDark],
                                  )
                                : null,
                            color: isUser
                                ? null
                                : (isDark ? AppTheme.darkCardAlt : Colors.white),
                            borderRadius: BorderRadius.only(
                              topLeft: const Radius.circular(18),
                              topRight: const Radius.circular(18),
                              bottomLeft: Radius.circular(isUser ? 18 : 4),
                              bottomRight: Radius.circular(isUser ? 4 : 18),
                            ),
                            border: isUser
                                ? null
                                : Border.all(
                                    color: isDark
                                        ? AppTheme.darkBorder
                                        : AppTheme.lightBorder,
                                  ),
                          ),
                          child: Text(
                            m['text']!,
                            style: TextStyle(
                              color: isUser ? Colors.white : null,
                              height: 1.45,
                              fontSize: 14.5,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
            decoration: BoxDecoration(
              color: isDark ? AppTheme.darkCard : Colors.white,
              border: Border(
                top: BorderSide(
                  color: isDark ? AppTheme.darkBorder : AppTheme.lightBorder,
                  width: 0.6,
                ),
              ),
            ),
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: const InputDecoration(
                        hintText: 'اكتب رسالتك...',
                        contentPadding: EdgeInsets.symmetric(
                            horizontal: 16, vertical: 12),
                      ),
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                    ),
                  ),
                  const SizedBox(width: 10),
                  GestureDetector(
                    onTap: () => _send(),
                    child: Container(
                      width: 48, height: 48,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [AppTheme.purple, AppTheme.purpleDark],
                        ),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: const Icon(Icons.send_rounded,
                          color: Colors.white, size: 22),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: ActionChip(
        label: Text(text, style: const TextStyle(fontSize: 13)),
        onPressed: () => _send(text),
        backgroundColor: AppTheme.purple.withOpacity(0.12),
        side: BorderSide.none,
      ),
    );
  }

  void _showAiSettings(BuildContext context) {
    final keyCtrl = TextEditingController(text: AiService.apiKey);
    String provider = AiService.provider;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).cardTheme.color,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModal) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20, right: 20, top: 20,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('إعدادات الذكاء الاصطناعي',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 6),
                  Text(
                    'Gemini مجاني من Google AI Studio',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: provider,
                    decoration: const InputDecoration(labelText: 'المزوّد'),
                    items: const [
                      DropdownMenuItem(value: 'gemini', child: Text('Google Gemini (مجاني)')),
                      DropdownMenuItem(value: 'groq', child: Text('Groq (مجاني)')),
                      DropdownMenuItem(value: 'openai', child: Text('OpenAI')),
                    ],
                    onChanged: (v) => setModal(() => provider = v!),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: keyCtrl,
                    decoration: const InputDecoration(
                      labelText: 'API Key',
                      hintText: 'الصق المفتاح هنا',
                    ),
                    obscureText: true,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Gemini: aistudio.google.com → Get API key\nGroq: console.groq.com',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      AiService.apiKey = keyCtrl.text.trim();
                      AiService.provider = provider;
                      Navigator.pop(ctx);
                      setState(() {});
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('تم حفظ إعدادات AI')),
                      );
                    },
                    child: const Text('حفظ'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
