
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/audio_service.dart';
import '../theme/app_theme.dart';

class AIChatScreen extends StatefulWidget {
  final bool active;
  const AIChatScreen({super.key, this.active = true});
  @override
  State<AIChatScreen> createState() => _AIChatScreenState();
}

class _AIChatScreenState extends State<AIChatScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final List<Map<String, String>> _messages = [];
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    if (widget.active) AudioService.instance.playLoop('assets/audio/ai_ambient.wav');
    _messages.add({
      'role': 'assistant',
      'text': 'أهلًا 👋 أنا Liv. اعتبرني المساحة اللي تقدر ترتب فيها دماغك من غير حكم.\nعايز نبدأ بإيه؟'
    });
  }

  @override
  void dispose() {
    AudioService.instance.stop();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topRight, end: Alignment.bottomLeft,
                colors: Theme.of(context).brightness == Brightness.dark
                    ? const [Color(0xFF171A2D), Color(0xFF10131C), Color(0xFF182323)]
                    : const [Color(0xFFEFF4FF), Color(0xFFF8F5FF), Color(0xFFEFFBF8)],
              ),
            ),
          )),
          SafeArea(child: Column(children: [
            _header(state),
            Expanded(child: ListView(
              controller: _scroll,
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 18),
              children: [
                _quickPrompts(),
                ..._messages.map(_bubble),
                if (_sending) const Padding(
                  padding: EdgeInsets.all(12),
                  child: Align(alignment: Alignment.centerRight, child: _Typing()),
                ),
              ],
            )),
            _composer(state),
          ])),
        ],
      ),
    );
  }

  Widget _header(AppState state) => Padding(
    padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
    child: Row(children: [
      Container(width: 48, height: 48,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(colors: [AppColors.primary, AppColors.accentTeal]),
          boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(.2), blurRadius: 18)],
        ),
        child: const Icon(Icons.psychology_alt_rounded, color: Colors.white)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Liv AI', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        Text(state.profile.geminiApiKey.isEmpty ? 'حط API Key عشان نبدأ' : 'مساحتك الهادية • خصوصية أولًا',
          style: TextStyle(fontSize: 12, color: secondaryText(context))),
      ])),
      IconButton(
        tooltip: 'إيقاف/تشغيل الموسيقى',
        onPressed: () => AudioService.instance.stop(),
        icon: const Icon(Icons.music_note_rounded),
      ),
    ]),
  );

  Widget _quickPrompts() => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: Wrap(spacing: 8, runSpacing: 8, children: [
      _chip('رتب يومي'),
      _chip('أنا مشتت'),
      _chip('حاسس إني واقف مكاني'),
      _chip('عايز خطة للأسبوع'),
    ]),
  );

  Widget _chip(String text) => ActionChip(
    label: Text(text),
    avatar: const Icon(Icons.auto_awesome, size: 15),
    onPressed: () { _input.text = text; _send(); },
  );

  Widget _bubble(Map<String, String> m) {
    final mine = m['role'] == 'user';
    return Align(
      alignment: mine ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 330),
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
        decoration: BoxDecoration(
          color: mine ? AppColors.primary : Theme.of(context).cardColor.withOpacity(.86),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20), topRight: const Radius.circular(20),
            bottomLeft: Radius.circular(mine ? 20 : 5),
            bottomRight: Radius.circular(mine ? 5 : 20),
          ),
          border: mine ? null : Border.all(color: AppColors.primary.withOpacity(.08)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(.04), blurRadius: 12, offset: const Offset(0, 5))],
        ),
        child: Text(m['text'] ?? '', style: TextStyle(
          height: 1.45, color: mine ? Colors.white : strongText(context))),
      ),
    );
  }

  Widget _composer(AppState state) => Container(
    padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
    decoration: BoxDecoration(
      color: Theme.of(context).scaffoldBackgroundColor.withOpacity(.88),
      border: Border(top: BorderSide(color: Colors.black.withOpacity(.05))),
    ),
    child: Row(children: [
      Expanded(child: TextField(
        controller: _input,
        minLines: 1, maxLines: 4,
        textInputAction: TextInputAction.send,
        onSubmitted: (_) => _send(),
        decoration: const InputDecoration(hintText: 'قول لـ Liv اللي في دماغك...'),
      )),
      const SizedBox(width: 8),
      IconButton.filled(
        onPressed: _sending ? null : _send,
        icon: const Icon(Icons.arrow_upward_rounded),
      ),
    ]),
  );

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _sending) return;
    final state = context.read<AppState>();
    if (!state.ai.isConfigured) {
      setState(() => _messages.add({'role': 'assistant', 'text': 'قبل ما نتكلم، حط Gemini API Key من البروفايل. وبعدها ارجعلي هنا ✨'}));
      _input.clear();
      return;
    }
    setState(() {
      _messages.add({'role': 'user', 'text': text});
      _input.clear();
      _sending = true;
    });
    _scrollLater();
    try {
      final reply = await state.ai.chat(
        userMessage: text,
        context: state.aiContext,
        history: _messages.sublist(0, _messages.length - 1),
      );
      if (!mounted) return;
      setState(() {
        _messages.add({'role': 'assistant', 'text': reply});
        _sending = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _messages.add({'role': 'assistant', 'text': 'حصلت مشكلة وأنا بحاول أوصل لـ Gemini:\n$e'});
        _sending = false;
      });
    }
    _scrollLater();
  }

  void _scrollLater() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    });
  }
}

class _Typing extends StatefulWidget {
  const _Typing();
  @override
  State<_Typing> createState() => _TypingState();
}
class _TypingState extends State<_Typing> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: Tween(begin: .35, end: 1.0).animate(_c),
    child: const Text('Liv بيكتب…', style: TextStyle(fontSize: 12)),
  );
}
