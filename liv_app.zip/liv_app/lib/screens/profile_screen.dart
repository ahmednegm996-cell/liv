import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final p = state.profile;

    return Scaffold(
      appBar: AppBar(title: const Text('البروفايل والإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('بياناتك', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                Gaps.h12,
                _infoRow(context, 'الاسم', p.name.isEmpty ? '—' : p.name,
                    () => _editName(context)),
                _infoRow(context, 'الطول (سم)', p.heightCm?.toString() ?? '—',
                    () => _editHeight(context)),
                _infoRow(context, 'الوزن (كجم)', p.weightKg?.toString() ?? '—',
                    () => _editWeight(context)),
                _infoRow(context, 'مجال الشغل', p.jobType ?? '—',
                    () => _editJob(context)),
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('هواياتك', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    IconButton(icon: const Icon(Icons.add), onPressed: () => _addToList(context, isHobby: true)),
                  ],
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: p.hobbies
                      .map((h) => Chip(label: Text(h), onDeleted: () => _removeFromList(context, h, isHobby: true)))
                      .toList(),
                ),
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('أهدافك', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    IconButton(icon: const Icon(Icons.add), onPressed: () => _addToList(context, isHobby: false)),
                  ],
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: p.goals
                      .map((g) => Chip(label: Text(g), onDeleted: () => _removeFromList(context, g, isHobby: false)))
                      .toList(),
                ),
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('الاشتراكات الشهرية', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    TextButton.icon(
                      icon: const Icon(Icons.add, size: 18),
                      label: const Text('اشتراك'),
                      onPressed: () => _addSub(context),
                    ),
                  ],
                ),
                Gaps.h8,
                ...state.subs.map((s) => ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(s.name),
                      subtitle: Text('${s.price.toStringAsFixed(0)} جنيه / شهريًا'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => state.deleteSub(s),
                      ),
                    )),
                if (state.subs.isNotEmpty) ...[
                  const Divider(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('الإجمالي الشهري', style: TextStyle(fontWeight: FontWeight.w700)),
                      Text('${state.monthlySubsTotal.toStringAsFixed(0)} جنيه',
                          style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.primary)),
                    ],
                  ),
                ],
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('إعدادات الذكاء الاصطناعي (Gemini)',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                Gaps.h8,
                const Text(
                  'هتحتاج مفتاح Gemini API مجاني من Google AI Studio (aistudio.google.com/apikey) وتحطه هنا.',
                  style: TextStyle(fontSize: 12, color: Colors.black54),
                ),
                Gaps.h12,
                _apiKeyField(context, p),
                Gaps.h12,
                _infoRow(context, 'الموديل المستخدم', p.geminiModel, () => _editModel(context)),
              ],
            ),
          ),
          Gaps.h24,
        ],
      ),
    );
  }

  Widget _infoRow(BuildContext context, String label, String value, VoidCallback onEdit) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: Colors.black54))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          IconButton(
            icon: const Icon(Icons.edit_outlined, size: 18),
            onPressed: onEdit,
          ),
        ],
      ),
    );
  }

  Widget _apiKeyField(BuildContext context, UserProfile p) {
    final controller = TextEditingController(text: p.geminiApiKey);
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: controller,
            obscureText: true,
            decoration: const InputDecoration(hintText: 'الصق مفتاح Gemini API هنا'),
          ),
        ),
        Gaps.w8,
        ElevatedButton(
          onPressed: () {
            context.read<AppState>().updateProfile((p) {
              p.geminiApiKey = controller.text.trim();
              return p;
            });
            ScaffoldMessenger.of(context)
                .showSnackBar(const SnackBar(content: Text('تم حفظ المفتاح')));
          },
          child: const Text('حفظ'),
        ),
      ],
    );
  }

  void _editName(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'اسمك', initial: context.read<AppState>().profile.name);
    if (v != null && context.mounted) {
      context.read<AppState>().updateProfile((p) { p.name = v; return p; });
    }
  }

  void _editHeight(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'طولك بالسم', hint: 'مثلا 175');
    final parsed = double.tryParse((v ?? '').replaceAll(',', '.'));
    if (parsed != null && context.mounted) {
      context.read<AppState>().updateProfile((p) { p.heightCm = parsed; return p; });
    }
  }

  void _editWeight(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'وزنك بالكيلو', hint: 'مثلا 75');
    final parsed = double.tryParse((v ?? '').replaceAll(',', '.'));
    if (parsed != null && context.mounted) {
      context.read<AppState>().updateProfile((p) { p.weightKg = parsed; return p; });
    }
  }

  void _editJob(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'مجال شغلك', hint: 'مثلا أوبر / عقارات / موظف');
    if (v != null && context.mounted) {
      context.read<AppState>().updateProfile((p) { p.jobType = v; return p; });
    }
  }

  void _editModel(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'اسم الموديل', hint: 'gemini-2.0-flash', initial: context.read<AppState>().profile.geminiModel);
    if (v != null && v.isNotEmpty && context.mounted) {
      context.read<AppState>().updateProfile((p) { p.geminiModel = v; return p; });
    }
  }

  void _addToList(BuildContext context, {required bool isHobby}) async {
    final v = await showTextInputDialog(context, title: isHobby ? 'هواية جديدة' : 'هدف جديد');
    if (v != null && v.isNotEmpty && context.mounted) {
      context.read<AppState>().updateProfile((p) {
        if (isHobby) {
          p.hobbies.add(v);
        } else {
          p.goals.add(v);
        }
        return p;
      });
    }
  }

  void _removeFromList(BuildContext context, String value, {required bool isHobby}) {
    context.read<AppState>().updateProfile((p) {
      if (isHobby) {
        p.hobbies.remove(value);
      } else {
        p.goals.remove(value);
      }
      return p;
    });
  }

  void _addSub(BuildContext context) async {
    final nameController = TextEditingController();
    final priceController = TextEditingController();
    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('اشتراك جديد'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: nameController, decoration: const InputDecoration(hintText: 'مثلا Netflix')),
            Gaps.h12,
            TextField(
              controller: priceController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(hintText: 'السعر الشهري بالجنيه'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, {
              'name': nameController.text.trim(),
              'price': priceController.text.trim(),
            }),
            child: const Text('إضافة'),
          ),
        ],
      ),
    );
    if (result != null && (result['name'] ?? '').isNotEmpty) {
      final price = double.tryParse((result['price'] ?? '0').replaceAll(',', '.')) ?? 0;
      if (context.mounted) {
        context.read<AppState>().addSub(result['name']!, price, 1);
      }
    }
  }
}
