import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:percent_indicator/percent_indicator.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import '../models/models.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final profile = state.profile;
    final progress = state.todayProgress;

    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _greeting(),
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: AppTheme.lightMuted,
                                ),
                          ),
                          Text(
                            profile.name.isEmpty ? 'صديق' : profile.name,
                            style: Theme.of(context).textTheme.headlineMedium,
                          ),
                        ],
                      ),
                    ),
                    // Hearts
                    Row(
                      children: List.generate(3, (i) {
                        return Padding(
                          padding: const EdgeInsets.only(left: 4),
                          child: Icon(
                            i < profile.hearts
                                ? Icons.favorite_rounded
                                : Icons.favorite_border_rounded,
                            color: AppTheme.danger,
                            size: 22,
                          ),
                        );
                      }),
                    ),
                  ],
                ),
              ),
            ),

            // Points & Level Card
            SliverToBoxAdapter(
              child: _Card(
                child: Row(
                  children: [
                    CircularPercentIndicator(
                      radius: 42,
                      lineWidth: 7,
                      percent: progress.clamp(0.0, 1.0),
                      center: Text(
                        '${(progress * 100).toInt()}%',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      progressColor: AppTheme.purple,
                      backgroundColor: AppTheme.lightBorder.withOpacity(0.3),
                      circularStrokeCap: CircularStrokeCap.round,
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'تقدم اليوم',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${profile.points} نقطة  •  Level ${profile.level}',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          const SizedBox(height: 8),
                          LinearProgressIndicator(
                            value: (profile.points % 500) / 500,
                            backgroundColor: AppTheme.lightBorder.withOpacity(0.3),
                            color: AppTheme.success,
                            borderRadius: BorderRadius.circular(4),
                            minHeight: 6,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Daily Challenge
            if (state.dailyChallenge != null)
              SliverToBoxAdapter(
                child: _Card(
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: AppTheme.warning.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.bolt_rounded,
                            color: AppTheme.warning),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'تحدي اليوم',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                            Text(
                              state.dailyChallenge!,
                              style: Theme.of(context).textTheme.titleMedium,
                            ),
                          ],
                        ),
                      ),
                      TextButton(
                        onPressed: () => state.completeDailyChallenge(),
                        child: const Text('خلصت'),
                      ),
                    ],
                  ),
                ),
              ),

            // Quick Stats
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    Expanded(
                      child: _MiniStat(
                        icon: Icons.check_circle_rounded,
                        label: 'مهام',
                        value:
                            '${state.tasks.where((t) => t.isCompleted).length}/${state.tasks.length}',
                        color: AppTheme.success,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _MiniStat(
                        icon: Icons.loop_rounded,
                        label: 'عادات',
                        value: '${state.habits.length}',
                        color: AppTheme.purpleLight,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _MiniStat(
                        icon: Icons.bedtime_rounded,
                        label: 'النوم',
                        value: '${profile.sleepHours}س',
                        color: AppTheme.purple,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Monster of the month
            if (state.habits.any((h) => h.isMonster))
              SliverToBoxAdapter(
                child: _Card(
                  child: Row(
                    children: [
                      const Text('👹', style: TextStyle(fontSize: 32)),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'وحش الشهر',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                            Text(
                              state.habits.firstWhere((h) => h.isMonster).title,
                              style: Theme.of(context).textTheme.titleMedium,
                            ),
                            Text(
                              'بطلها الشهر ده وخد نقاط كتير!',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            // Today's tasks preview
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                child: Text(
                  'مهام اليوم',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ),
            ),
            if (state.tasks.where((t) => t.category == 'daily').isEmpty)
              const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(
                    child: Text(
                      'مفيش مهام النهاردة ✨\nضيف مهام من تبويب المهام',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppTheme.lightMuted),
                    ),
                  ),
                ),
              )
            else
              SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, i) {
                    final daily = state.tasks
                        .where((t) => t.category == 'daily')
                        .toList();
                    if (i >= daily.length || i >= 5) return null;
                    final task = daily[i];
                    return _TaskTile(task: task);
                  },
                  childCount: 5,
                ),
              ),

            const SliverToBoxAdapter(child: SizedBox(height: 100)),
          ],
        ),
      ),
    );
  }

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 12) return 'صباح الخير ☀️';
    if (h < 17) return 'مساء الخير 🌤';
    return 'مساء الخير 🌙';
  }
}

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(16),
      ),
      child: child,
    );
  }
}

class _MiniStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _MiniStat({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          Text(label, style: const TextStyle(fontSize: 11, color: AppTheme.lightMuted)),
        ],
      ),
    );
  }
}

class _TaskTile extends StatelessWidget {
  final Task task;
  const _TaskTile({required this.task});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => state.toggleTask(task.id),
            child: Icon(
              task.isCompleted
                  ? Icons.check_circle_rounded
                  : Icons.circle_outlined,
              color: task.isCompleted ? AppTheme.success : AppTheme.lightMuted,
              size: 26,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              task.title,
              style: TextStyle(
                fontSize: 15,
                decoration:
                    task.isCompleted ? TextDecoration.lineThrough : null,
                color: task.isCompleted
                    ? AppTheme.lightMuted
                    : null,
              ),
            ),
          ),
          Text(
            '+${task.points}',
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppTheme.purple,
            ),
          ),
        ],
      ),
    );
  }
}
