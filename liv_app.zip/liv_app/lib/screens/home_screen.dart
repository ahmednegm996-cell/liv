import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final goodHabits = state.habits.where((h) => h.isGood).toList();
    final weekTasks = state.thisWeekTasks;
    final doneWeekTasks = weekTasks.where((t) => t.isDone).length;

    return Scaffold(
      appBar: AppBar(
        title: Text(state.profile.name.isEmpty
            ? 'أهلاً بيك في Liv'
            : 'أهلاً، ${state.profile.name}'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(left: 16),
            child: Center(child: PointsChip(points: state.profile.totalPoints)),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SectionCard(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('قلوبك النهاردة',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                HeartsRow(hearts: state.profile.hearts),
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    Icon(Icons.bolt_rounded, color: AppColors.accentOrange),
                    Gaps.w8,
                    Text('تحدي اليوم',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  ],
                ),
                Gaps.h8,
                Text(state.dailyChallenge, style: const TextStyle(fontSize: 15)),
              ],
            ),
          ),
          Gaps.h16,
          Text('عاداتك الكويسة النهاردة',
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w700)),
          Gaps.h8,
          if (goodHabits.isEmpty)
            const SectionCard(child: Text('ضيف عادات كويسة من تبويب "العادات"'))
          else
            ...goodHabits.map((h) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: SectionCard(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(
                      children: [
                        Checkbox(
                          value: h.doneToday,
                          activeColor: AppColors.primary,
                          onChanged: h.doneToday
                              ? null
                              : (_) => context.read<AppState>().markHabitToday(h),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(h.name,
                                  style: const TextStyle(fontWeight: FontWeight.w600)),
                              Text('استمرار: ${h.currentStreak} يوم',
                                  style: const TextStyle(
                                      fontSize: 12, color: Colors.black54)),
                            ],
                          ),
                        ),
                        Text('+${h.pointsValue}',
                            style: const TextStyle(
                                color: AppColors.accentTeal,
                                fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                )),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('مهام الأسبوع',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    Row(
                      children: [
                        Text('$doneWeekTasks/${weekTasks.length}'),
                        IconButton(
                          icon: const Icon(Icons.add_circle_outline, size: 20),
                          onPressed: () => _addWeeklyTask(context),
                        ),
                      ],
                    ),
                  ],
                ),
                Gaps.h8,
                if (weekTasks.isEmpty)
                  const Text('مفيش مهام أسبوعية لسه',
                      style: TextStyle(color: Colors.black54))
                else
                  ...weekTasks.map((t) => CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        controlAffinity: ListTileControlAffinity.leading,
                        value: t.isDone,
                        activeColor: AppColors.primary,
                        title: Text(t.title),
                        onChanged: (_) => context.read<AppState>().toggleWeeklyTask(t),
                      )),
              ],
            ),
          ),
          Gaps.h16,
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.smart_toy_outlined),
              label: const Text('ميتنج أسبوعي مع الـ AI'),
              onPressed: () => _openWeeklyMeeting(context),
            ),
          ),
          Gaps.h24,
        ],
      ),
    );
  }

  void _addWeeklyTask(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'مهمة أسبوعية جديدة');
    if (v != null && v.isNotEmpty && context.mounted) {
      context.read<AppState>().addWeeklyTask(v);
    }
  }

  void _openWeeklyMeeting(BuildContext context) async {
    final state = context.read<AppState>();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    String result;
    try {
      result = await state.runWeeklyMeeting();
    } catch (e) {
      result = 'حصل خطأ: $e';
    }
    if (!context.mounted) return;
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('ميتنج الأسبوع مع Liv AI'),
        content: SingleChildScrollView(child: Text(result)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('تمام')),
        ],
      ),
    );
  }
}
