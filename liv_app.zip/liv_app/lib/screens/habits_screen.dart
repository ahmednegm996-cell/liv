import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';

class HabitsScreen extends StatelessWidget {
  const HabitsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final good = state.habits.where((h) => h.type == HabitType.good).toList();
    final bad = state.habits.where((h) => h.type == HabitType.bad).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('العادات')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddHabit(context),
        backgroundColor: AppTheme.purple,
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 100),
        children: [
          if (good.isNotEmpty) ...[
            _sectionTitle(context, 'عادات كويسة 🌱'),
            ...good.map((h) => _HabitCard(habit: h)),
          ],
          if (bad.isNotEmpty) ...[
            _sectionTitle(context, 'عادات وحشة ⚠️'),
            ...bad.map((h) => _HabitCard(habit: h)),
          ],
          if (state.habits.isEmpty)
            const Padding(
              padding: EdgeInsets.all(40),
              child: Center(
                child: Text(
                  'مفيش عادات لسه\nضيف عادة كويسة أو وحشة',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppTheme.lightMuted),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _sectionTitle(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
      child: Text(title, style: Theme.of(context).textTheme.titleLarge),
    );
  }

  void _showAddHabit(BuildContext context) {
    final titleCtrl = TextEditingController();
    HabitType type = HabitType.good;
    final pointsCtrl = TextEditingController(text: '15');

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).cardTheme.color,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModal) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('عادة جديدة',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 16),
                  TextField(
                    controller: titleCtrl,
                    decoration: const InputDecoration(hintText: 'اسم العادة'),
                    autofocus: true,
                  ),
                  const SizedBox(height: 12),
                  SegmentedButton<HabitType>(
                    segments: const [
                      ButtonSegment(
                          value: HabitType.good, label: Text('كويسة')),
                      ButtonSegment(
                          value: HabitType.bad, label: Text('وحشة')),
                    ],
                    selected: {type},
                    onSelectionChanged: (s) =>
                        setModal(() => type = s.first),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: pointsCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                        hintText: 'نقاط في اليوم'),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      if (titleCtrl.text.trim().isEmpty) return;
                      context.read<AppState>().addHabit(Habit(
                            title: titleCtrl.text.trim(),
                            type: type,
                            pointsPerDay:
                                int.tryParse(pointsCtrl.text) ?? 15,
                          ));
                      Navigator.pop(ctx);
                    },
                    child: const Text('إضافة'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _HabitCard extends StatelessWidget {
  final Habit habit;
  const _HabitCard({required this.habit});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    final today = DateTime.now().toIso8601String().substring(0, 10);
    final doneToday = habit.completedDates.contains(today);
    final isBad = habit.type == HabitType.bad;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(16),
        border: habit.isMonster
            ? Border.all(color: AppTheme.danger, width: 1.5)
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (habit.isMonster)
                const Padding(
                  padding: EdgeInsets.only(left: 8),
                  child: Text('👹', style: TextStyle(fontSize: 20)),
                ),
              Expanded(
                child: Text(
                  habit.title,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              if (!doneToday)
                IconButton(
                  onPressed: () => state.completeHabit(habit.id),
                  icon: Icon(
                    isBad ? Icons.remove_circle_outline : Icons.add_circle_outline,
                    color: isBad ? AppTheme.danger : AppTheme.success,
                  ),
                )
              else
                const Icon(Icons.check_circle, color: AppTheme.success),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _chip('🔥 ${habit.streak} يوم'),
              const SizedBox(width: 8),
              _chip('${habit.totalCompletions} مرة'),
              const SizedBox(width: 8),
              _chip(isBad ? '-${habit.pointsPerDay}' : '+${habit.pointsPerDay}'),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              TextButton(
                onPressed: () {
                  final msg = state.getHabitProjection(habit, 30);
                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('تحليل 30 يوم'),
                      content: Text(msg),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('حسناً'),
                        ),
                      ],
                    ),
                  );
                },
                child: const Text('تحليل مستقبلي'),
              ),
              if (isBad && !habit.isMonster)
                TextButton(
                  onPressed: () => state.setMonthlyMonster(habit.id),
                  child: const Text('اجعله وحش الشهر'),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _chip(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: AppTheme.lightBg,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(text, style: const TextStyle(fontSize: 12)),
    );
  }
}
