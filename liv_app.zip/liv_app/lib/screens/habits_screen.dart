import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class HabitsScreen extends StatelessWidget {
  const HabitsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final good = state.habits.where((h) => h.isGood).toList();
    final bad = state.habits.where((h) => !h.isGood).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('العادات')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addHabitDialog(context),
        icon: const Icon(Icons.add),
        label: const Text('عادة جديدة'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (state.monsterOfMonth != null) ...[
            SectionCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: const [
                      Icon(Icons.local_fire_department, color: Colors.deepOrange),
                      Gaps.w8,
                      Text('وحش الشهر ده',
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    ],
                  ),
                  Gaps.h8,
                  Text(
                      'بتحاول تتخلص من: "${state.monsterOfMonth!.name}" - كل يوم من غيرها = نقط إضافية!'),
                ],
              ),
            ),
            Gaps.h16,
          ],
          Text('عادات كويسة',
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w700)),
          Gaps.h8,
          if (good.isEmpty) const Text('لسه معملتش عادات كويسة', style: TextStyle(color: secondaryText(context))),
          ...good.map((h) => _habitTile(context, h)),
          Gaps.h24,
          Text('عادات وحشة',
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w700)),
          Gaps.h8,
          if (bad.isEmpty) const Text('لسه معملتش عادات وحشة', style: TextStyle(color: secondaryText(context))),
          ...bad.map((h) => _habitTile(context, h)),
          Gaps.h24,
        ],
      ),
    );
  }

  Widget _habitTile(BuildContext context, Habit h) {
    final state = context.read<AppState>();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SectionCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(h.name,
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                ),
                if (!h.isGood)
                  IconButton(
                    tooltip: 'اختارها وحش الشهر',
                    icon: Icon(Icons.local_fire_department,
                        color: h.isMonsterOfMonth ? Colors.deepOrange : subtleIcon(context)),
                    onPressed: () => state.chooseMonsterOfMonth(h),
                  ),
                IconButton(
                  icon: Icon(Icons.delete_outline, color: mutedText(context)),
                  onPressed: () => state.deleteHabit(h),
                ),
              ],
            ),
            Text('استمرار: ${h.currentStreak} يوم • ${h.isGood ? "+" : "-"}${h.pointsValue} نقطة',
                style: TextStyle(fontSize: 12, color: secondaryText(context))),
            if (h.aiAnalysis != null) ...[
              Gaps.h8,
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(h.aiAnalysis!, style: const TextStyle(fontSize: 13)),
              ),
            ],
            Gaps.h12,
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.psychology_outlined, size: 18),
                    label: const Text('تحليل AI'),
                    onPressed: () => _analyzeWithAI(context, h),
                  ),
                ),
                Gaps.w12,
                Expanded(
                  child: ElevatedButton(
                    onPressed: h.doneToday ? null : () => state.markHabitToday(h),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: h.isGood ? AppColors.accentTeal : AppColors.heartRed),
                    child: Text(h.doneToday
                        ? 'اتسجلت النهاردة'
                        : (h.isGood ? 'عملتها النهاردة' : 'للأسف عملتها')),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _analyzeWithAI(BuildContext context, Habit h) async {
    final state = context.read<AppState>();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    try {
      await state.analyzeHabitWithAI(h);
    } catch (e) {
      if (context.mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('خطأ: $e')));
        return;
      }
    }
    if (context.mounted) Navigator.pop(context);
  }

  void _addHabitDialog(BuildContext context) async {
    final nameController = TextEditingController();
    bool isGood = true;
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: const Text('عادة جديدة'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                autofocus: true,
                decoration: const InputDecoration(hintText: 'اسم العادة'),
              ),
              Gaps.h16,
              Row(
                children: [
                  Expanded(
                    child: ChoiceChip(
                      label: const Text('كويسة'),
                      selected: isGood,
                      onSelected: (_) => setState(() => isGood = true),
                    ),
                  ),
                  Gaps.w12,
                  Expanded(
                    child: ChoiceChip(
                      label: const Text('وحشة'),
                      selected: !isGood,
                      onSelected: (_) => setState(() => isGood = false),
                    ),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, {
                'name': nameController.text.trim(),
                'isGood': isGood,
              }),
              child: const Text('إضافة'),
            ),
          ],
        ),
      ),
    );
    if (result != null && (result['name'] as String).isNotEmpty) {
      if (context.mounted) {
        context.read<AppState>().addHabit(result['name'], result['isGood']);
      }
    }
  }
}
