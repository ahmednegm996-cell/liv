
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/audio_service.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _page = PageController();
  final _api = TextEditingController();
  final Map<String, TextEditingController> _answers = {};
  int _step = 0;
  bool _loading = false;

  final _questions = const [
    ['اسمك', 'إحنا هنناديك بإيه؟', 'مثال: أحمد'],
    ['السن', 'عندك كام سنة؟', 'مثال: 25'],
    ['الشغل/الدراسة', 'بتشتغل أو بتدرس إيه؟', 'مثال: عقارات / جامعة / فريلانسر'],
    ['روتينك اليومي', 'احكي يومك العادي من أول ما بتصحى لحد ما تنام.', 'مثال: بصحى 10، شغل، برجع 7، بقعد على الموبايل...'],
    ['النوم', 'بتنام وتصحى إمتى تقريبًا؟ وكم ساعة؟', 'مثال: بنام 2 وبصحى 10'],
    ['الحركة والرياضة', 'بتتحرك أو بتتمرن قد إيه؟ وإيه الرياضة اللي نفسك تجربها؟', 'مثال: مش بتمرن وعايز أبدأ جيم'],
    ['الصحة', 'إيه أهم حاجة صحية عايز تحسنها؟', 'مثال: الوزن، الأكل، النوم، الطاقة'],
    ['الفلوس', 'إيه هدفك المالي؟ وإيه أكتر حاجة بتصرف فيها زيادة؟', 'مثال: أوفر 5000 جنيه وأقلل المصاريف'],
    ['التعلم', 'إيه مهارة نفسك تتعلمها أو تطورها؟', 'مثال: إنجليزي، برمجة، تسويق'],
    ['عادات عايز تثبتها', 'اكتب عادات كويسة نفسك تعملها باستمرار، وافصل بينهم بفاصلة.', 'مثال: القراءة، المشي، الصلاة، المذاكرة'],
    ['حاجات عايز تقللها', 'إيه أكتر حاجات بتعطلك أو بتضيع وقتك؟', 'مثال: سكرول، سهر، تأجيل'],
    ['الاجتماعيات', 'عايز تدي وقت قد إيه لأصحابك/الخروج/العيلة؟', 'مثال: خروجة واحدة في الأسبوع'],
    ['الحلم الأكبر', 'لو بعد سنة حياتك اتحسنت جدًا، إيه أهم حاجة تكون حققتها؟', 'مثال: بدأت مشروعي أو سافرت أو غيرت شغلي'],
    ['أولوياتك', 'رتّب أهم 3 حاجات عندك دلوقتي.', 'مثال: فلوس، صحة، شغل'],
    ['أصعب حاجة', 'إيه أكتر حاجة بتحس إنها مانعاك من التقدم؟', 'مثال: الكسل، التشتت، قلة الوقت'],
    ['الوقت المتاح', 'كام دقيقة تقريبًا تقدر تدي لنفسك كل يوم؟', 'مثال: 30 دقيقة'],
  ];

  @override
  void initState() {
    super.initState();
    for (final q in _questions) _answers[q[0]] = TextEditingController();
    AudioService.instance.playLoop('assets/audio/welcome_ambient.wav');
  }

  @override
  void dispose() {
    AudioService.instance.stop();
    _page.dispose();
    _api.dispose();
    for (final c in _answers.values) c.dispose();
    super.dispose();
  }

  int get total => _questions.length + 3;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: Theme.of(context).brightness == Brightness.dark
                      ? const [Color(0xFF17132B), Color(0xFF101016)]
                      : const [Color(0xFFF2F0FF), Color(0xFFF8F9FC)],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(22, 14, 22, 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: ProgressBarWithLabel(
                          progress: (_step + 1) / total,
                          label: 'بنبني نسختك من Liv • ${_step + 1}/$total',
                        ),
                      ),
                      const SizedBox(width: 10),
                      IconButton(
                        onPressed: _step == 0 ? null : _back,
                        icon: const Icon(Icons.arrow_forward_rounded),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: PageView(
                    controller: _page,
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      _welcome(),
                      _apiStep(),
                      ..._questions.map((q) => _question(q[0], q[1], q[2])),
                      _finish(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _shell({required Widget child}) => Padding(
    padding: const EdgeInsets.fromLTRB(22, 8, 22, 22),
    child: Center(child: SingleChildScrollView(child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 560),
      child: child,
    ))),
  );

  Widget _welcome() => _shell(child: Column(
    children: [
      Container(
        width: 94, height: 94,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [AppColors.primary, AppColors.accentTeal]),
          borderRadius: BorderRadius.circular(30),
          boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(.25), blurRadius: 28, offset: const Offset(0, 12))],
        ),
        child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 48),
      ),
      Gaps.h24,
      const Text('أهلاً بيك في Liv', textAlign: TextAlign.center,
        style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
      Gaps.h12,
      Text('مش هنقولك “غيّر حياتك” وخلاص 😅\nهنفهم حياتك الأول، وبعدها نبني لك بداية واقعية.',
        textAlign: TextAlign.center, style: TextStyle(fontSize: 16, height: 1.5, color: secondaryText(context))),
      Gaps.h24,
      SectionCard(child: Column(children: const [
        ListTile(leading: Icon(Icons.psychology_alt_outlined), title: Text('AI يفهم نمط حياتك'), subtitle: Text('مش مجرد شات… هيستخدم إجاباتك في التخطيط.')),
        ListTile(leading: Icon(Icons.check_circle_outline), title: Text('مهام وعادات تلقائية'), subtitle: Text('هنبدأك بحاجات صغيرة تقدر تعملها فعلًا.')),
        ListTile(leading: Icon(Icons.insights_outlined), title: Text('تطورك قدام عينك'), subtitle: Text('نقط، قلوب، أحلام، عادات وإحصائيات.')),
      ])),
      Gaps.h24,
      SizedBox(width: double.infinity, child: ElevatedButton.icon(
        onPressed: _next, icon: const Icon(Icons.arrow_back_rounded), label: const Text('يلا نبدأ'),
      )),
    ],
  ));

  Widget _apiStep() => _shell(child: Column(
    children: [
      const Icon(Icons.key_rounded, size: 56, color: AppColors.primary),
      Gaps.h16,
      const Text('خلّي Liv أذكى', textAlign: TextAlign.center,
        style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
      Gaps.h8,
      Text('حط Gemini API Key عشان نولّد لك خطة مخصصة ونتكلم مع Liv AI. تقدر تكمله بعدين من البروفايل.',
        textAlign: TextAlign.center, style: TextStyle(color: secondaryText(context))),
      Gaps.h20,
      SectionCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('Gemini API Key', style: TextStyle(fontWeight: FontWeight.w800)),
        Gaps.h8,
        TextField(controller: _api, obscureText: true,
          decoration: const InputDecoration(prefixIcon: Icon(Icons.lock_outline), hintText: 'الصق المفتاح هنا')),
        Gaps.h8,
        Text('لو ظهر “مشكلة اتصال” بعد البناء، الإصدار ده فيه إصلاحات للإنترنت والموديل.',
          style: TextStyle(fontSize: 12, color: secondaryText(context))),
      ])),
      Gaps.h20,
      SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _next, child: const Text('التالي'))),
      TextButton(onPressed: _next, child: const Text('هحطه بعدين')),
    ],
  ));

  Widget _question(String key, String title, String hint) => _shell(child: Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Text('${_step - 1}', style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800)),
      Gaps.h8,
      Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      Gaps.h10,
      Text('كل ما تقول تفاصيل أكتر، Liv هيفهمك أحسن.', textAlign: TextAlign.center,
        style: TextStyle(color: secondaryText(context))),
      Gaps.h24,
      SectionCard(child: TextField(
        controller: _answers[key],
        autofocus: true,
        maxLines: 5,
        textInputAction: TextInputAction.next,
        decoration: InputDecoration(hintText: hint, alignLabelWithHint: true),
      )),
      Gaps.h18,
      SizedBox(width: double.infinity, child: ElevatedButton.icon(
        onPressed: _next, icon: const Icon(Icons.arrow_back_rounded), label: const Text('تمام، التالي'),
      )),
      if (_answers[key]!.text.isEmpty)
        Center(child: TextButton(onPressed: _next, child: const Text('تخطي السؤال'))),
    ],
  ));

  Widget _finish() => _shell(child: Column(
    children: [
      const Icon(Icons.rocket_launch_rounded, size: 64, color: AppColors.primary),
      Gaps.h16,
      const Text('جاهز؟ Liv هيشتغل على إجاباتك دلوقتي.',
        textAlign: TextAlign.center, style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      Gaps.h10,
      Text('هيحاول يطلع لك عادات + مهام أسبوعية + أول خطوة لحلمك. ولو الـ AI مش متاح، التطبيق مش هيقف.',
        textAlign: TextAlign.center, style: TextStyle(color: secondaryText(context))),
      Gaps.h24,
      if (_loading) const CircularProgressIndicator()
      else SizedBox(width: double.infinity, child: ElevatedButton.icon(
        onPressed: _finishSetup, icon: const Icon(Icons.auto_awesome), label: const Text('ابني لي البداية'),
      )),
    ],
  ));

  void _next() {
    if (_step >= total - 1) return;
    setState(() => _step++);
    _page.nextPage(duration: const Duration(milliseconds: 280), curve: Curves.easeOutCubic);
  }

  void _back() {
    if (_step <= 0) return;
    setState(() => _step--);
    _page.previousPage(duration: const Duration(milliseconds: 280), curve: Curves.easeOutCubic);
  }

  Future<void> _finishSetup() async {
    setState(() => _loading = true);
    final state = context.read<AppState>();
    final name = (_answers['اسمك']?.text.trim().isNotEmpty ?? false)
        ? _answers['اسمك']!.text.trim() : 'صديقي';
    final answers = <String, String>{
      for (final e in _answers.entries) e.key: e.value.text.trim(),
    };
    answers.removeWhere((_, v) => v.isEmpty);

    await state.updateProfile((p) {
      p.name = name;
      p.jobType = answers['الشغل/الدراسة'];
      p.geminiApiKey = _api.text.trim();
      p.goals = [
        if ((answers['الحلم الأكبر'] ?? '').isNotEmpty) answers['الحلم الأكبر']!,
        if ((answers['أولوياتك'] ?? '').isNotEmpty) answers['أولوياتك']!,
      ];
      return p;
    });

    await state.buildStarterPlan(answers);
    await state.completeOnboarding(name);
    if (mounted) setState(() => _loading = false);
  }
}
