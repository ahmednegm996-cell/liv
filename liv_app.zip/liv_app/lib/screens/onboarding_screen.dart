import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _nameController = TextEditingController();
  final _pageController = PageController();
  int _page = 0;

  final _pages = [
    {
      'title': 'مرحباً بك في liv',
      'subtitle': 'رفيقك الذكي لإدارة حياتك وتحقيق أهدافك',
      'icon': Icons.auto_awesome_rounded,
    },
    {
      'title': 'نقاط وقلوب',
      'subtitle': 'اكسب نقاط لما تخلص مهامك، وخلي بالك من الـ 3 قلوب اليومية',
      'icon': Icons.favorite_rounded,
    },
    {
      'title': 'عادات وأحلام',
      'subtitle': 'تابع عاداتك، اضرب الوحش الشهري، وحقق أحلامك خطوة بخطوة مع الـ AI',
      'icon': Icons.flag_rounded,
    },
    {
      'title': 'يلا نبدأ',
      'subtitle': 'قولنا اسمك عشان نخصص تجربتك',
      'icon': Icons.person_rounded,
    },
  ];

  @override
  void dispose() {
    _nameController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                onPageChanged: (i) => setState(() => _page = i),
                itemCount: _pages.length,
                itemBuilder: (context, i) {
                  final p = _pages[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            color: AppTheme.purple.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(28),
                          ),
                          child: Icon(
                            p['icon'] as IconData,
                            size: 48,
                            color: AppTheme.purple,
                          ),
                        ),
                        const SizedBox(height: 40),
                        Text(
                          p['title'] as String,
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.headlineMedium,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          p['subtitle'] as String,
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                color: AppTheme.lightMuted,
                              ),
                        ),
                        if (i == 3) ...[
                          const SizedBox(height: 40),
                          TextField(
                            controller: _nameController,
                            textAlign: TextAlign.center,
                            decoration: const InputDecoration(
                              hintText: 'اسمك',
                            ),
                            style: const TextStyle(fontSize: 20),
                          ),
                        ],
                      ],
                    ),
                  );
                },
              ),
            ),
            // Dots
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                _pages.length,
                (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: _page == i ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _page == i ? AppTheme.purple : AppTheme.lightBorder,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 32),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    if (_page < _pages.length - 1) {
                      _pageController.nextPage(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeInOut,
                      );
                    } else {
                      final name = _nameController.text.trim();
                      if (name.isEmpty) return;
                      context.read<AppState>().completeOnboarding(name);
                    }
                  },
                  child: Text(
                    _page < _pages.length - 1 ? 'التالي' : 'ابدأ الآن',
                  ),
                ),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
