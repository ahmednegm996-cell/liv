import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _nameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.self_improvement_rounded,
                  size: 72, color: AppColors.primary),
              Gaps.h24,
              const Text(
                'أهلاً بيك في Liv',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
              ),
              Gaps.h12,
              const Text(
                'رفيقك اليومي لإدارة وقتك وعاداتك وأحلامك، بمساعدة الذكاء الاصطناعي.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 15, color: Colors.black54),
              ),
              Gaps.h24,
              SectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('إيه اسمك؟',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    Gaps.h12,
                    TextField(
                      controller: _nameController,
                      autofocus: true,
                      decoration: const InputDecoration(hintText: 'اكتب اسمك هنا'),
                    ),
                  ],
                ),
              ),
              Gaps.h24,
              ElevatedButton(
                onPressed: _submit,
                child: const Text('يلا نبدأ'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _submit() {
    final name = _nameController.text.trim();
    context.read<AppState>().completeOnboarding(name.isEmpty ? 'صديقي' : name);
  }
}
