import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _pageController = PageController();
  int _step = 0;
  bool _submitting = false;
  String? _error;

  final _apiKeyController = TextEditingController();
  final _nameController = TextEditingController();
  final _routineController = TextEditingController();
  final _dreamController = TextEditingController();
  final _jobController = TextEditingController();

  static const _totalSteps = 6;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 16, 24, 8),
              child: ProgressBarWithLabel(
                progress: (_step + 1) / _totalSteps,
                label: 'خطوة ${_step + 1} من $_totalSteps',
              ),
            ),
            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _apiKeyStep(),
                  _questionStep(
                    icon: Icons.badge_outlined,
                    title: 'اسمك إيه؟',
                    controller: _nameController,
                    hint: 'اكتب اسمك',
                  ),
                  _questionStep(
                    icon: Icons.wb_sunny_outlined,
                    title: 'يومك بيمشي إزاي عادةً؟',
                    subtitle: 'كام كلمة عن روتينك اليومي بيبدأ إزاي وبينتهي إزاي',
                    controller: _routineController,
                    hint: 'مثلاً: بصحى بدري، بروح شغل، برجع متعب وبنام بدري',
                    maxLines: 3,
                  ),
                  _questionStep(
                    icon: Icons.auto_awesome_outlined,
                    title: 'نفسك تحقق إيه؟',
                    subtitle: 'اكتب أكبر حلم أو هدف عايز توصله - الـ AI هيبنيلك أول خطوات عشانه',
                    controller: _dreamController,
                    hint: 'مثلاً: عايز أفتح مشروعي الخاص',
                    maxLines: 3,
                  ),
                  _questionStep(
                    icon: Icons.work_outline,
                    title: 'مجال شغلك أو دراستك؟',
                    controller: _jobController,
                    hint: 'مثلاً: طالب / مبرمج / أوبر / عقارات',
                  ),
                  _finalStep(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stepWrapper({required Widget child}) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [child],
        ),
      ),
    );
  }

  Widget _apiKeyStep() {
    return _stepWrapper(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Icon(Icons.auto_awesome, size: 56, color: AppColors.primary),
          Gaps.h16,
          const Text('أهلاً بيك في Liv',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          Gaps.h8,
          Builder(builder: (context) {
            return Text(
              'قبل ما نبدأ، هنسألك كام سؤال بسيط عشان الـ AI يقدر يفهم حياتك ويبنيلك أهداف واضحة من أول يوم.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: secondaryText(context)),
            );
          }),
          Gaps.h24,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('مفتاح Gemini API (مجاني)',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                Gaps.h8,
                Builder(builder: (context) {
                  return Text(
                    'من غيره الأسئلة الجاية هتتحفظ بس من غير ما الـ AI يقترحلك حاجة. تقدر تجيبه مجانًا من aistudio.google.com/apikey',
                    style: TextStyle(fontSize: 12, color: secondaryText(context)),
                  );
                }),
                Gaps.h12,
                TextField(
                  controller: _apiKeyController,
                  obscureText: true,
                  decoration: const InputDecoration(hintText: 'الصق المفتاح هنا'),
                ),
              ],
            ),
          ),
          Gaps.h24,
          ElevatedButton(
            onPressed: () => _goNext(),
            child: const Text('التالي'),
          ),
          Gaps.h8,
          TextButton(
            onPressed: () => _goNext(),
            child: const Text('هحطه بعدين'),
          ),
        ],
      ),
    );
  }

  Widget _questionStep({
    required IconData icon,
    required String title,
    String? subtitle,
    required TextEditingController controller,
    required String hint,
    int maxLines = 1,
  }) {
    return _stepWrapper(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Icon(icon, size: 48, color: AppColors.primary),
          Gaps.h16,
          Text(title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          if (subtitle != null) ...[
            Gaps.h8,
            Builder(builder: (context) {
              return Text(
                subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: secondaryText(context)),
              );
            }),
          ],
          Gaps.h24,
          SectionCard(
            child: TextField(
              controller: controller,
              maxLines: maxLines,
              autofocus: true,
              decoration: InputDecoration(hintText: hint),
            ),
          ),
          Gaps.h24,
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _goBack,
                  child: const Text('رجوع'),
                ),
              ),
              Gaps.w12,
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: _goNext,
                  child: const Text('التالي'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _finalStep() {
    return _stepWrapper(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Icon(Icons.rocket_launch_outlined, size: 56, color: AppColors.primary),
          Gaps.h16,
          const Text('تمام، كده هبدأ أبنيلك أهدافك',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          Gaps.h8,
          Builder(builder: (context) {
            return Text(
              _apiKeyController.text.trim().isEmpty
                  ? 'من غير مفتاح Gemini هبدأ التطبيق عادي، وتقدر تحط المفتاح بعدين من البروفايل.'
                  : 'الـ AI هياخد إجاباتك ويبنيلك أول حلم بخطوات واضحة تلاقيه في تبويب "الأحلام".',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: secondaryText(context)),
            );
          }),
          Gaps.h24,
          if (_error != null) ...[
            Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.heartRed)),
            Gaps.h12,
          ],
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _submitting ? null : _goBack,
                  child: const Text('رجوع'),
                ),
              ),
              Gaps.w12,
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: _submitting ? null : _finish,
                  child: _submitting
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Text('يلا نبدأ'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _goNext() {
    if (_step < _totalSteps - 1) {
      setState(() => _step++);
      _pageController.nextPage(
          duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    }
  }

  void _goBack() {
    if (_step > 0) {
      setState(() => _step--);
      _pageController.previousPage(
          duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    }
  }

  void _finish() async {
    setState(() {
      _submitting = true;
      _error = null;
    });
    final state = context.read<AppState>();
    final name = _nameController.text.trim().isEmpty ? 'صديقي' : _nameController.text.trim();
    final job = _jobController.text.trim();
    final dreamText = _dreamController.text.trim();
    final routineText = _routineController.text.trim();
    final apiKey = _apiKeyController.text.trim();

    try {
      await state.updateProfile((p) {
        p.name = name;
        p.jobType = job.isEmpty ? null : job;
        p.geminiApiKey = apiKey;
        return p;
      });

      if (apiKey.isNotEmpty && dreamText.isNotEmpty) {
        final extraContext = routineText.isEmpty
            ? dreamText
            : '$dreamText. (سياق إضافي عن يوم المستخدم: $routineText)';
        await state.addDreamWithAISteps(dreamText, extraContext);
      }

      await state.completeOnboarding(name);
    } catch (e) {
      // حتى لو فشل الاتصال بالـ AI، منسيبش المستخدم عالق في الأونبوردنج
      await state.completeOnboarding(name);
    }
    if (mounted) {
      setState(() => _submitting = false);
    }
  }
}
