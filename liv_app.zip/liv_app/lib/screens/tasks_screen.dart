import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('المهام'),
        bottom: TabBar(
          controller: _tab,
          labelColor: AppTheme.purple,
          unselectedLabelColor: AppTheme.lightMuted,
          indicatorColor: AppTheme.purple,
          tabs: const [
            Tab(text: 'يومي'),
            Tab(text: 'أسبوعي'),
            Tab(text: 'شهري'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddTask(context),
        backgroundColor: AppTheme.purple,
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _TaskList(category: 'daily', tasks: state.tasks),
          _TaskList(category: 'weekly', tasks: state.tasks),
          _TaskList(category: 'monthly', tasks: state.tasks),
        ],
      ),
    );
  }

  void _showAddTask(BuildContext context) {
    final titleCtrl = TextEditingController();
    final pointsCtrl = TextEditingController(text: '10');
    String category = 'daily';
    TaskPriority priority = TaskPriority.medium;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).cardTheme.color,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModal) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('مهمة جديدة',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 16),
                  TextField(
                    controller: titleCtrl,
                    decoration: const InputDecoration(hintText: 'عنوان المهمة'),
                    autofocus: true,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: pointsCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(hintText: 'النقاط'),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: category,
                    decoration: const InputDecoration(labelText: 'النوع'),
                    items: const [
                      DropdownMenuItem(value: 'daily', child: Text('يومي')),
                      DropdownMenuItem(value: 'weekly', child: Text('أسبوعي')),
                      DropdownMenuItem(value: 'monthly', child: Text('شهري')),
                    ],
                    onChanged: (v) => setModal(() => category = v!),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<TaskPriority>(
                    value: priority,
                    decoration: const InputDecoration(labelText: 'الأولوية'),
                    items: const [
                      DropdownMenuItem(
                          value: TaskPriority.low, child: Text('منخفضة')),
                      DropdownMenuItem(
                          value: TaskPriority.medium, child: Text('متوسطة')),
                      DropdownMenuItem(
                          value: TaskPriority.high, child: Text('عالية')),
                    ],
                    onChanged: (v) => setModal(() => priority = v!),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      if (titleCtrl.text.trim().isEmpty) return;
                      context.read<AppState>().addTask(Task(
                            title: titleCtrl.text.trim(),
                            points: int.tryParse(pointsCtrl.text) ?? 10,
                            category: category,
                            priority: priority,
                          ));
                      Navigator.pop(ctx);
                    },
                    child: const Text('إضافة'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _TaskList extends StatelessWidget {
  final String category;
  final List<Task> tasks;

  const _TaskList({required this.category, required this.tasks});

  @override
  Widget build(BuildContext context) {
    final filtered = tasks.where((t) => t.category == category).toList();
    final state = context.read<AppState>();

    if (filtered.isEmpty) {
      return const Center(
        child: Text(
          'مفيش مهام هنا\nاضغط + عشان تضيف',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppTheme.lightMuted),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.only(top: 8, bottom: 80),
      itemCount: filtered.length,
      itemBuilder: (context, i) {
        final task = filtered[i];
        return Dismissible(
          key: Key(task.id),
          direction: DismissDirection.endToStart,
          background: Container(
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.only(left: 20),
            color: AppTheme.danger,
            child: const Icon(Icons.delete, color: Colors.white),
          ),
          onDismissed: (_) => state.deleteTask(task.id),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            decoration: BoxDecoration(
              color: Theme.of(context).cardTheme.color,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () => state.toggleTask(task.id),
                  child: Icon(
                    task.isCompleted
                        ? Icons.check_circle_rounded
                        : Icons.circle_outlined,
                    color: task.isCompleted
                        ? AppTheme.success
                        : AppTheme.lightMuted,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        task.title,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          decoration: task.isCompleted
                              ? TextDecoration.lineThrough
                              : null,
                          color: task.isCompleted
                              ? AppTheme.lightMuted
                              : null,
                        ),
                      ),
                      if (task.priority == TaskPriority.high)
                        const Text(
                          'أولوية عالية',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppTheme.danger,
                          ),
                        ),
                    ],
                  ),
                ),
                Text(
                  '+${task.points}',
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.purple,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
