import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final last7Weight = state.weightLogs.length > 7
        ? state.weightLogs.sublist(state.weightLogs.length - 7)
        : state.weightLogs;
    final last7Sleep = state.sleepLogs.length > 7
        ? state.sleepLogs.sublist(state.sleepLogs.length - 7)
        : state.sleepLogs;

    final todaySocialMinutes = state.socialLogs
        .where((l) => l.date == _todayKey())
        .fold(0.0, (a, b) => a + b.value);

    return Scaffold(
      appBar: AppBar(title: const Text('المتابعة والإحصائيات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('الوزن', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    TextButton.icon(
                      icon: const Icon(Icons.add, size: 18),
                      label: const Text('تسجيل'),
                      onPressed: () => _logWeight(context),
                    ),
                  ],
                ),
                Gaps.h8,
                SimpleBarChart(
                  values: last7Weight.map((e) => e.value).toList(),
                  labels: last7Weight.map((e) => e.date.substring(5)).toList(),
                  color: AppColors.primary,
                ),
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('النوم', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    TextButton.icon(
                      icon: const Icon(Icons.add, size: 18),
                      label: const Text('تسجيل'),
                      onPressed: () => _logSleep(context),
                    ),
                  ],
                ),
                Gaps.h8,
                SimpleBarChart(
                  values: last7Sleep.map((e) => e.value).toList(),
                  labels: last7Sleep.map((e) => e.date.substring(5)).toList(),
                  color: AppColors.accentTeal,
                ),
                if (last7Sleep.isNotEmpty) ...[
                  Gaps.h8,
                  Text(
                    state.sleepFeedback(last7Sleep.last.value),
                    style: TextStyle(fontSize: 13, color: secondaryText(context)),
                  ),
                ],
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('وقت السوشيال ميديا النهاردة',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    TextButton.icon(
                      icon: const Icon(Icons.add, size: 18),
                      label: const Text('تسجيل'),
                      onPressed: () => _logSocial(context),
                    ),
                  ],
                ),
                Gaps.h8,
                Text('${todaySocialMinutes.round()} دقيقة',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                if (todaySocialMinutes > 0) ...[
                  Gaps.h8,
                  Text(
                    state.socialMediaEquivalent(todaySocialMinutes),
                    style: TextStyle(fontSize: 13, color: secondaryText(context)),
                  ),
                ],
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('تحليل شخصية سريع بالـ AI',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                Gaps.h8,
                const Text(
                  'بناءً على عاداتك وبياناتك، الـ AI هيديك لمحة سريعة عن نمط حياتك.',
                  style: TextStyle(fontSize: 13, color: secondaryText(context)),
                ),
                Gaps.h12,
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.psychology_alt_outlined),
                    label: const Text('اعمل التحليل'),
                    onPressed: () => _personalityInsight(context),
                  ),
                ),
              ],
            ),
          ),
          Gaps.h24,
        ],
      ),
    );
  }

  String _todayKey() {
    final d = DateTime.now();
    return "${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}";
  }

  void _logWeight(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'وزنك النهاردة (كيلو)', hint: 'مثلا 75');
    final parsed = double.tryParse((v ?? '').replaceAll(',', '.'));
    if (parsed != null && context.mounted) {
      context.read<AppState>().logWeight(parsed);
    }
  }

  void _logSleep(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'عدد ساعات نومك', hint: 'مثلا 7.5');
    final parsed = double.tryParse((v ?? '').replaceAll(',', '.'));
    if (parsed != null && context.mounted) {
      context.read<AppState>().logSleep(parsed);
    }
  }

  void _logSocial(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'كام دقيقة قعدت سوشيال ميديا؟', hint: 'مثلا 30');
    final parsed = double.tryParse((v ?? '').replaceAll(',', '.'));
    if (parsed != null && context.mounted) {
      context.read<AppState>().logSocialMinutes(parsed);
    }
  }

  void _personalityInsight(BuildContext context) async {
    final state = context.read<AppState>();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    String result;
    try {
      final p = state.profile;
      final summary = '''
الاسم: ${p.name}
الهوايات: ${p.hobbies.join('، ')}
الأهداف: ${p.goals.join('، ')}
${state.buildWeeklySummary()}
''';
      result = await state.ai.personalityInsight(profileSummary: summary);
    } catch (e) {
      result = 'خطأ: $e';
    }
    if (!context.mounted) return;
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('تحليل شخصيتك'),
        content: SingleChildScrollView(child: Text(result)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('تمام')),
        ],
      ),
    );
  }
}
