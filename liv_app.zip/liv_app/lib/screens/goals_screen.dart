import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:percent_indicator/percent_indicator.dart';
import '../services/app_state.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';

class GoalsScreen extends StatelessWidget {
  const GoalsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final goals = state.goals.where((g) => !g.isDream).toList();
    final dreams = state.goals.where((g) => g.isDream).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('الأهداف والأحلام')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAdd(context),
        backgroundColor: AppTheme.purple,
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 100),
        children: [
          if (goals.isNotEmpty) ...[
            _title(context, 'أهداف'),
            ...goals.map((g) => _GoalCard(goal: g)),
          ],
          if (dreams.isNotEmpty) ...[
            _title(context, 'أحلام ✨'),
            ...dreams.map((g) => _GoalCard(goal: g)),
          ],
          if (state.goals.isEmpty)
            const Padding(
              padding: EdgeInsets.all(40),
              child: Center(
                child: Text(
                  'حط هدف أو حلم\nوالـ AI هيساعدك تحققهم',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppTheme.lightMuted),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _title(BuildContext context, String t) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
      child: Text(t, style: Theme.of(context).textTheme.titleLarge),
    );
  }

  void _showAdd(BuildContext context) {
    final titleCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    bool isDream = false;
    GoalCategory cat = GoalCategory.personal;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).cardTheme.color,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModal) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('هدف / حلم جديد',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 16),
                  TextField(
                    controller: titleCtrl,
                    decoration: const InputDecoration(hintText: 'العنوان'),
                    autofocus: true,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: descCtrl,
                    decoration: const InputDecoration(hintText: 'وصف (اختياري)'),
                    maxLines: 2,
                  ),
                  const SizedBox(height: 12),
                  SwitchListTile(
                    title: const Text('ده حلم طويل المدى'),
                    value: isDream,
                    onChanged: (v) => setModal(() => isDream = v),
                  ),
                  DropdownButtonFormField<GoalCategory>(
                    value: cat,
                    decoration: const InputDecoration(labelText: 'التصنيف'),
                    items: GoalCategory.values
                        .map((c) => DropdownMenuItem(
                              value: c,
                              child: Text(_catName(c)),
                            ))
                        .toList(),
                    onChanged: (v) => setModal(() => cat = v!),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      if (titleCtrl.text.trim().isEmpty) return;
                      final steps = isDream
                          ? _generateSteps(titleCtrl.text.trim())
                          : <String>[];
                      context.read<AppState>().addGoal(Goal(
                            title: titleCtrl.text.trim(),
                            description: descCtrl.text.trim().isEmpty
                                ? null
                                : descCtrl.text.trim(),
                            isDream: isDream,
                            category: cat,
                            steps: steps,
                          ));
                      Navigator.pop(ctx);
                    },
                    child: const Text('إضافة'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  String _catName(GoalCategory c) {
    switch (c) {
      case GoalCategory.personal:
        return 'شخصي';
      case GoalCategory.career:
        return 'عمل';
      case GoalCategory.health:
        return 'صحة';
      case GoalCategory.finance:
        return 'فلوس';
      case GoalCategory.learning:
        return 'تعلم';
      case GoalCategory.social:
        return 'اجتماعي';
    }
  }

  List<String> _generateSteps(String dream) {
    // Mock AI steps
    return [
      'حدد الهدف بوضوح واكتبه',
      'قسم الهدف لمراحل صغيرة',
      'حدد موعد نهائي لكل مرحلة',
      'ابدأ بأول خطوة النهاردة',
      'راجع تقدمك أسبوعياً',
      'اطلب مساعدة أو نصيحة من حد خبرة',
      'احتفل بكل إنجاز صغير',
    ];
  }
}

class _GoalCard extends StatelessWidget {
  final Goal goal;
  const _GoalCard({required this.goal});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (goal.isDream)
                const Text('✨ ', style: TextStyle(fontSize: 18)),
              Expanded(
                child: Text(
                  goal.title,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
            ],
          ),
          if (goal.description != null) ...[
            const SizedBox(height: 4),
            Text(
              goal.description!,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
          const SizedBox(height: 12),
          LinearPercentIndicator(
            lineHeight: 8,
            percent: goal.progress,
            progressColor: AppTheme.purple,
            backgroundColor: AppTheme.lightBorder.withOpacity(0.3),
            barRadius: const Radius.circular(4),
            padding: EdgeInsets.zero,
          ),
          const SizedBox(height: 6),
          Text(
            '${(goal.progress * 100).toInt()}%',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          if (goal.steps.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text('خطوات التحقيق:',
                style: Theme.of(context).textTheme.bodySmall),
            ...goal.steps.asMap().entries.map((e) => Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    '${e.key + 1}. ${e.value}',
                    style: const TextStyle(fontSize: 13),
                  ),
                )),
          ],
          const SizedBox(height: 8),
          Row(
            children: [
              TextButton(
                onPressed: () {
                  final p = (goal.progress + 0.1).clamp(0.0, 1.0);
                  state.updateGoalProgress(goal.id, p);
                },
                child: const Text('+10%'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
