import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class DreamsScreen extends StatelessWidget {
  const DreamsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('الأحلام')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addDreamDialog(context),
        icon: const Icon(Icons.add),
        label: const Text('حلم جديد'),
      ),
      body: state.dreams.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'لسه معملتش أحلام. ضيف حلمك وهيحطلك الـ AI خطوات واضحة لتحقيقه.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black54),
                ),
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: state.dreams.map((d) => _dreamCard(context, d)).toList(),
            ),
    );
  }

  Widget _dreamCard(BuildContext context, Dream d) {
    final state = context.read<AppState>();
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: SectionCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(d.title,
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline, color: Colors.black38),
                  onPressed: () => state.deleteDream(d),
                ),
              ],
            ),
            if (d.description.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(d.description, style: const TextStyle(color: Colors.black54)),
              ),
            Gaps.h12,
            ProgressBarWithLabel(progress: d.progress, label: 'التقدم'),
            Gaps.h12,
            if (d.steps.isEmpty)
              const Text('مفيش خطوات - جرب "احتاج خطوات AI" تحت',
                  style: TextStyle(color: Colors.black45, fontSize: 12))
            else
              ...d.steps.map((s) => CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    dense: true,
                    activeColor: AppColors.primary,
                    value: s.isDone,
                    title: Text(
                      s.text,
                      style: TextStyle(
                        decoration: s.isDone ? TextDecoration.lineThrough : null,
                        color: s.isDone ? Colors.black38 : Colors.black87,
                      ),
                    ),
                    onChanged: (_) => state.toggleDreamStep(d, s),
                  )),
            if (d.steps.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.auto_awesome, size: 18),
                  label: const Text('احتاج خطوات AI'),
                  onPressed: () => _generateSteps(context, d),
                ),
              ),
          ],
        ),
      ),
    );
  }

  void _generateSteps(BuildContext context, Dream d) async {
    final state = context.read<AppState>();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    try {
      await state.addAIStepsToDream(d);
    } catch (e) {
      if (context.mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خطأ: $e')));
        return;
      }
    }
    if (context.mounted) Navigator.pop(context);
  }

  void _addDreamDialog(BuildContext context) async {
    final titleController = TextEditingController();
    final descController = TextEditingController();
    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('حلم جديد'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleController,
              autofocus: true,
              decoration: const InputDecoration(hintText: 'اسم الحلم'),
            ),
            Gaps.h12,
            TextField(
              controller: descController,
              maxLines: 3,
              decoration: const InputDecoration(hintText: 'تفاصيل إضافية (اختياري)'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, {
              'title': titleController.text.trim(),
              'description': descController.text.trim(),
            }),
            child: const Text('إضافة'),
          ),
        ],
      ),
    );
    if (result != null && (result['title'] ?? '').isNotEmpty) {
      if (!context.mounted) return;
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const Center(child: CircularProgressIndicator()),
      );
      await context
          .read<AppState>()
          .addDreamWithAISteps(result['title']!, result['description'] ?? '');
      if (context.mounted) Navigator.pop(context);
    }
  }
}
