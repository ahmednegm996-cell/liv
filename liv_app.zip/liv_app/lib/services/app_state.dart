import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/models.dart';

class AppState extends ChangeNotifier {
  final _box = Hive.box('liv_data');
  final _profileBox = Hive.box('user_profile');

  UserProfile profile = UserProfile();
  List<Task> tasks = [];
  List<Habit> habits = [];
  List<Goal> goals = [];
  List<Subscription> subscriptions = [];
  bool hasCompletedOnboarding = false;
  bool isDarkMode = false;
  Locale locale = const Locale('ar');
  String? dailyChallenge;
  List<String> aiChatHistory = [];

  void load() {
    hasCompletedOnboarding = _box.get('onboarding', defaultValue: false);
    isDarkMode = _box.get('darkMode', defaultValue: false);
    final lang = _box.get('locale', defaultValue: 'ar');
    locale = Locale(lang);

    final profileJson = _profileBox.get('profile');
    if (profileJson != null) {
      profile = UserProfile.fromJson(Map<String, dynamic>.from(profileJson));
    }

    final tasksJson = _box.get('tasks');
    if (tasksJson != null) {
      tasks = (tasksJson as List)
          .map((e) => Task.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }

    final habitsJson = _box.get('habits');
    if (habitsJson != null) {
      habits = (habitsJson as List)
          .map((e) => Habit.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }

    final goalsJson = _box.get('goals');
    if (goalsJson != null) {
      goals = (goalsJson as List)
          .map((e) => Goal.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }

    final subsJson = _box.get('subscriptions');
    if (subsJson != null) {
      subscriptions = (subsJson as List)
          .map((e) => Subscription.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }

    dailyChallenge = _box.get('dailyChallenge');
    aiChatHistory = List<String>.from(_box.get('aiChat', defaultValue: []));

    _resetHeartsIfNeeded();
    _generateDailyChallengeIfNeeded();
    notifyListeners();
  }

  void _save() {
    _profileBox.put('profile', profile.toJson());
    _box.put('tasks', tasks.map((e) => e.toJson()).toList());
    _box.put('habits', habits.map((e) => e.toJson()).toList());
    _box.put('goals', goals.map((e) => e.toJson()).toList());
    _box.put('subscriptions', subscriptions.map((e) => e.toJson()).toList());
    _box.put('onboarding', hasCompletedOnboarding);
    _box.put('darkMode', isDarkMode);
    _box.put('locale', locale.languageCode);
    _box.put('dailyChallenge', dailyChallenge);
    _box.put('aiChat', aiChatHistory);
  }

  void completeOnboarding(String name) {
    profile.name = name;
    hasCompletedOnboarding = true;
    _save();
    notifyListeners();
  }

  void toggleDarkMode() {
    isDarkMode = !isDarkMode;
    _save();
    notifyListeners();
  }

  void setLocale(Locale l) {
    locale = l;
    _save();
    notifyListeners();
  }

  // ========== Tasks ==========
  void addTask(Task task) {
    tasks.insert(0, task);
    _save();
    notifyListeners();
  }

  void toggleTask(String id) {
    final i = tasks.indexWhere((t) => t.id == id);
    if (i == -1) return;
    final task = tasks[i];
    task.isCompleted = !task.isCompleted;
    if (task.isCompleted) {
      task.completedAt = DateTime.now();
      addPoints(task.points);
    } else {
      task.completedAt = null;
      addPoints(-task.points);
    }
    _save();
    notifyListeners();
  }

  void deleteTask(String id) {
    tasks.removeWhere((t) => t.id == id);
    _save();
    notifyListeners();
  }

  double get todayProgress {
    final today = tasks.where((t) => t.category == 'daily').toList();
    if (today.isEmpty) return 0;
    final done = today.where((t) => t.isCompleted).length;
    return done / today.length;
  }

  // ========== Habits ==========
  void addHabit(Habit habit) {
    habits.add(habit);
    _save();
    notifyListeners();
  }

  void completeHabit(String id) {
    final i = habits.indexWhere((h) => h.id == id);
    if (i == -1) return;
    final habit = habits[i];
    final today = DateTime.now().toIso8601String().substring(0, 10);
    if (habit.completedDates.contains(today)) return;

    habit.completedDates.add(today);
    habit.totalCompletions++;
    habit.streak++;

    if (habit.type == HabitType.good) {
      addPoints(habit.pointsPerDay);
    } else {
      // عادة وحشة
      loseHeart();
      addPoints(-habit.pointsPerDay);
    }
    _save();
    notifyListeners();
  }

  void setMonthlyMonster(String habitId) {
    for (var h in habits) {
      h.isMonster = h.id == habitId;
    }
    profile.monthlyMonsterHabitId = habitId;
    _save();
    notifyListeners();
  }

  // ========== Goals & Dreams ==========
  void addGoal(Goal goal) {
    goals.insert(0, goal);
    _save();
    notifyListeners();
  }

  void updateGoalProgress(String id, double progress) {
    final i = goals.indexWhere((g) => g.id == id);
    if (i == -1) return;
    goals[i].progress = progress.clamp(0.0, 1.0);
    _save();
    notifyListeners();
  }

  // ========== Points & Hearts ==========
  void addPoints(int p) {
    profile.points += p;
    if (profile.points < 0) profile.points = 0;
    // Level up every 500 points
    profile.level = (profile.points / 500).floor() + 1;
    _save();
    notifyListeners();
  }

  void loseHeart() {
    if (profile.hearts > 0) {
      profile.hearts--;
      _save();
      notifyListeners();
    }
  }

  void _resetHeartsIfNeeded() {
    final now = DateTime.now();
    final last = profile.lastHeartReset;
    if (last == null ||
        last.day != now.day ||
        last.month != now.month ||
        last.year != now.year) {
      profile.hearts = 3;
      profile.lastHeartReset = now;
      _save();
    }
  }

  // ========== Daily Challenge ==========
  void _generateDailyChallengeIfNeeded() {
    final today = DateTime.now().toIso8601String().substring(0, 10);
    final last = _box.get('challengeDate');
    if (last != today) {
      final challenges = [
        'اتمرن 20 دقيقة',
        'اقرأ 10 صفحات من كتاب',
        'اشرب 8 أكواب مية',
        'تكلم مع صديق قديم',
        'اكتب 3 حاجات ممتن ليها',
        'تعلم كلمة جديدة بلغة أجنبية',
        'امشي 30 دقيقة',
        'نظم مكتبك أو غرفتك',
        'اطبخ وجبة صحية',
        'اقفل السوشيال ميديا ساعتين',
      ];
      dailyChallenge = challenges[DateTime.now().day % challenges.length];
      _box.put('challengeDate', today);
      _box.put('dailyChallenge', dailyChallenge);
    }
  }

  void completeDailyChallenge() {
    addPoints(25);
    dailyChallenge = null;
    _save();
    notifyListeners();
  }

  // ========== AI Mock ==========
  String getAiResponse(String userMessage) {
    final msg = userMessage.toLowerCase();
    String reply;

    if (msg.contains('نقط') || msg.contains('points')) {
      reply =
          'نقاطك الحالية: ${profile.points} نقطة 🎯\nمستواك: Level ${profile.level}\nكمل المهام عشان توصل للمستوى اللي بعده!';
    } else if (msg.contains('نوم') || msg.contains('sleep')) {
      reply =
          'نومك متوسط ${profile.sleepHours} ساعات بجودة ${(profile.sleepQuality * 100).toInt()}%.\nحاول تنام قبل 11 وتبعد عن الشاشات قبل النوم بساعة.';
    } else if (msg.contains('عادة') || msg.contains('habit')) {
      final good = habits.where((h) => h.type == HabitType.good).length;
      final bad = habits.where((h) => h.type == HabitType.bad).length;
      reply =
          'عندك $good عادات كويسة و $bad عادات وحشة.\nركز على عادة واحدة في الشهر (الوحش) وبطلها هتاخد نقاط كتير!';
    } else if (msg.contains('حلم') || msg.contains('dream') || msg.contains('هدف')) {
      reply =
          'أحلامك موجودة في قسم الأهداف.\nقولي حلمك وأنا هقترحلك خطوات عملية تحققها خطوة بخطوة ✨';
    } else if (msg.contains('سوشيال') || msg.contains('social')) {
      reply =
          'لو قعدت على السوشيال ساعة، كان ممكن:\n• تتعلم 20 كلمة لغة جديدة\n• تعمل تمرين رياضة كامل\n• تقرأ فصل من كتاب\nحاول تحدد وقت يومي للسوشيال مش أكتر.';
    } else if (msg.contains('مهمة') || msg.contains('task')) {
      final pending = tasks.where((t) => !t.isCompleted).length;
      reply =
          'عندك $pending مهمة لسه مخلصتش.\nابدأ بأصغر مهمة دلوقتي، الزخم هيجيب الباقي 💪';
    } else {
      reply =
          'أنا مساعد liv الذكي 🤖\nقدر أساعدك في:\n• تحليل مهامك وعاداتك\n• اقتراح خطط للأحلام\n• نصايح للنوم والصحة\n• تحديات يومية\nقولي عايز إيه؟';
    }

    aiChatHistory.add('user:$userMessage');
    aiChatHistory.add('ai:$reply');
    if (aiChatHistory.length > 40) {
      aiChatHistory = aiChatHistory.sublist(aiChatHistory.length - 40);
    }
    _save();
    notifyListeners();
    return reply;
  }

  // ========== Job Stats ==========
  void updateJobStat(String key, dynamic value) {
    profile.jobStats[key] = value;
    _save();
    notifyListeners();
  }

  void setJobType(String type) {
    profile.jobType = type;
    _save();
    notifyListeners();
  }

  // ========== Subscriptions ==========
  void addSubscription(Subscription sub) {
    subscriptions.add(sub);
    _save();
    notifyListeners();
  }

  void removeSubscription(String id) {
    subscriptions.removeWhere((s) => s.id == id);
    _save();
    notifyListeners();
  }

  // ========== Sleep ==========
  void updateSleep(int hours, double quality) {
    profile.sleepHours = hours;
    profile.sleepQuality = quality;
    _save();
    notifyListeners();
  }

  // ========== Projection (تحليل مستقبلي) ==========
  String getHabitProjection(Habit habit, int days) {
    if (habit.type == HabitType.good) {
      final totalPoints = habit.pointsPerDay * days;
      return 'لو استمرت على "${habit.title}" لمدة $days يوم:\n• هتكسب حوالي $totalPoints نقطة\n• هتبني عادة قوية جداً\n• تأثير إيجابي كبير على حياتك 🌟';
    } else {
      final lost = habit.pointsPerDay * days;
      return 'لو فضلت على "${habit.title}" لمدة $days يوم:\n• هتخسر حوالي $lost نقطة\n• هتأثر سلباً على صحتك وطاقتك\n• أنصحك تبطلها دلوقتي 🔥';
    }
  }
}
