import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:hive_flutter/hive_flutter.dart';

/// Real AI via Google Gemini (free tier) or any OpenAI-compatible endpoint.
/// User pastes API key in Profile → إعدادات AI
class AiService {
  static final _box = Hive.box('liv_data');

  static String get apiKey => _box.get('ai_api_key', defaultValue: '') as String;
  static set apiKey(String v) => _box.put('ai_api_key', v);

  /// "gemini" | "openai" | "groq"
  static String get provider => _box.get('ai_provider', defaultValue: 'gemini') as String;
  static set provider(String v) => _box.put('ai_provider', v);

  static bool get hasKey => apiKey.trim().isNotEmpty;

  static Future<String> chat({
    required String userMessage,
    required String systemContext,
    List<Map<String, String>> history = const [],
  }) async {
    if (!hasKey) {
      return _smartLocal(userMessage, systemContext);
    }

    try {
      switch (provider) {
        case 'openai':
        case 'groq':
          return await _openAiCompatible(userMessage, systemContext, history);
        case 'gemini':
        default:
          return await _gemini(userMessage, systemContext, history);
      }
    } catch (e) {
      return 'حصلت مشكلة في الاتصال بالـ AI 😔\n$e\n\nجرب تتأكد من الـ API Key في الإعدادات.';
    }
  }

  static Future<String> _gemini(
    String userMessage,
    String systemContext,
    List<Map<String, String>> history,
  ) async {
    final url = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey',
    );

    final contents = <Map<String, dynamic>>[];
    for (final h in history.take(12)) {
      contents.add({
        'role': h['role'] == 'user' ? 'user' : 'model',
        'parts': [{'text': h['text']}],
      });
    }
    contents.add({
      'role': 'user',
      'parts': [{'text': userMessage}],
    });

    final body = {
      'system_instruction': {
        'parts': [{'text': systemContext}],
      },
      'contents': contents,
      'generationConfig': {
        'temperature': 0.75,
        'maxOutputTokens': 1024,
      },
    };

    final res = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(body),
    );

    if (res.statusCode != 200) {
      throw Exception('Gemini error ${res.statusCode}: ${res.body}');
    }

    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final text = data['candidates']?[0]?['content']?['parts']?[0]?['text'];
    if (text == null || (text as String).isEmpty) {
      throw Exception('Empty response from Gemini');
    }
    return text.trim();
  }

  static Future<String> _openAiCompatible(
    String userMessage,
    String systemContext,
    List<Map<String, String>> history,
  ) async {
    final base = provider == 'groq'
        ? 'https://api.groq.com/openai/v1/chat/completions'
        : 'https://api.openai.com/v1/chat/completions';
    final model = provider == 'groq' ? 'llama-3.3-70b-versatile' : 'gpt-4o-mini';

    final messages = <Map<String, String>>[
      {'role': 'system', 'content': systemContext},
      ...history.map((h) => {
            'role': h['role'] == 'user' ? 'user' : 'assistant',
            'content': h['text'] ?? '',
          }),
      {'role': 'user', 'content': userMessage},
    ];

    final res = await http.post(
      Uri.parse(base),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({
        'model': model,
        'messages': messages,
        'temperature': 0.75,
        'max_tokens': 1024,
      }),
    );

    if (res.statusCode != 200) {
      throw Exception('API error ${res.statusCode}: ${res.body}');
    }

    final data = jsonDecode(res.body) as Map<String, dynamic>;
    return (data['choices'][0]['message']['content'] as String).trim();
  }

  /// Smart offline fallback when no API key
  static String _smartLocal(String msg, String ctx) {
    final m = msg.toLowerCase();
    if (m.contains('نقط') || m.contains('point')) {
      return 'عشان أشوف نقاطك بالتفصيل حط API Key من الإعدادات 🔑\nأو قولّي عن مهامك وعاداتك وأحللها لك محلياً.';
    }
    if (m.contains('عاد') || m.contains('habit')) {
      return 'العادات القوية بتتبني بالتكرار اليومي الصغير.\nاختار عادة واحدة بس هذا الأسبوع وركز عليها.\n(حط Gemini API Key المجاني عشان أديك خطة مخصصة)';
    }
    if (m.contains('نوم') || m.contains('sleep')) {
      return 'نوم كويس = طاقة اليوم كله.\nجرب:\n• ثابت ميعاد النوم\n• ابعد الشاشات قبل النوم بـ 45 دقيقة\n• غرفة مظلمة وهادية';
    }
    if (m.contains('حلم') || m.contains('هدف') || m.contains('goal')) {
      return 'قسّم حلمك لخطوات أسبوعية صغيرة.\nأول خطوة تنجزها النهاردة أهم من خطة مثالية.\nحط API Key وأنا أبنيلك خطة كاملة مخصصة.';
    }
    return 'أنا مساعد liv 💜\n\nعشان أرد عليك بذكاء حقيقي:\n1. روح الإعدادات → إعدادات AI\n2. حط Gemini API Key (مجاني من Google AI Studio)\n3. ارجع واتكلم معايا عادي\n\nلحد ما تحط المفتاح، أقدر أديك نصايح عامة كويسة.';
  }

  static String buildSystemPrompt({
    required String name,
    required int points,
    required int level,
    required int hearts,
    required int tasksDone,
    required int tasksTotal,
    required int habitsCount,
    required int sleepHours,
  }) {
    return '''
أنت مساعد ذكي داخل تطبيق liv لإدارة الحياة. اسم المستخدم: $name.
رد دائماً بالعامية المصرية بأسلوب ودود ومختصر وعملي.
بيانات المستخدم الحالية:
- النقاط: $points | المستوى: $level | القلوب: $hearts/3
- مهام اليوم: $tasksDone من $tasksTotal
- عدد العادات: $habitsCount
- ساعات النوم: $sleepHours

ساعده في: المهام، العادات، الأهداف، النوم، التركيز، التحفيز، خطط الأحلام.
لو سأل عن حاجة مش متعلقة بحياته، جاوب باختصار وارجع للموضوع.
''';
  }
}
