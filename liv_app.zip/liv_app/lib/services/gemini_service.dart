import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

/// خدمة AI موحّدة: Gemini أو Grok (xAI)
/// فيها طابور طلبات + إعادة محاولة عشان ميتعلقش بعد طلبين/تلاتة
class GeminiService {
  final String apiKey;
  final String model;
  final String provider; // 'gemini' | 'groq' | 'grok'

  GeminiService({
    required this.apiKey,
    this.model = 'gemini-2.0-flash',
    this.provider = 'gemini',
  });

  bool get isConfigured => apiKey.trim().isNotEmpty;

  // طابور بسيط: طلب واحد في نفس الوقت + تأخير بين الطلبات
  static Future<void> _chain = Future.value();
  static DateTime _lastCall = DateTime.fromMillisecondsSinceEpoch(0);

  Future<T> _enqueue<T>(Future<T> Function() job) {
    final c = Completer<T>();
    _chain = _chain.then((_) async {
      final wait = const Duration(milliseconds: 800) -
          DateTime.now().difference(_lastCall);
      if (wait > Duration.zero) await Future.delayed(wait);
      try {
        final r = await job();
        _lastCall = DateTime.now();
        c.complete(r);
      } catch (e) {
        c.completeError(e);
      }
    });
    return c.future;
  }

  Future<String> generateText(String prompt) {
    if (!isConfigured) {
      throw Exception('محتاج تحط مفتاح API الأول من الإعدادات.');
    }
    return _enqueue(() => _generateWithRetry(prompt));
  }

  Future<String> _generateWithRetry(String prompt, {int attempt = 0}) async {
    try {
      if (provider == 'grok' || provider == 'groq') {
        return await _openAiCompatible(prompt);
      }
      return await _gemini(prompt);
    } catch (e) {
      final msg = e.toString();
      final retriable = msg.contains('429') ||
          msg.contains('حد الطلبات') ||
          msg.contains('Timeout') ||
          msg.contains('وقت طويل') ||
          msg.contains('500') ||
          msg.contains('503');
      if (retriable && attempt < 3) {
        await Future.delayed(Duration(seconds: 2 * (attempt + 1)));
        return _generateWithRetry(prompt, attempt: attempt + 1);
      }
      rethrow;
    }
  }

  Future<String> _gemini(String prompt) async {
    // موديلات مستقرة — gemini-3.6-flash مش موجود عند الكل
    final models = <String>[
      model,
      'gemini-2.0-flash',
      'gemini-1.5-flash',
      'gemini-1.5-flash-latest',
    ];
    Object? lastErr;
    for (final m in models.toSet()) {
      try {
        final url = Uri.parse(
            'https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$apiKey');
        final res = await http
            .post(
              url,
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({
                'contents': [
                  {
                    'parts': [
                      {'text': prompt}
                    ]
                  }
                ],
                'generationConfig': {
                  'temperature': 0.75,
                  'maxOutputTokens': 2048,
                }
              }),
            )
            .timeout(const Duration(seconds: 40));

        if (res.statusCode == 429) {
          throw Exception('وصلت لحد الطلبات مؤقتًا (429). استنى شوية.');
        }
        if (res.statusCode == 401 || res.statusCode == 403) {
          throw Exception('مفتاح Gemini غير صحيح أو مش مفعّل.');
        }
        if (res.statusCode == 404) {
          lastErr = Exception('الموديل $m مش متاح');
          continue;
        }
        if (res.statusCode >= 500) {
          throw Exception('خدمة Gemini فيها مشكلة مؤقتة (${res.statusCode}).');
        }
        if (res.statusCode != 200) {
          throw Exception('Gemini رجّع ${res.statusCode}: ${res.body}');
        }

        final data = jsonDecode(utf8.decode(res.bodyBytes));
        final candidates = data['candidates'];
        if (candidates is List && candidates.isNotEmpty) {
          final parts = candidates[0]['content']?['parts'];
          if (parts is List) {
            final text = parts
                .map((p) => p['text'] ?? '')
                .where((x) => x.toString().isNotEmpty)
                .join('\n')
                .trim();
            if (text.isNotEmpty) return text;
          }
        }
        throw Exception('Gemini رجّع رد فاضي.');
      } on TimeoutException {
        lastErr = Exception('الاتصال أخد وقت طويل. تأكد من النت.');
      } on SocketException {
        throw Exception('مفيش إنترنت. تأكد إن Wi‑Fi أو البيانات شغالة.');
      } on HandshakeException {
        throw Exception('مشكلة أمان في الاتصال. جرّب شبكة تانية.');
      } catch (e) {
        lastErr = e;
        if (e.toString().contains('429') ||
            e.toString().contains('غير صحيح') ||
            e.toString().contains('إنترنت')) {
          rethrow;
        }
      }
    }
    throw lastErr ?? Exception('فشل الاتصال بـ Gemini.');
  }

  Future<String> _openAiCompatible(String prompt) async {
    // Grok (xAI) أو Groq
    final isGrok = provider == 'grok';
    final base = isGrok
        ? 'https://api.x.ai/v1/chat/completions'
        : 'https://api.groq.com/openai/v1/chat/completions';
    final mdl = isGrok
        ? (model.isEmpty || model.startsWith('gemini') ? 'grok-2-latest' : model)
        : (model.isEmpty || model.startsWith('gemini')
            ? 'llama-3.3-70b-versatile'
            : model);

    final res = await http
        .post(
          Uri.parse(base),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $apiKey',
          },
          body: jsonEncode({
            'model': mdl,
            'messages': [
              {'role': 'user', 'content': prompt}
            ],
            'temperature': 0.75,
            'max_tokens': 2048,
          }),
        )
        .timeout(const Duration(seconds: 40));

    if (res.statusCode == 429) {
      throw Exception('وصلت لحد الطلبات مؤقتًا. استنى شوية.');
    }
    if (res.statusCode == 401 || res.statusCode == 403) {
      throw Exception('مفتاح ${isGrok ? 'Grok' : 'Groq'} غير صحيح.');
    }
    if (res.statusCode != 200) {
      throw Exception('API رجّع ${res.statusCode}: ${res.body}');
    }
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    final text = data['choices']?[0]?['message']?['content'];
    if (text == null || (text as String).trim().isEmpty) {
      throw Exception('رد فاضي من الـ API.');
    }
    return text.trim();
  }

  Future<String> testConnection() =>
      generateText('رد بكلمة واحدة فقط: تمام');

  Future<List<String>> generateDreamSteps({
    required String title,
    required String description,
  }) async {
    final text = await generateText('''
أنت مخطط أهداف عملي. المستخدم عنده حلم: "$title".
تفاصيل: "$description".

اكتب خطة من 6 إلى 8 خطوات زمنية واضحة (مش كلام تحفيزي):
- كل خطوة تبدأ بمدة تقديرية بين قوسين زي: (يوم 1-3) أو (الأسبوع 2) أو (خلال شهر)
- بعد المدة: فعل واضح قابل للتنفيذ
- بالعربي المصري البسيط
- كل خطوة في سطر لوحدها بدون ترقيم زائد
''');
    return text
        .split('\n')
        .map((l) => l.replaceFirst(RegExp(r'^[\-\*\d\.\)\s]+'), '').trim())
        .where((l) => l.isNotEmpty)
        .toList();
  }

  Future<String> weeklyMeeting({required String weeklySummary}) =>
      generateText('''
أنت مساعد شخصي بتعمل ميتنج أسبوعي.
ملخص المستخدم:
$weeklySummary
بالعربي المصري:
1) إنجاز يستاهل تقدير
2) أكبر نقطة محتاجة تحسين
3) خطوة عملية واحدة للأسبوع الجاي
مختصر وواقعي.
''');

  Future<String> dailyMeeting({required String dailySummary}) =>
      generateText('''
أنت مساعد شخصي بتعمل ميتنج سريع آخر اليوم.
ملخص اليوم:
$dailySummary
بالعربي المصري في 4-6 أسطر:
- إيه اللي اتعمل كويس
- إيه اللي اتأجل
- حاجة واحدة بس بكرة
''');

  Future<String> personalityInsight({required String profileSummary}) =>
      generateText('''
بيانات مستخدم:
$profileSummary
حلّل نمط حياته بشكل بنّاء بالعربي المصري في 5-7 جمل، من غير تشخيص طبي.
''');

  Future<String> analyzeHabitImpact({
    required String habitName,
    required bool isGood,
    required int currentStreakDays,
  }) =>
      generateText(
          'حلّل عادة ${isGood ? 'إيجابية' : 'سلبية'} اسمها "$habitName". مستمر عليها $currentStreakDays يوم. اكتب 4-6 جمل بالعربي المصري عن تأثيرها خلال 3 شهور لسنة + نصيحة عملية.');

  Future<Map<String, dynamic>> generateStarterPlan({
    required Map<String, String> answers,
  }) async {
    final context =
        answers.entries.map((e) => '${e.key}: ${e.value}').join('\n');
    final text = await generateText('''
أنت العقل التخطيطي لتطبيق Liv.
بيانات المستخدم:
$context
ابنِ بداية أسبوع واحد. رجّع JSON فقط بدون Markdown:
{"good_habits":["..."],"bad_habits":["..."],"weekly_tasks":["..."],"dream_title":"...","dream_description":"..."}
2-4 عادات كويسة، 0-2 وحشة، 3-6 مهام أسبوعية.
''');
    final cleaned = text
        .replaceFirst(RegExp(r'^```json\s*'), '')
        .replaceFirst(RegExp(r'^```\s*'), '')
        .replaceFirst(RegExp(r'\s*```$'), '')
        .trim();
    final decoded = jsonDecode(cleaned);
    if (decoded is! Map<String, dynamic>) {
      throw Exception('خطة البداية غير مفهومة.');
    }
    return decoded;
  }

  Future<String> chat({
    required String userMessage,
    required String context,
    List<Map<String, String>> history = const [],
  }) {
    final previous = history.take(10).map((m) {
      final who = m['role'] == 'user' ? 'المستخدم' : 'Liv AI';
      return '$who: ${m['text']}';
    }).join('\n');
    return generateText('''
أنت Liv AI، مساعد شخصي هادي وذكي. اتكلم بالمصري الطبيعي.
مش بتشخّص طبيًا. لو الموضوع خطير شجّع المختص.
بياناته:
$context

آخر المحادثة:
$previous

رسالة المستخدم:
$userMessage

رد إنساني مختصر عملي.
''');
  }
}
