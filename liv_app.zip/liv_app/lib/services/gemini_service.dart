// خدمة الاتصال بـ Google Gemini API (فيه باقة مجانية - Google AI Studio)
// المستخدم بيحط الـ API key بتاعه في شاشة البروفايل/الإعدادات.
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class GeminiService {
  final String apiKey;
  final String model;

  GeminiService({required this.apiKey, this.model = 'gemini-2.0-flash'});

  bool get isConfigured => apiKey.trim().isNotEmpty;

  Uri get _endpoint => Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey');

  /// استدعاء عام: يبعت prompt نصي ويرجع نص الرد من Gemini.
  Future<String> generateText(String prompt) async {
    if (!isConfigured) {
      throw Exception(
          'محتاج تحط مفتاح Gemini API الأول من شاشة الإعدادات (مجاني من Google AI Studio).');
    }
    http.Response res;
    try {
      res = await http.post(
        _endpoint,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [
            {
              'parts': [
                {'text': prompt}
              ]
            }
          ],
          'generationConfig': {
            'temperature': 0.8,
            'maxOutputTokens': 1024,
          }
        }),
      );
    } on SocketException {
      throw Exception('مفيش اتصال إنترنت دلوقتي. اتأكد إن الواي فاي أو البيانات شغالة وجرب تاني.');
    } on HttpException catch (e) {
      throw Exception('مشكلة في الاتصال: $e');
    } catch (e) {
      // بنعرض الخطأ الحقيقي بدل ما نفترض إنه مشكلة نت دايمًا
      throw Exception('حصل خطأ غير متوقع: $e');
    }

    if (res.statusCode == 400 || res.statusCode == 403) {
      throw Exception('مفتاح Gemini API مش صحيح أو مرفوض. اتأكد إنك حاطط المفتاح صح من الإعدادات.');
    }
    if (res.statusCode != 200) {
      throw Exception(
          'فشل الاتصال بـ Gemini (كود ${res.statusCode}): ${res.body}');
    }

    final data = jsonDecode(utf8.decode(res.bodyBytes));
    try {
      final candidates = data['candidates'] as List;
      final parts = candidates[0]['content']['parts'] as List;
      return parts.map((p) => p['text'] ?? '').join('\n').trim();
    } catch (_) {
      throw Exception('رد غير متوقع من Gemini: ${res.body}');
    }
  }

  /// تحليل تأثير عادة (كويسة أو وحشة) بعد استمرارها فترة معينة
  Future<String> analyzeHabitImpact({
    required String habitName,
    required bool isGood,
    required int currentStreakDays,
  }) {
    final kind = isGood ? 'عادة إيجابية' : 'عادة سلبية';
    final prompt = '''
أنت مدرب حياة (life coach) واقعي ومباشر. المستخدم عنده $kind اسمها: "$habitName".
هو مستمر عليها من $currentStreakDays يوم.
اكتب تحليل واقعي وقصير (٤-٦ جمل، بالعربي المصري البسيط، من غير مبالغة) لتأثير الاستمرار على العادة دي على المدى المتوسط والطويل (٣ شهور - سنة):
- لو عادة كويسة: وضّح الفايدة الحقيقية المتوقعة (صحية/نفسية/إنتاجية) لو استمر.
- لو عادة وحشة: وضّح الضرر الحقيقي المتوقع لو استمر، وإيه اللي ممكن يحصل لو بطلها بدري.
منظم في نقط قصيرة لو ينفع، وخليه تحفيزي بس واقعي مش خيالي.
''';
    return generateText(prompt);
  }

  /// توليد خطوات واضحة ومنطقية لتحقيق حلم
  Future<List<String>> generateDreamSteps({
    required String title,
    required String description,
  }) async {
    final prompt = '''
أنت مستشار تخطيط أهداف. المستخدم عنده حلم اسمه: "$title".
تفاصيل إضافية: "$description".
اكتب خطة عملية من ٥ إلى ٨ خطوات واضحة ومرتبة منطقيًا (من الأول للآخر) لتحقيق الحلم ده، كل خطوة تكون قابلة للتنفيذ فعليًا (مش كلام عام).
رجّع كل خطوة في سطر لوحدها، من غير ترقيم ومن غير رموز زيادة، بالعربي المصري البسيط.
''';
    final text = await generateText(prompt);
    return text
        .split('\n')
        .map((l) => l.replaceFirst(RegExp(r'^[\-\*\d\.\)\s]+'), '').trim())
        .where((l) => l.isNotEmpty)
        .toList();
  }

  /// تقرير/اجتماع أسبوعي مع الـ AI بناءً على ملخص أداء المستخدم
  Future<String> weeklyMeeting({required String weeklySummary}) {
    final prompt = '''
أنت مساعد شخصي بيعمل "ميتنج أسبوعي" مع المستخدم زي كوتش حقيقي.
دا ملخص أداء المستخدم الأسبوع ده:
$weeklySummary

اكتب رد بأسلوب ودود ومباشر (بالعربي المصري):
1. حاجة إيجابية حصلت الأسبوع ده وتستاهل تقدير.
2. أكبر مشكلة أو حاجة اتقصر فيها.
3. اقتراح عملي واحد بس للأسبوع الجاي عشان يتحسن.
خليه مختصر - مش أكتر من ٨ سطور.
''';
    return generateText(prompt);
  }

  /// تحليل شخصية مبدئي بناءً على بيانات المستخدم والعادات
  Future<String> personalityInsight({required String profileSummary}) {
    final prompt = '''
دي بيانات وعادات مستخدم:
$profileSummary

اكتب تحليل شخصية قصير وودود (٥-٧ جمل بالعربي المصري) عن نمط حياته الحالي،
نقاط قوته، وحاجة واحدة يقدر يشتغل عليها. متكونش حكم قاسي، خليه بنّاء ومحفّز.
''';
    return generateText(prompt);
  }
}
