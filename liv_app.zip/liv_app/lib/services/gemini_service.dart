
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class GeminiService {
  final String apiKey;
  final String model;

  GeminiService({required this.apiKey, this.model = 'gemini-3.6-flash'});

  bool get isConfigured => apiKey.trim().isNotEmpty;

  Uri get _endpoint => Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey');

  Future<String> generateText(String prompt) async {
    if (!isConfigured) {
      throw Exception('محتاج تحط مفتاح Gemini API الأول من الإعدادات.');
    }
    try {
      final res = await http.post(
        _endpoint,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [{'parts': [{'text': prompt}]}],
          'generationConfig': {'maxOutputTokens': 2048}
        }),
      ).timeout(const Duration(seconds: 35));

      if (res.statusCode == 400) throw Exception('Gemini رفض الطلب. راجع اسم الموديل أو صيغة الطلب.');
      if (res.statusCode == 401 || res.statusCode == 403) throw Exception('مفتاح Gemini غير صحيح أو غير مسموح له باستخدام الـ API.');
      if (res.statusCode == 404) throw Exception('الموديل "$model" غير متاح. جرّب Gemini 3.6 Flash من الإعدادات.');
      if (res.statusCode == 429) throw Exception('وصلت لحد الطلبات مؤقتًا. استنى شوية وجرب تاني.');
      if (res.statusCode >= 500) throw Exception('خدمة Gemini فيها مشكلة مؤقتة. جرب بعد دقيقة.');
      if (res.statusCode != 200) throw Exception('Gemini رجّع كود ${res.statusCode}: ${res.body}');

      final data = jsonDecode(utf8.decode(res.bodyBytes));
      final candidates = data['candidates'];
      if (candidates is List && candidates.isNotEmpty) {
        final parts = candidates[0]['content']?['parts'];
        if (parts is List) {
          final text = parts.map((p) => p['text'] ?? '').where((x) => x.toString().isNotEmpty).join('\n').trim();
          if (text.isNotEmpty) return text;
        }
      }
      throw Exception('Gemini رجّع رد فاضي أو غير مفهوم.');
    } on TimeoutException {
      throw Exception('الاتصال أخد وقت طويل. اتأكد من النت وجرب تاني.');
    } on SocketException {
      throw Exception('الموبايل مش قادر يوصل للإنترنت. تأكد إن Wi‑Fi/البيانات شغالة.');
    } on HandshakeException {
      throw Exception('حصلت مشكلة أمان أثناء الاتصال. جرّب شبكة مختلفة.');
    }
  }

  Future<String> testConnection() => generateText('رد بكلمة واحدة فقط: تمام');

  Future<List<String>> generateDreamSteps({required String title, required String description}) async {
    final text = await generateText('''
أنت مستشار تخطيط أهداف. المستخدم عنده حلم اسمه: "$title".
تفاصيل إضافية: "$description".
اكتب خطة عملية من 5 إلى 8 خطوات قابلة للتنفيذ، كل خطوة في سطر مستقل، بالعربي المصري.
''');
    return text.split('\n')
        .map((l) => l.replaceFirst(RegExp(r'^[\-\*\d\.\)\s]+'), '').trim())
        .where((l) => l.isNotEmpty).toList();
  }

  Future<String> weeklyMeeting({required String weeklySummary}) => generateText('''
أنت مساعد شخصي بيعمل ميتنج أسبوعي مع المستخدم.
ملخصه:
$weeklySummary
اكتب بالعربي المصري:
1) إنجاز يستاهل تقدير.
2) أكبر نقطة محتاجة تحسين.
3) خطوة واحدة عملية للأسبوع الجاي.
مختصر وواقعي.
''');

  Future<String> personalityInsight({required String profileSummary}) => generateText('''
دي بيانات مستخدم:
$profileSummary
حلل نمط حياته بشكل بنّاء وواقعي بالعربي المصري في 5-7 جمل، بدون تشخيص طبي أو أحكام قاسية.
''');

  Future<String> analyzeHabitImpact({required String habitName, required bool isGood, required int currentStreakDays}) =>
      generateText('حلل عادة ${isGood ? 'إيجابية' : 'سلبية'} اسمها "$habitName". مستمر عليها $currentStreakDays يوم. اكتب بالعربي المصري 4-6 جمل عن تأثيرها الواقعي خلال 3 شهور إلى سنة، مع نصيحة عملية.');

  Future<Map<String, dynamic>> generateStarterPlan({required Map<String, String> answers}) async {
    final context = answers.entries.map((e) => '${e.key}: ${e.value}').join('\n');
    final text = await generateText('''
أنت العقل التخطيطي لتطبيق Liv لإدارة الحياة.
بيانات المستخدم:
$context

ابنِ له بداية عملية لمدة أسبوع واحد. لا تخترع معلومات غير موجودة.
أعد JSON فقط بدون Markdown وبالمفاتيح التالية:
{
 "good_habits":["...","..."],
 "bad_habits":["..."],
 "weekly_tasks":["...","...","..."],
 "dream_title":"...",
 "dream_description":"..."
}
ضع 2-4 عادات جيدة، 0-2 عادات سلبية، 3-6 مهام أسبوعية، وحلمًا واحدًا إذا ذكر المستخدم هدفًا واضحًا.
كل مهمة صغيرة وقابلة للتنفيذ.
''');
    final cleaned = text.replaceFirst(RegExp(r'^```json\s*'), '')
        .replaceFirst(RegExp(r'^```\s*'), '')
        .replaceFirst(RegExp(r'\s*```$'), '').trim();
    final decoded = jsonDecode(cleaned);
    if (decoded is! Map<String, dynamic>) throw Exception('خطة البداية غير مفهومة.');
    return decoded;
  }

  Future<String> chat({required String userMessage, required String context, List<Map<String, String>> history = const []}) {
    final previous = history.take(8).map((m) => '${m['role'] == 'user' ? 'المستخدم' : 'Liv AI'}: ${m['text']}').join('\n');
    return generateText('''
أنت Liv AI، مساعد شخصي هادي وذكي. اتكلم بالمصري الطبيعي.
المستخدم مش طالب تشخيص نفسي ولا علاج طبي؛ لو الموضوع طبي/نفسي خطير شجعه يتكلم مع مختص.
بياناته:
$context

آخر المحادثة:
$previous

رسالة المستخدم:
$userMessage

رد بشكل إنساني، مختصر، عملي، واسأل سؤالًا واحدًا فقط لو محتاج تفهم أكثر.
''');
  }
}
