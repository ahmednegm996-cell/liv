import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

/// خدمة AI: Gemini / Grok / Groq
/// معالجة قوية لـ 429: طابور + تأخير + backoff تصاعدي
class GeminiService {
  final String apiKey;
  final String model;
  final String provider; // gemini | grok | groq

  GeminiService({
    required this.apiKey,
    this.model = 'gemini-1.5-flash',
    this.provider = 'gemini',
  });

  bool get isConfigured => apiKey.trim().isNotEmpty;

  // طابور عام لكل الطلبات
  static Future<void> _chain = Future.value();
  static DateTime _lastCall = DateTime.fromMillisecondsSinceEpoch(0);
  static int _consecutive429 = 0;

  /// أقل فاصل بين أي طلبين (ثواني) — بيزيد لو حصل 429
  static Duration get _minGap {
    if (_consecutive429 >= 3) return const Duration(seconds: 12);
    if (_consecutive429 >= 1) return const Duration(seconds: 6);
    return const Duration(seconds: 2);
  }

  Future<T> _enqueue<T>(Future<T> Function() job) {
    final c = Completer<T>();
    _chain = _chain.then((_) async {
      final gap = _minGap - DateTime.now().difference(_lastCall);
      if (gap > Duration.zero) {
        await Future.delayed(gap);
      }
      try {
        final r = await job();
        _lastCall = DateTime.now();
        _consecutive429 = 0;
        c.complete(r);
      } catch (e) {
        _lastCall = DateTime.now();
        c.completeError(e);
      }
    });
    return c.future;
  }

  Future<String> generateText(String prompt) {
    if (!isConfigured) {
      throw Exception('محتاج تحط مفتاح API من الإعدادات الأول.');
    }
    return _enqueue(() => _generateWithRetry(prompt));
  }

  Future<String> _generateWithRetry(String prompt, {int attempt = 0}) async {
    try {
      if (provider == 'grok' || provider == 'groq') {
        return await _openAiCompatible(prompt);
      }
      return await _gemini(prompt);
    } catch (e) {
      final msg = e.toString();
      final is429 = msg.contains('429') || msg.contains('حد الطلبات') || msg.contains('RESOURCE_EXHAUSTED');
      final retriable = is429 ||
          msg.contains('Timeout') ||
          msg.contains('وقت طويل') ||
          msg.contains('500') ||
          msg.contains('503');

      if (is429) _consecutive429++;

      if (retriable && attempt < 4) {
        // 5s, 15s, 30s, 45s
        final waitSec = is429 ? (5 + attempt * 15) : (2 + attempt * 3);
        await Future.delayed(Duration(seconds: waitSec));
        return _generateWithRetry(prompt, attempt: attempt + 1);
      }

      if (is429) {
        throw Exception(
          'وصلت للحد المجاني من Google (خطأ 429).\n'
          'استنى دقيقة أو دقيقتين وجرب تاني.\n'
          'أو حوّل لمزوّد Grok/Groq من البروفايل.',
        );
      }
      rethrow;
    }
  }

  Future<String> _gemini(String prompt) async {
    // موديلات مستقرة — 1.5-flash عليه حد أعلى في الباقة المجانية غالباً
    final models = <String>[
      if (model.isNotEmpty) model,
      'gemini-1.5-flash',
      'gemini-1.5-flash-latest',
      'gemini-2.0-flash',
      'gemini-1.5-flash-8b',
    ];

    Object? lastErr;
    for (final m in models.toSet()) {
      try {
        final url = Uri.parse(
          'https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$apiKey',
        );
        final res = await http
            .post(
              url,
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({
                'contents': [
                  {
                    'parts': [
                      {'text': prompt}
                    ]
                  }
                ],
                'generationConfig': {
                  'temperature': 0.7,
                  'maxOutputTokens': 1024, // أقل = أقل استهلاك للكوتا
                },
              }),
            )
            .timeout(const Duration(seconds: 45));

        if (res.statusCode == 429) {
          throw Exception('429 حد الطلبات');
        }
        if (res.statusCode == 401 || res.statusCode == 403) {
          throw Exception('مفتاح Gemini غير صحيح أو مش مفعّل للـ API.');
        }
        if (res.statusCode == 404) {
          lastErr = Exception('الموديل $m مش متاح');
          continue;
        }
        if (res.statusCode >= 500) {
          throw Exception('خدمة Gemini فيها مشكلة مؤقتة (${res.statusCode}).');
        }
        if (res.statusCode != 200) {
          // RESOURCE_EXHAUSTED often in body with 429 already handled
          if (res.body.contains('RESOURCE_EXHAUSTED') || res.body.contains('quota')) {
            throw Exception('429 حد الطلبات');
          }
          throw Exception('Gemini رجّع ${res.statusCode}');
        }

        final data = jsonDecode(utf8.decode(res.bodyBytes));
        final candidates = data['candidates'];
        if (candidates is List && candidates.isNotEmpty) {
          final parts = candidates[0]['content']?['parts'];
          if (parts is List) {
            final text = parts
                .map((p) => p['text'] ?? '')
                .where((x) => x.toString().isNotEmpty)
                .join('\n')
                .trim();
            if (text.isNotEmpty) return text;
          }
        }
        // block reason?
        final block = data['promptFeedback']?['blockReason'];
        if (block != null) {
          throw Exception('الطلب اترفض من Google ($block). غيّر صيغة السؤال.');
        }
        throw Exception('Gemini رجّع رد فاضي.');
      } on TimeoutException {
        lastErr = Exception('الاتصال أخد وقت طويل. تأكد من النت.');
      } on SocketException {
        throw Exception('مفيش إنترنت. تأكد إن Wi‑Fi أو البيانات شغالة.');
      } on HandshakeException {
        throw Exception('مشكلة أمان في الاتصال. جرّب شبكة تانية.');
      } catch (e) {
        lastErr = e;
        final s = e.toString();
        if (s.contains('429') ||
            s.contains('غير صحيح') ||
            s.contains('إنترنت') ||
            s.contains('حد الطلبات')) {
          rethrow;
        }
      }
    }
    throw lastErr ?? Exception('فشل الاتصال بـ Gemini.');
  }

  Future<String> _openAiCompatible(String prompt) async {
    final isGrok = provider == 'grok';
    final base = isGrok
        ? 'https://api.x.ai/v1/chat/completions'
        : 'https://api.groq.com/openai/v1/chat/completions';
    final mdl = isGrok
        ? (model.isEmpty || model.startsWith('gemini') ? 'grok-2-latest' : model)
        : (model.isEmpty || model.startsWith('gemini')
            ? 'llama-3.3-70b-versatile'
            : model);

    final res = await http
        .post(
          Uri.parse(base),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $apiKey',
          },
          body: jsonEncode({
            'model': mdl,
            'messages': [
              {'role': 'user', 'content': prompt}
            ],
            'temperature': 0.7,
            'max_tokens': 1024,
          }),
        )
        .timeout(const Duration(seconds: 45));

    if (res.statusCode == 429) throw Exception('429 حد الطلبات');
    if (res.statusCode == 401 || res.statusCode == 403) {
      throw Exception('مفتاح ${isGrok ? 'Grok' : 'Groq'} غير صحيح.');
    }
    if (res.statusCode != 200) {
      throw Exception('API رجّع ${res.statusCode}');
    }
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    final text = data['choices']?[0]?['message']?['content'];
    if (text == null || (text as String).trim().isEmpty) {
      throw Exception('رد فاضي من الـ API.');
    }
    return text.trim();
  }

  Future<String> testConnection() =>
      generateText('Reply with one word only: OK');

  Future<List<String>> generateDreamSteps({
    required String title,
    required String description,
  }) async {
    final text = await generateText('''
أنت مخطط أهداف. حلم المستخدم: "$title". تفاصيل: "$description".
اكتب 6 خطوات زمنية عملية بالعربي المصري، كل خطوة سطر:
(يوم 1-3) فعل...
(الأسبوع 2) فعل...
بدون كلام تحفيزي فاضي.
''');
    return text
        .split('\n')
        .map((l) => l.replaceFirst(RegExp(r'^[\-\*\d\.\)\s]+'), '').trim())
        .where((l) => l.isNotEmpty)
        .toList();
  }

  Future<String> weeklyMeeting({required String weeklySummary}) =>
      generateText('''
ميتنج أسبوعي. الملخص:
$weeklySummary
بالعربي المصري: 1) إنجاز 2) مشكلة 3) خطوة واحدة للأسبوع الجاي. مختصر.
''');

  Future<String> dailyMeeting({required String dailySummary}) =>
      generateText('''
ميتنج سريع آخر اليوم:
$dailySummary
بالعربي المصري في 4 أسطر: اللي اتعمل، اللي اتأجل، حاجة واحدة بكرة.
''');

  Future<String> personalityInsight({required String profileSummary}) =>
      generateText('بيانات:\n$profileSummary\nتحليل بنّاء 5 جمل بالعربي المصري.');

  Future<String> analyzeHabitImpact({
    required String habitName,
    required bool isGood,
    required int currentStreakDays,
  }) =>
      generateText(
        'عادة ${isGood ? 'كويسة' : 'وحشة'}: "$habitName" — $currentStreakDays يوم. تأثير 3-12 شهر + نصيحة. 5 جمل مصري.',
      );

  Future<Map<String, dynamic>> generateStarterPlan({
    required Map<String, String> answers,
  }) async {
    final context =
        answers.entries.map((e) => '${e.key}: ${e.value}').join('\n');
    final text = await generateText('''
بيانات مستخدم Liv:
$context
JSON فقط:
{"good_habits":[".."],"bad_habits":[".."],"weekly_tasks":[".."],"dream_title":"..","dream_description":".."}
''');
    final cleaned = text
        .replaceFirst(RegExp(r'^```json\s*'), '')
        .replaceFirst(RegExp(r'^```\s*'), '')
        .replaceFirst(RegExp(r'\s*```$'), '')
        .trim();
    final decoded = jsonDecode(cleaned);
    if (decoded is! Map<String, dynamic>) {
      throw Exception('خطة البداية غير مفهومة.');
    }
    return decoded;
  }

  Future<String> chat({
    required String userMessage,
    required String context,
    List<Map<String, String>> history = const [],
  }) {
    final previous = history.take(6).map((m) {
      final who = m['role'] == 'user' ? 'مستخدم' : 'Liv';
      return '$who: ${m['text']}';
    }).join('\n');
    return generateText('''
أنت Liv AI. مصري، مختصر، عملي.
سياق: $context
محادثة: $previous
رسالة: $userMessage
''');
  }
}
