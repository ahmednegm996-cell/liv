/* =========================================================
   Liv — Voice commands
   Uses the browser's built-in SpeechRecognition (no server,
   no API key needed). Understands simple Arabic phrases:
     "بدأت جيم" / "خلصت جيم"     -> starts/stops a live timer
     "عملت [اسم عادة]"           -> marks a good habit done
     "عملت حاجة وحشة"            -> logs a generic bad action (-points)
     "عايز / نفسي في [كذا]"      -> adds a new dream
   ========================================================= */

let recognition = null;
let liveTimers = {}; // name -> startTime

function speechSupported(){
  return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
}

function startVoiceCommand(onResult, onEnd){
  if(!speechSupported()){
    onResult({ ok:false, message:'المتصفح ده مش بيدعم الأوامر الصوتية للأسف. جرب Chrome على الموبايل أو الكمبيوتر.' });
    onEnd && onEnd();
    return;
  }
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SR();
  recognition.lang = 'ar-EG';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.onresult = (e)=>{
    const transcript = e.results[0][0].transcript;
    const parsed = parseVoiceCommand(transcript);
    onResult(parsed);
  };
  recognition.onerror = (e)=>{
    onResult({ ok:false, message:'ملقتش صوت واضح، جرب تاني.' , raw:e.error});
  };
  recognition.onend = ()=>{ onEnd && onEnd(); };

  try{ recognition.start(); }
  catch(e){ onResult({ ok:false, message:'حصل خطأ في تشغيل الميكروفون.' }); onEnd && onEnd(); }
}

function stopVoiceCommand(){
  if(recognition){ try{ recognition.stop(); }catch(e){} }
}

function parseVoiceCommand(text){
  const t = text.trim();
  const norm = t.replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه');

  // start/stop activity timer: "بدأت جيم" / "خلصت جيم"
  let m = norm.match(/^(بدات|بدأت|هبدا)\s+(.+)/);
  if(m){
    const activity = m[2].trim();
    liveTimers[activity] = Date.now();
    return { ok:true, kind:'timer_start', activity, message:`تمام، بدأت أحسب وقت "${activity}" ⏱️` };
  }
  m = norm.match(/^(خلصت|انتهيت|وقفت)\s+(.+)/);
  if(m){
    const activity = m[2].trim();
    const start = liveTimers[activity];
    if(start){
      const mins = Math.max(1, Math.round((Date.now()-start)/60000));
      delete liveTimers[activity];
      return { ok:true, kind:'timer_end', activity, minutes:mins, message:`جامد، "${activity}" استغرق ${mins} دقيقة تقريبًا 💪` };
    }
    return { ok:true, kind:'timer_end_unknown', activity, message:`مسجلتش وقت بدايته، بس هسجل إنك خلصت "${activity}"` };
  }

  // bad action: "عملت حاجة وحشة"
  if(/عملت حاجه وحشه|عملت غلط|فشلت/.test(norm)){
    return { ok:true, kind:'bad_action', message:'تمام، هخصم شوية نقط. المرة الجاية هتبقى أحسن 🤍' };
  }

  // dream/wish: "عايز / نفسي في"
  m = norm.match(/^(عايز|عاوز|نفسي في|حلمي)\s+(.+)/);
  if(m){
    const dream = m[2].trim();
    return { ok:true, kind:'dream', dream, message:`ضفتها لأحلامك: "${dream}" 💫` };
  }

  // generic "عملت [حاجة]" -> try to match a habit name
  m = norm.match(/^(عملت|خلصت)\s+(.+)/);
  if(m){
    const activity = m[2].trim();
    return { ok:true, kind:'did_activity', activity, message:`تمام، هدور على عادة اسمها "${activity}"` };
  }

  return { ok:true, kind:'unknown', message:`سمعتك بتقول: "${t}" — بس معرفتش أعمل بيها إيه، جرب تقول "عملت [اسم العادة]" أو "بدأت [نشاط]"` };
}
