/* =========================================================
   Liv — UI rendering
   ========================================================= */

function showToast(msg){
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(showToast._t);
  showToast._t = setTimeout(()=> el.classList.add('hidden'), 2600);
}

function openModal(html){
  document.getElementById('modalSheet').innerHTML = html;
  document.getElementById('modalOverlay').classList.remove('hidden');
}
function closeModal(){
  document.getElementById('modalOverlay').classList.add('hidden');
}

/* ---------- topbar ---------- */
function renderTopbar(){
  const heartsRow = document.getElementById('heartsRow');
  heartsRow.innerHTML = [0,1,2].map(i=>{
    const filled = i < STATE.hearts;
    return `<svg class="heart-icon" viewBox="0 0 24 24"><path fill="${filled? 'var(--coral)':'var(--stroke)'}" d="M12 21s-6.7-4.3-9.3-8.2C1 10 1.6 6.6 4.4 5.1c2.2-1.2 4.7-.5 6 1.3l1.6 2.1 1.6-2.1c1.3-1.8 3.8-2.5 6-1.3 2.8 1.5 3.4 4.9 1.7 7.7C18.7 16.7 12 21 12 21Z"/></svg>`;
  }).join('');
  document.getElementById('pointsVal').textContent = STATE.points;
}

/* ---------- rings ---------- */
function renderRings(){
  const { habitsPct, timePct, moneyPct } = todayCompletionRatio();
  const circumference = 2*Math.PI*86;
  setRing('ringHabits', 86, habitsPct);
  setRing('ringTime', 64, timePct);
  setRing('ringMoney', 42, moneyPct);
  const avg = Math.round(((habitsPct+timePct+moneyPct)/3)*100);
  document.getElementById('ringsPct').textContent = toArabicPct(avg);
}
function setRing(id, r, pct){
  const c = 2*Math.PI*r;
  const el = document.getElementById(id);
  el.style.strokeDasharray = c;
  el.style.strokeDashoffset = c - c*Math.max(0,Math.min(1,pct));
}
function toArabicPct(n){
  const map = {'0':'٠','1':'١','2':'٢','3':'٣','4':'٤','5':'٥','6':'٦','7':'٧','8':'٨','9':'٩'};
  return String(n).split('').map(c=>map[c]||c).join('') + '٪';
}

/* ---------- home ---------- */
function renderHome(){
  document.getElementById('heroName').textContent = STATE.profile.name ? `يا ${STATE.profile.name} 👋` : 'يا بطل 👋';
  const hr = new Date().getHours();
  document.getElementById('heroHello').textContent = hr<12 ? 'صباح الخير' : hr<18 ? 'مساء الخير' : 'مساء النور';

  renderRings();

  const t = todayStr();
  const list = document.getElementById('todayHabitsList');
  if(!STATE.habits.length){
    list.innerHTML = `<div class="empty-state">لسه مفيش عادات مسجلة. دوس "+ عادة" وابدأ 🌱</div>`;
  } else {
    list.innerHTML = STATE.habits.map(h=>habitRowHtml(h, t)).join('');
  }

  document.getElementById('challengeText').textContent = STATE.challenge.text;
  const cbtn = document.getElementById('challengeDoneBtn');
  cbtn.textContent = STATE.challenge.done ? 'تم ✓' : 'تم التحدي ✓';
  cbtn.disabled = STATE.challenge.done;

  renderMonsterCard();
  renderWeeklyTasksHome();
}

function habitRowHtml(h, t){
  const done = !!h.history[t];
  return `
  <div class="habit-row" data-id="${h.id}">
    <div class="habit-check ${h.type} ${done?'done':''}" data-toggle="${h.id}">
      ${done ? '✓' : ''}
    </div>
    <div class="habit-body">
      <div class="habit-name">${escapeHtml(h.name)}</div>
      <div class="habit-meta">
        <span class="habit-badge ${h.type}">${h.type==='good'?'حلوة':'وحشة'}</span>
        <span>🔥 ${h.streak}</span>
      </div>
    </div>
    <div class="habit-pts ${h.type==='good' ? (done?'pos':'') : (done?'neg':'pos')}">
      ${h.type==='good' ? (done?'+':'') : (done?'-':'+')}${h.points}
    </div>
    <button class="habit-del" data-del="${h.id}">✕</button>
  </div>`;
}

function renderMonsterCard(){
  const card = document.getElementById('monsterCard');
  if(!STATE.monster){
    const badHabits = STATE.habits.filter(h=>h.type==='bad');
    if(!badHabits.length){
      card.innerHTML = `<div class="empty-state">ضيف عادة وحشة الأول عشان تقدر تحدد وحش الشهر</div>`;
      return;
    }
    card.innerHTML = `
      <div class="monster-title">مفيش وحش متحدد للشهر ده</div>
      <div class="monster-sub">اختر عادة وحشة تحاربها الشهر ده. لو خلصت الشهر من غيرها، هتاخد نقط كتير 🏆</div>
      <select class="select" id="monsterSelect">
        ${badHabits.map(h=>`<option value="${h.id}">${escapeHtml(h.name)}</option>`).join('')}
      </select>
      <button class="btn btn-primary btn-block" id="setMonsterBtn">حدد وحش الشهر</button>
    `;
    return;
  }
  const prog = monsterProgress();
  if(!prog){ card.innerHTML=''; return; }
  const pct = Math.round((prog.cleanDays/prog.totalDays)*100);
  card.innerHTML = `
    <div class="monster-title">🎯 ${escapeHtml(prog.habit.name)}</div>
    <div class="monster-sub">${prog.cleanDays} من ${prog.totalDays} يوم نضيف من ${escapeHtml(prog.habit.name)} الشهر ده</div>
    <div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div>
    <div class="row-between" style="margin-top:10px">
      <span class="muted-sm">${pct}% مكتمل</span>
      <button class="link-btn" id="clearMonsterBtn">تغيير الوحش</button>
    </div>
  `;
}

function renderWeeklyTasksHome(){
  const list = document.getElementById('weeklyTasksList');
  const tasks = currentWeekTasks();
  if(!tasks.length){
    list.innerHTML = `<div class="empty-state">مفيش مهام للأسبوع ده لسه</div>`;
    return;
  }
  list.innerHTML = tasks.map(t=>`
    <div class="task-row ${t.done?'done':''}" data-id="${t.id}">
      <div class="checkbox ${t.done?'done':''}" data-toggletask="${t.id}">${t.done?'✓':''}</div>
      <div class="task-text">${escapeHtml(t.text)}</div>
      <button class="habit-del" data-deltask="${t.id}">✕</button>
    </div>
  `).join('');
}

/* ---------- habits page ---------- */
function renderHabitsPage(filter='all'){
  const list = document.getElementById('allHabitsList');
  const t = todayStr();
  let items = STATE.habits;
  if(filter==='good') items = items.filter(h=>h.type==='good');
  if(filter==='bad') items = items.filter(h=>h.type==='bad');
  list.innerHTML = items.length
    ? items.map(h=>habitRowHtml(h,t)).join('')
    : `<div class="empty-state">مفيش عادات في القسم ده</div>`;

  const select = document.getElementById('predictHabitSelect');
  select.innerHTML = STATE.habits.length
    ? STATE.habits.map(h=>`<option value="${h.id}">${escapeHtml(h.name)}</option>`).join('')
    : `<option value="">مفيش عادات لسه</option>`;

  const trendSelect = document.getElementById('trendHabitSelect');
  if(trendSelect){
    trendSelect.innerHTML = select.innerHTML;
  }
  document.getElementById('predictResult').classList.add('hidden');
}

/* ---------- goals page ---------- */
function renderGoalsPage(){
  const goals = currentMonthGoals();
  document.getElementById('monthlyGoalsList').innerHTML = goals.length ? goals.map(g=>`
    <div class="goal-card">
      <div class="goal-title">${escapeHtml(g.text)}</div>
      <div class="goal-pct"><span>التقدم</span><span>${g.progress}%</span></div>
      <input type="range" class="range" min="0" max="100" value="${g.progress}" data-goal="${g.id}">
      <button class="link-btn" style="margin-top:8px" data-delgoal="${g.id}">حذف</button>
    </div>
  `).join('') : `<div class="empty-state">لسه مفيش أهداف للشهر ده</div>`;

  document.getElementById('savingsList').innerHTML = STATE.savings.length ? STATE.savings.map(s=>{
    const pct = s.target ? Math.min(100, Math.round(s.saved/s.target*100)) : 0;
    return `
    <div class="saving-card">
      <div class="saving-top">
        <span class="saving-name">${escapeHtml(s.name)}</span>
        <span class="saving-amt">${s.saved} / ${s.target} ج.م</span>
      </div>
      <div class="progress-bar"><div class="progress-fill" style="width:${pct}%; background:linear-gradient(90deg,var(--blue),var(--teal))"></div></div>
      <div class="saving-add">
        <input type="number" class="input-inline" placeholder="مبلغ" id="add-${s.id}" style="flex:1;width:auto">
        <button class="btn btn-small btn-primary" data-addsave="${s.id}">ضيف</button>
        <button class="habit-del" data-delsave="${s.id}">✕</button>
      </div>
    </div>`;
  }).join('') : `<div class="empty-state">لسه مفيش أهداف ادخار</div>`;

  document.getElementById('dreamsList').innerHTML = STATE.dreams.length ? STATE.dreams.map(d=>`
    <div class="dream-card">
      <div class="row-between" style="margin-bottom:0">
        <div class="dream-text">💭 ${escapeHtml(d.text)}</div>
        <button class="habit-del" data-deldream="${d.id}">✕</button>
      </div>
      ${d.steps.length ? `
        <ol class="dream-steps">
          ${d.steps.map((s,i)=>`<li class="dream-step"><span class="dream-step-num">${i+1}</span><span>${escapeHtml(s)}</span></li>`).join('')}
        </ol>
      ` : `<button class="btn btn-secondary btn-block" data-plandream="${d.id}">اطلب خطة من الذكاء الاصطناعي 🪄</button>`}
    </div>
  `).join('') : `<div class="empty-state">اكتب أول حلم ليك وهنحوله لخطة</div>`;
}

/* ---------- life page (time/money/health) ---------- */
function renderLifePage(){
  document.getElementById('socialMinutesInput').value = STATE.social[todayStr()] ?? '';
  document.getElementById('friendsHoursInput').value = STATE.friendsHours[isoWeek()] ?? '';
  document.getElementById('sleepHoursInput').value = STATE.sleep[todayStr()] ?? '';

  document.getElementById('subsList').innerHTML = STATE.subscriptions.length ? STATE.subscriptions.map(s=>`
    <div class="sub-row">
      <span>${escapeHtml(s.name)}</span>
      <div style="display:flex;align-items:center;gap:10px">
        <strong>${s.cost} ج.م</strong>
        <button class="habit-del" data-delsub="${s.id}">✕</button>
      </div>
    </div>
  `).join('') : `<div class="empty-state">لسه مفيش اشتراكات مسجلة</div>`;
  document.getElementById('subsTotal').textContent = subscriptionsTotal() + ' ج.م';

  renderJobCard();
  renderSleepFeedback();
}

function renderJobCard(){
  const card = document.getElementById('jobCard');
  const t = todayStr();
  const entry = STATE.job.entries[t] || { count:0, earnings:0 };
  const label = STATE.profile.jobLabel || 'شغلك';
  card.innerHTML = `
    <div class="row-between"><span class="muted-sm">${escapeHtml(label)} — مهام/رحلات النهاردة</span>
      <input type="number" class="input-inline" id="jobCountInput" value="${entry.count}"></div>
    <div class="row-between"><span class="muted-sm">دخل النهاردة (ج.م)</span>
      <input type="number" class="input-inline" id="jobEarningsInput" value="${entry.earnings}"></div>
    <button class="btn btn-small btn-primary" id="saveJobBtn">حفظ</button>
  `;
}

function renderSleepFeedback(){
  const h = STATE.sleep[todayStr()];
  const el = document.getElementById('sleepFeedback');
  if(h===undefined){ el.textContent=''; return; }
  if(h < 5) el.textContent = '😴 نوم قليل جدًا، حاول تعوّض بدري.';
  else if(h < 7) el.textContent = '🙂 مقبول، بس ممكن تحسّنه شوية.';
  else if(h <= 9) el.textContent = '✅ عدد ساعات ممتاز!';
  else el.textContent = '💤 نوم زيادة عن اللزوم، جرب تظبط المواعيد.';
}

/* ---------- me page ---------- */
function renderMePage(){
  const p = STATE.profile;
  document.getElementById('profileCard').innerHTML = `
    <div class="profile-row"><span>الاسم</span><span>${escapeHtml(p.name)||'—'}</span></div>
    <div class="profile-row"><span>الطول</span><span>${p.height?p.height+' سم':'—'}</span></div>
    <div class="profile-row"><span>الوزن</span><span>${p.weight?p.weight+' كجم':'—'}</span></div>
    <div class="profile-row"><span>الشغل</span><span>${escapeHtml(p.jobLabel)||'—'}</span></div>
    <div class="profile-row"><span>الهوايات</span><span>${escapeHtml(p.hobbies)||'—'}</span></div>
    <div class="profile-row"><span>نبذة</span><span>${escapeHtml(p.bio)||'—'}</span></div>
  `;
  document.getElementById('apiKeyInput').value = STATE.apiKey || '';
  document.getElementById('apiKeyStatus').textContent = STATE.apiKey ? '✅ المفتاح متسجل' : 'لسه معملتش ربط بمفتاح Gemini';
  document.getElementById('meAiResult').classList.add('hidden');
}

/* ---------- helpers ---------- */
function escapeHtml(s){
  if(s===undefined || s===null) return '';
  return String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function showAiLoading(el){
  el.classList.remove('hidden');
  el.classList.add('loading');
  el.innerHTML = `<span class="ai-badge">✨ Liv AI بيفكر…</span>جاري تحليل بياناتك…`;
}
function showAiResult(el, text){
  el.classList.remove('loading');
  el.innerHTML = `<span class="ai-badge">✨ Liv AI</span>${escapeHtml(text)}`;
}
function showAiError(el, err){
  el.classList.remove('loading');
  el.innerHTML = `<span class="ai-badge" style="color:var(--coral)">⚠️</span>${escapeHtml(aiErrorMessage(err))}`;
}

function renderAll(){
  renderTopbar();
  renderHome();
  renderHabitsPage(document.querySelector('.tab-sub.active')?.dataset.f || 'all');
  renderGoalsPage();
  renderLifePage();
  renderMePage();
}
