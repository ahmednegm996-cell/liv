/* =========================================================
   Liv — Gemini AI layer
   All calls go directly from the browser to Google's Gemini
   API using the user's own free API key (stored locally only).
   ========================================================= */

const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/models/';

async function callGemini(prompt, system){
  const key = STATE.apiKey;
  if(!key){
    throw new Error('NO_KEY');
  }
  const model = STATE.aiModel || 'gemini-2.5-flash';
  const url = `${GEMINI_BASE}${model}:generateContent?key=${encodeURIComponent(key)}`;

  const body = {
    contents: [{ role:'user', parts:[{ text: prompt }] }],
    generationConfig: { temperature: 0.8, maxOutputTokens: 700 }
  };
  if(system){
    body.systemInstruction = { parts:[{ text: system }] };
  }

  const res = await fetch(url, {
    method:'POST',
    headers:{ 'Content-Type':'application/json' },
    body: JSON.stringify(body)
  });

  if(!res.ok){
    const errText = await res.text().catch(()=> '');
    throw new Error('API_ERROR: ' + res.status + ' ' + errText.slice(0,200));
  }
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.map(p=>p.text).join('\n') || '';
  if(!text) throw new Error('EMPTY_RESPONSE');
  return text.trim();
}

const LIV_SYSTEM = `أنت "Liv"، مساعد ذكاء اصطناعي داخل تطبيق شخصي لإدارة الحياة (عادات، وقت، فلوس، صحة، أحلام).
اتكلم دايمًا بالعربية المصرية العامية، بأسلوب صديق داعم وصريح مش متملق، جمل قصيرة وواضحة، من غير مقدمات طويلة.
استخدم الأرقام والبيانات اللي هتتبعتلك فعليًا، ومتخترعش معلومات مش موجودة. لو البيانات قليلة قول كده بصراحة واقترح يتابع كام يوم كمان.`;

/* ---------- feature 1: habit outcome prediction ---------- */
async function aiPredictHabit(habit){
  const rate7 = habitCompletionRate(habit, 7);
  const rate30 = habitCompletionRate(habit, 30);
  const kind = habit.type==='good' ? 'عادة حلوة عايز يكملها' : 'عادة وحشة عايز يبطلها';
  const prompt = `العادة: "${habit.name}" — ${kind}.
الالتزام آخر 7 أيام: ${rate7}%.
الالتزام آخر 30 يوم: ${rate30}%.
أطول سلسلة (Streak): ${habit.best} يوم. السلسلة الحالية: ${habit.streak} يوم.

اكتب تحليل حقيقي مبني على الأرقام دي (مش كلام عام):
1) لو استمر بنفس المعدل ده 30 يوم جاية، هيوصل فين؟
2) لو حسّن الالتزام 20%، الفرق هيبان إزاي بعد شهر؟
3) نصيحة عملية واحدة يقدر يطبقها بكرة الصبح بالظبط.
خليه مختصر، 5 أسطر بحد أقصى، من غير عناوين رقمية ظاهرة.`;
  return callGemini(prompt, LIV_SYSTEM);
}

/* ---------- feature 2: dream -> actionable steps ---------- */
async function aiDreamSteps(dreamText, profile){
  const prompt = `حلم المستخدم: "${dreamText}".
معلومات عنه: ${profile.jobLabel || 'مش محدد شغل'}، هوايات: ${profile.hobbies || 'مش محدد'}.

قسّم الحلم ده لخطوات واضحة ومنطقية وقابلة للتنفيذ، مرتبة بالترتيب الصح (من أول خطوة للأخيرة).
من 5 لـ 7 خطوات بالظبط. كل خطوة سطر واحد بس، عملي ومحدد (مش كلام عام زي "اجتهد" أو "آمن بنفسك").
رجّع النتيجة كـ JSON array of strings بس، من غير أي كلام تاني، بالشكل ده بالظبط:
["الخطوة الأولى", "الخطوة الثانية", ...]`;
  const raw = await callGemini(prompt, LIV_SYSTEM);
  return parseJsonArray(raw);
}

function parseJsonArray(raw){
  try{
    const match = raw.match(/\[[\s\S]*\]/);
    if(match) return JSON.parse(match[0]);
  }catch(e){ /* fall through */ }
  // fallback: split lines
  return raw.split('\n').map(l=>l.replace(/^[-*\d.)\s]+/, '').trim()).filter(Boolean).slice(0,7);
}

/* ---------- feature 3: social media time -> alternative uses ---------- */
async function aiSocialInsight(minutes){
  const prompt = `المستخدم قعد ${minutes} دقيقة على السوشيال ميديا النهاردة.
اكتب له بشكل مباشر وودود (مش لوم): إيه اللي كان ممكن يعمله بالوقت ده بالظبط (مثال: كام صفحة كان ممكن يقرأ، كام دقيقة رياضة، كام كلمة لغة جديدة يتعلمها) — استخدم أرقام تقريبية واقعية.
سطرين لـ 3 بس.`;
  return callGemini(prompt, LIV_SYSTEM);
}

/* ---------- feature 4: trend projection (week/month/year) ---------- */
async function aiTrendProjection(habit, range){
  const days = range==='week' ? 7 : range==='month' ? 30 : 365;
  const sample = range==='week' ? 14 : range==='month' ? 30 : 90;
  const rate = habitCompletionRate(habit, Math.min(sample, 90));
  const rangeLabel = range==='week' ? 'أسبوع' : range==='month' ? 'شهر' : 'سنة';
  const kind = habit.type==='good' ? 'عادة حلوة' : 'عادة وحشة';
  const prompt = `العادة "${habit.name}" (${kind}) بمعدل التزام حالي ${rate}%.
لو استمر المستخدم بنفس المعدل ده لمدة ${rangeLabel} (${days} يوم) قدام، وصف له بشكل واقعي وملموس:
- شكل حياته/جسمه/مزاجه هيبقى إزاي (حسب نوع العادة)
- رقم تقريبي (مثلاً عدد مرات الالتزام المتوقعة من أصل ${days})
اكتب بأسلوب قصصي قصير مش نقط، فقرة واحدة من 3-4 أسطر.`;
  return callGemini(prompt, LIV_SYSTEM);
}

/* ---------- feature 5: weekly AI meeting ---------- */
async function aiWeeklyMeeting(){
  const habitsSummary = STATE.habits.map(h=>{
    const r7 = habitCompletionRate(h,7);
    return `${h.name} (${h.type==='good'?'حلوة':'وحشة'}): ${r7}% آخر أسبوع`;
  }).join('\n') || 'مفيش عادات متسجلة لسه';

  const tasks = currentWeekTasks();
  const tasksDone = tasks.filter(t=>t.done).length;
  const goals = currentMonthGoals();

  const prompt = `ميتنج أسبوعي مع المستخدم. البيانات:
العادات: 
${habitsSummary}

مهام الأسبوع: ${tasksDone}/${tasks.length} خلصانة.
أهداف الشهر: ${goals.map(g=>`${g.text} (${g.progress}%)`).join('، ') || 'لا يوجد'}.
النقاط الحالية: ${STATE.points}. القلوب المتبقية النهاردة: ${STATE.hearts}/3.

اتكلم معاه زي كوتش شخصي في جلسة أسبوعية:
1) إيه أكتر حاجة لاحظتها إيجابية.
2) إيه المشكلة الأكبر اللي واضحة من الأرقام، وسبب محتمل ليها.
3) اقتراح واحد بسيط ومحدد يطبقه الأسبوع الجاي.
كلام دافئ وصريح، من غير وعظ زيادة، 5-6 أسطر.`;
  return callGemini(prompt, LIV_SYSTEM);
}

/* ---------- feature 6: personality analysis ---------- */
async function aiPersonalityAnalysis(){
  const goodHabits = STATE.habits.filter(h=>h.type==='good').map(h=>h.name).join('، ') || 'لا يوجد';
  const badHabits = STATE.habits.filter(h=>h.type==='bad').map(h=>h.name).join('، ') || 'لا يوجد';
  const dreams = STATE.dreams.map(d=>d.text).join('، ') || 'لا يوجد';
  const prompt = `بناءً على البيانات دي عن المستخدم:
عادات بيحاول يبنيها: ${goodHabits}
عادات بيحاول يتخلص منها: ${badHabits}
أحلامه: ${dreams}
هوايات: ${STATE.profile.hobbies || 'غير محدد'}
شغله: ${STATE.profile.jobLabel || 'غير محدد'}

اكتب تحليل شخصية قصير وودود (مش تشخيص نفسي رسمي، ده تأمل شخصي بس) عن:
- إيه اللي شكله بيحرك المستخدم ده (motivation)
- إيه نقطة قوته الظاهرة من اختياراته
- إيه حاجة واحدة ممكن تعطله لو محلّهاش
5 أسطر بحد أقصى.`;
  return callGemini(prompt, LIV_SYSTEM);
}

/* ---------- feature 7: AI task report ---------- */
async function aiTaskReport(){
  const t = todayStr();
  const doneToday = STATE.habits.filter(h=> h.type==='good' ? h.history[t] : h.history[t]===false).length;
  const tasks = currentWeekTasks();
  const prompt = `تقرير سريع عن أداء اليوم والأسبوع:
عادات خلصانة النهاردة: ${doneToday} من ${STATE.habits.length}.
مهام الأسبوع: ${tasks.filter(x=>x.done).length} من ${tasks.length}.
النقاط: ${STATE.points}. القلوب: ${STATE.hearts}/3.
اكتب تقرير مختصر جدًا (3 أسطر) بأسلوب مباشر يقول للمستخدم هو ماشي كويس ولا محتاج يشد الحيل.`;
  return callGemini(prompt, LIV_SYSTEM);
}

/* ---------- error helper ---------- */
function aiErrorMessage(err){
  const msg = String(err && err.message || err);
  if(msg === 'NO_KEY') return 'محتاج تحط مفتاح Gemini API الأول من صفحة "أنا" ⚙️ (مجاني من aistudio.google.com/apikey)';
  if(msg.startsWith('API_ERROR')) return 'في مشكلة في الاتصال بـ Gemini. اتأكد إن المفتاح صحيح ولسه شغال، أو حاول تاني كمان شوية.';
  return 'حصل خطأ غير متوقع. جرب تاني.';
}
