/* =========================================================
   Liv — State management
   Single source of truth, persisted to localStorage.
   ========================================================= */
const LIV_KEY = 'liv_state_v1';

function todayStr(d = new Date()){
  return d.toISOString().slice(0,10);
}
function uid(){
  return Date.now().toString(36) + Math.random().toString(36).slice(2,7);
}
function isoWeek(d = new Date()){
  const date = new Date(d.getTime());
  date.setHours(0,0,0,0);
  date.setDate(date.getDate() + 3 - (date.getDay()+6)%7);
  const week1 = new Date(date.getFullYear(),0,4);
  return date.getFullYear()+'-W'+(1+Math.round(((date-week1)/86400000-3+(week1.getDay()+6)%7)/7));
}

function defaultState(){
  return {
    version: 1,
    createdAt: todayStr(),
    profile: {
      name: '',
      height: null,
      weight: null,
      hobbies: '',
      jobType: 'custom',
      jobLabel: '',
      bio: ''
    },
    apiKey: '',
    aiModel: 'gemini-2.5-flash',
    points: 0,
    hearts: 3,
    heartsDate: todayStr(),
    habits: [],          // {id,name,type:'good'|'bad',points,streak,best,history:{date:bool},createdAt}
    monster: null,        // {id,habitId,name,startedMonth,cleared}
    weeklyTasks: [],       // {id,text,done,week}
    monthlyGoals: [],      // {id,text,progress,month}
    savings: [],           // {id,name,target,saved}
    subscriptions: [],     // {id,name,cost}
    dreams: [],             // {id,text,steps:[],createdAt}
    sleep: {},              // date -> hours
    social: {},              // date -> minutes
    friendsHours: {},         // isoWeek -> hours
    job: { entries: {} },      // date -> {count, earnings, note}
    challenge: { date:'', text:'', done:false },
    weeklyMeeting: { lastWeek:'', notes:[] },
    lastActiveDate: todayStr()
  };
}

let STATE = load();

function load(){
  try{
    const raw = localStorage.getItem(LIV_KEY);
    if(!raw) return defaultState();
    const parsed = JSON.parse(raw);
    return Object.assign(defaultState(), parsed);
  }catch(e){
    console.warn('Liv: could not load state, starting fresh', e);
    return defaultState();
  }
}

function save(){
  localStorage.setItem(LIV_KEY, JSON.stringify(STATE));
}

/* ---------- daily rollover: hearts reset, streak breaks, monster progress ---------- */
function rollover(){
  const t = todayStr();
  if(STATE.heartsDate !== t){
    STATE.hearts = 3;
    STATE.heartsDate = t;
  }
  if(STATE.challenge.date !== t){
    STATE.challenge = { date:t, text: pickChallenge(), done:false };
  }
  STATE.lastActiveDate = t;
  save();
}

function pickChallenge(){
  const pool = [
    'اشرب 8 أكواب مياه النهاردة',
    'امشي 20 دقيقة من غير موبايل',
    'اكتب 3 حاجات انت شاكر عليها',
    'قفل السوشيال ميديا لمدة ساعتين متواصلة',
    'ابعت رسالة تقدير لحد قريب منك',
    'رتّب مكان شغلك أو غرفتك 10 دقايق',
    'اتعلم 5 كلمات جديدة في لغة بتتعلمها',
    'نام قبل الساعة 12 بالليل',
    'اعمل 15 دقيقة رياضة',
    'اكتب هدفك لبكرة قبل ما تنام',
    'اتصل بصاحبك اللي مكلمتوش بقالك وقت',
    'سيب المكيّف/الموبايل وقعد في الشمس 10 دقايق'
  ];
  return pool[Math.floor(Math.random()*pool.length)];
}

/* ---------- points / hearts ---------- */
function addPoints(n){
  STATE.points = Math.max(0, STATE.points + n);
  save();
}
function loseHeart(){
  STATE.hearts = Math.max(0, STATE.hearts - 1);
  save();
}
function gainHeart(){
  STATE.hearts = Math.min(3, STATE.hearts + 1);
  save();
}

/* ---------- habits ---------- */
function addHabit(name, type){
  const h = { id: uid(), name, type, points: type==='good'?10:10, streak:0, best:0, history:{}, createdAt: todayStr() };
  STATE.habits.push(h);
  save();
  return h;
}
function deleteHabit(id){
  STATE.habits = STATE.habits.filter(h=>h.id!==id);
  if(STATE.monster && STATE.monster.habitId===id) STATE.monster=null;
  save();
}
function toggleHabitToday(id){
  const h = STATE.habits.find(x=>x.id===id);
  if(!h) return null;
  const t = todayStr();
  const wasDone = !!h.history[t];
  const nowDone = !wasDone;
  h.history[t] = nowDone;

  if(h.type==='good'){
    if(nowDone){
      addPoints(h.points);
      h.streak += 1;
      h.best = Math.max(h.best, h.streak);
    } else {
      addPoints(-h.points);
      h.streak = Math.max(0, h.streak-1);
    }
  } else { // bad habit -> "done" means relapsed today
    if(nowDone){
      addPoints(-h.points);
      loseHeart();
      h.streak = 0;
    } else {
      addPoints(h.points);
      h.streak += 1;
      h.best = Math.max(h.best, h.streak);
    }
  }
  save();
  return h;
}
function habitHistoryArray(h, days){
  const out = [];
  const d = new Date();
  for(let i=days-1;i>=0;i--){
    const dd = new Date(d.getTime());
    dd.setDate(dd.getDate()-i);
    const key = todayStr(dd);
    out.push({ date:key, value: h.history[key] ? 1 : 0 });
  }
  return out;
}
function habitCompletionRate(h, days){
  const arr = habitHistoryArray(h, days);
  const denom = arr.length || 1;
  const good = h.type==='good'
    ? arr.filter(a=>a.value).length
    : arr.filter(a=>!a.value).length; // for bad habits, "good" = not relapsed
  return Math.round((good/denom)*100);
}

/* ---------- monster of the month ---------- */
function currentMonthKey(){
  return todayStr().slice(0,7);
}
function setMonster(habitId){
  const h = STATE.habits.find(x=>x.id===habitId);
  if(!h) return;
  STATE.monster = { id: uid(), habitId, name:h.name, startedMonth: currentMonthKey(), cleared:false };
  save();
}
function monsterProgress(){
  if(!STATE.monster) return null;
  const h = STATE.habits.find(x=>x.id===STATE.monster.habitId);
  if(!h) return null;
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const daysInSoFar = Math.floor((now - monthStart)/86400000)+1;
  let cleanDays = 0;
  for(let i=0;i<daysInSoFar;i++){
    const d = new Date(monthStart.getTime()); d.setDate(d.getDate()+i);
    const key = todayStr(d);
    if(!h.history[key]) cleanDays++;
  }
  return { habit:h, cleanDays, totalDays: daysInSoFar };
}

/* ---------- weekly tasks ---------- */
function addWeeklyTask(text){
  STATE.weeklyTasks.push({ id: uid(), text, done:false, week: isoWeek() });
  save();
}
function toggleWeeklyTask(id){
  const t = STATE.weeklyTasks.find(x=>x.id===id);
  if(!t) return;
  t.done = !t.done;
  addPoints(t.done ? 15 : -15);
  save();
}
function deleteWeeklyTask(id){
  STATE.weeklyTasks = STATE.weeklyTasks.filter(x=>x.id!==id);
  save();
}
function currentWeekTasks(){
  return STATE.weeklyTasks.filter(t=>t.week===isoWeek());
}

/* ---------- monthly goals ---------- */
function addGoal(text){
  STATE.monthlyGoals.push({ id: uid(), text, progress:0, month: currentMonthKey() });
  save();
}
function setGoalProgress(id, val){
  const g = STATE.monthlyGoals.find(x=>x.id===id);
  if(!g) return;
  g.progress = Math.max(0, Math.min(100, val));
  save();
}
function deleteGoal(id){
  STATE.monthlyGoals = STATE.monthlyGoals.filter(x=>x.id!==id);
  save();
}
function currentMonthGoals(){
  return STATE.monthlyGoals.filter(g=>g.month===currentMonthKey());
}

/* ---------- savings ---------- */
function addSaving(name, target){
  STATE.savings.push({ id: uid(), name, target: Number(target)||0, saved:0 });
  save();
}
function addToSaving(id, amount){
  const s = STATE.savings.find(x=>x.id===id);
  if(!s) return;
  s.saved = Math.max(0, s.saved + Number(amount));
  save();
}
function deleteSaving(id){
  STATE.savings = STATE.savings.filter(x=>x.id!==id);
  save();
}

/* ---------- subscriptions ---------- */
function addSubscription(name, cost){
  STATE.subscriptions.push({ id: uid(), name, cost: Number(cost)||0 });
  save();
}
function deleteSubscription(id){
  STATE.subscriptions = STATE.subscriptions.filter(x=>x.id!==id);
  save();
}
function subscriptionsTotal(){
  return STATE.subscriptions.reduce((s,x)=>s+x.cost,0);
}

/* ---------- dreams ---------- */
function addDream(text){
  const d = { id: uid(), text, steps: [], createdAt: todayStr() };
  STATE.dreams.push(d);
  save();
  return d;
}
function setDreamSteps(id, steps){
  const d = STATE.dreams.find(x=>x.id===id);
  if(!d) return;
  d.steps = steps;
  save();
}
function deleteDream(id){
  STATE.dreams = STATE.dreams.filter(x=>x.id!==id);
  save();
}

/* ---------- sleep / social / friends / job ---------- */
function setSleep(hours){
  STATE.sleep[todayStr()] = Number(hours);
  save();
}
function setSocial(minutes){
  STATE.social[todayStr()] = Number(minutes);
  save();
}
function setFriendsHours(hours){
  STATE.friendsHours[isoWeek()] = Number(hours);
  save();
}
function addJobEntry(patch){
  const t = todayStr();
  const cur = STATE.job.entries[t] || { count:0, earnings:0, note:'' };
  STATE.job.entries[t] = Object.assign(cur, patch);
  save();
}

/* ---------- today snapshot / rings ---------- */
function todayHabits(){
  return STATE.habits;
}
function todayCompletionRatio(){
  const t = todayStr();
  const habitsCount = STATE.habits.length;
  const habitsDone = STATE.habits.filter(h=>{
    const v = h.history[t];
    return h.type==='good' ? !!v : v===false || v===undefined;
  }).length;
  const habitsPct = habitsCount ? habitsDone/habitsCount : 0;

  const socialMin = STATE.social[t] ?? null;
  const timePct = socialMin===null ? 0.5 : Math.max(0, Math.min(1, 1 - socialMin/180));

  const savingsPct = STATE.savings.length
    ? STATE.savings.reduce((s,x)=> s + Math.min(1, x.target? x.saved/x.target : 0), 0)/STATE.savings.length
    : 0.3;

  return { habitsPct, timePct, moneyPct: savingsPct };
}

/* ---------- import / export ---------- */
function exportState(){
  return JSON.stringify(STATE, null, 2);
}
function importState(json){
  const parsed = JSON.parse(json);
  STATE = Object.assign(defaultState(), parsed);
  save();
}
function resetState(){
  STATE = defaultState();
  save();
}
