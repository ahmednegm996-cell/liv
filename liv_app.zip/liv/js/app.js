/* =========================================================
   Liv — App controller
   ========================================================= */

document.addEventListener('DOMContentLoaded', init);

function init(){
  rollover();
  if(!STATE.profile.name){
    runOnboarding();
  } else {
    boot();
  }
}

function boot(){
  document.getElementById('onboarding').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
  renderAll();
  wireNav();
  wireHome();
  wireHabits();
  wireGoals();
  wireLife();
  wireMe();
  wireModalClose();
  wireVoice();
}

/* =========================================================
   ONBOARDING
   ========================================================= */
const ONB_STEPS = [
  { key:'name', title:'إيه اسمك؟', sub:'عشان Liv يكلمك بيه', field:`<input class="input-full" id="onbName" placeholder="اسمك">` },
  { key:'stats', title:'كام معلومة سريعة', sub:'اختياري، بس بيساعد التحليل يكون أدق', field:`
      <label class="field-label">الطول (سم)</label>
      <input class="input-full" id="onbHeight" type="number" placeholder="مثلاً 175">
      <div style="height:10px"></div>
      <label class="field-label">الوزن (كجم)</label>
      <input class="input-full" id="onbWeight" type="number" placeholder="مثلاً 78">` },
  { key:'job', title:'شغلك إيه؟', sub:'هنخصص متابعة يومية على حسب شغلك', field:`
      <input class="input-full" id="onbJob" placeholder="مثلاً: سائق أوبر / سيلز عقارات / مبرمج">` },
  { key:'hobbies', title:'هواياتك إيه؟', sub:'', field:`<input class="input-full" id="onbHobbies" placeholder="مثلاً: قراءة، جيم، جيمنج">` },
  { key:'dream', title:'إيه أكبر حلم بتحاول توصله دلوقتي؟', sub:'ممكن تضيف غيره بعدين', field:`<textarea class="input-full" id="onbDream" placeholder="اكتب حلمك هنا"></textarea>` },
  { key:'key', title:'اربط مفتاح Gemini (اختياري)', sub:'مجاني من aistudio.google.com/apikey — ده اللي بيشغّل كل ميزات الذكاء الاصطناعي. ممكن تضيفه بعدين من صفحة "أنا".', field:`<input class="input-full" id="onbKey" type="password" placeholder="مفتاح Gemini API">` },
];
let onbIndex = 0;

function runOnboarding(){
  document.getElementById('onboarding').classList.remove('hidden');
  const wrap = document.getElementById('onb-steps');
  wrap.innerHTML = ONB_STEPS.map((s,i)=>`
    <div class="onb-step ${i===0?'active':''}" data-i="${i}">
      <h3>${s.title}</h3>
      ${s.sub?`<p class="sub">${s.sub}</p>`:''}
      ${s.field}
    </div>
  `).join('');
  const dots = document.getElementById('onbDots');
  dots.innerHTML = ONB_STEPS.map((_,i)=>`<span class="${i===0?'active':''}"></span>`).join('');

  document.getElementById('onbNext').onclick = onbNext;
  document.getElementById('onbBack').onclick = onbBack;
}

function onbNext(){
  saveOnbStep(onbIndex);
  if(onbIndex < ONB_STEPS.length-1){
    onbIndex++;
    updateOnbUI();
  } else {
    finishOnboarding();
  }
}
function onbBack(){
  if(onbIndex>0){ onbIndex--; updateOnbUI(); }
}
function updateOnbUI(){
  document.querySelectorAll('.onb-step').forEach((el,i)=> el.classList.toggle('active', i===onbIndex));
  document.querySelectorAll('#onbDots span').forEach((el,i)=> el.classList.toggle('active', i===onbIndex));
  document.getElementById('onbBack').style.visibility = onbIndex===0 ? 'hidden':'visible';
  document.getElementById('onbNext').textContent = onbIndex===ONB_STEPS.length-1 ? 'يلا نبدأ 🚀' : 'التالي';
}
function saveOnbStep(i){
  const key = ONB_STEPS[i].key;
  if(key==='name') STATE.profile.name = document.getElementById('onbName').value.trim();
  if(key==='stats'){
    STATE.profile.height = Number(document.getElementById('onbHeight').value)||null;
    STATE.profile.weight = Number(document.getElementById('onbWeight').value)||null;
  }
  if(key==='job') STATE.profile.jobLabel = document.getElementById('onbJob').value.trim();
  if(key==='hobbies') STATE.profile.hobbies = document.getElementById('onbHobbies').value.trim();
  if(key==='dream'){
    const v = document.getElementById('onbDream').value.trim();
    if(v) addDream(v);
  }
  if(key==='key') STATE.apiKey = document.getElementById('onbKey').value.trim();
  save();
}
function finishOnboarding(){
  if(!STATE.profile.name) STATE.profile.name = 'صديقي';
  save();
  boot();
}

/* =========================================================
   NAVIGATION
   ========================================================= */
const PAGE_TITLES = { home:'الرئيسية', habits:'العادات', goals:'الأهداف', life:'الوقت والمال', me:'أنا' };

function wireNav(){
  document.querySelectorAll('.tab-btn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const page = btn.dataset.page;
      document.querySelectorAll('.tab-btn').forEach(b=>b.classList.toggle('active', b===btn));
      document.querySelectorAll('.page').forEach(p=>p.classList.add('hidden'));
      document.getElementById('page-'+page).classList.remove('hidden');
      document.getElementById('pageTitle').textContent = PAGE_TITLES[page];
      window.scrollTo(0,0);
    });
  });
}

function wireModalClose(){
  document.getElementById('modalOverlay').addEventListener('click', (e)=>{
    if(e.target.id==='modalOverlay') closeModal();
  });
}

/* =========================================================
   HOME
   ========================================================= */
function wireHome(){
  document.getElementById('content').addEventListener('click', handleContentClick);

  document.getElementById('addHabitQuick').addEventListener('click', openAddHabitModal);

  document.getElementById('challengeDoneBtn').addEventListener('click', ()=>{
    if(STATE.challenge.done) return;
    STATE.challenge.done = true;
    addPoints(20);
    save();
    renderAll();
    showToast('تحدي اليوم خلص! +20 نقطة 🎉');
  });

  document.getElementById('addWeeklyTaskBtn').addEventListener('click', ()=>{
    openModal(`
      <div class="modal-title">مهمة جديدة للأسبوع</div>
      <input class="input-full" id="newTaskInput" placeholder="اكتب المهمة">
      <div class="modal-actions">
        <button class="btn btn-ghost" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" id="saveTaskBtn">إضافة</button>
      </div>
    `);
    document.getElementById('saveTaskBtn').onclick = ()=>{
      const v = document.getElementById('newTaskInput').value.trim();
      if(!v) return;
      addWeeklyTask(v);
      closeModal();
      renderAll();
      showToast('اتضافت المهمة ✅');
    };
  });
}

/* delegated clicks across the whole content area (habit toggles, deletes, etc.) */
function handleContentClick(e){
  const toggle = e.target.closest('[data-toggle]');
  if(toggle){
    const h = toggleHabitToday(toggle.dataset.toggle);
    renderAll();
    if(h){
      if(h.type==='good') showToast(h.history[todayStr()] ? `+${h.points} نقطة 🎯` : `تراجعت −${h.points}`);
      else showToast(h.history[todayStr()] ? `−${h.points} نقطة وقلب 💔` : `تمام، فضلت نضيف +${h.points}`);
    }
    return;
  }
  const del = e.target.closest('[data-del]');
  if(del){
    if(confirm('تحذف العادة دي؟')){ deleteHabit(del.dataset.del); renderAll(); }
    return;
  }
  const togTask = e.target.closest('[data-toggletask]');
  if(togTask){ toggleWeeklyTask(togTask.dataset.toggletask); renderAll(); return; }
  const delTask = e.target.closest('[data-deltask]');
  if(delTask){ deleteWeeklyTask(delTask.dataset.deltask); renderAll(); return; }

  const setMonster = e.target.closest('#setMonsterBtn');
  if(setMonster){
    const sel = document.getElementById('monsterSelect');
    if(sel && sel.value){ liv_setMonster(sel.value); }
    return;
  }
  const clearMonster = e.target.closest('#clearMonsterBtn');
  if(clearMonster){ STATE.monster=null; save(); renderAll(); return; }

  const delGoal = e.target.closest('[data-delgoal]');
  if(delGoal){ deleteGoal(delGoal.dataset.delgoal); renderAll(); return; }
  const delSave = e.target.closest('[data-delsave]');
  if(delSave){ deleteSaving(delSave.dataset.delsave); renderAll(); return; }
  const addSave = e.target.closest('[data-addsave]');
  if(addSave){
    const id = addSave.dataset.addsave;
    const input = document.getElementById('add-'+id);
    const amt = Number(input.value);
    if(amt){ addToSaving(id, amt); renderAll(); showToast('اتضاف للمدخرات 💰'); }
    return;
  }
  const delDream = e.target.closest('[data-deldream]');
  if(delDream){ deleteDream(delDream.dataset.deldream); renderAll(); return; }
  const planDream = e.target.closest('[data-plandream]');
  if(planDream){ requestDreamPlan(planDream.dataset.plandream); return; }
  const delSub = e.target.closest('[data-delsub]');
  if(delSub){ deleteSubscription(delSub.dataset.delsub); renderAll(); return; }
}

function liv_setMonster(id){
  setMonster(id);
  renderAll();
  showToast('اتحدد وحش الشهر 👹 يلا اقفل عليه!');
}

async function requestDreamPlan(id){
  const dream = STATE.dreams.find(d=>d.id===id);
  if(!dream) return;
  showToast('جاري بناء الخطة… ✨');
  try{
    const steps = await aiDreamSteps(dream.text, STATE.profile);
    setDreamSteps(id, steps);
    renderAll();
  }catch(err){
    showToast(aiErrorMessage(err));
  }
}

/* =========================================================
   ADD HABIT MODAL
   ========================================================= */
function openAddHabitModal(){
  openModal(`
    <div class="modal-title">عادة جديدة</div>
    <input class="input-full" id="newHabitName" placeholder="اسم العادة">
    <div style="height:10px"></div>
    <div class="seg-control">
      <button class="seg active" id="habitTypeGood" type="button">حلوة 🌱</button>
      <button class="seg" id="habitTypeBad" type="button">وحشة 🚫</button>
    </div>
    <div class="modal-actions">
      <button class="btn btn-ghost" onclick="closeModal()">إلغاء</button>
      <button class="btn btn-primary" id="saveHabitBtn">إضافة</button>
    </div>
  `);
  let type = 'good';
  document.getElementById('habitTypeGood').onclick = ()=>{ type='good'; document.getElementById('habitTypeGood').classList.add('active'); document.getElementById('habitTypeBad').classList.remove('active'); };
  document.getElementById('habitTypeBad').onclick = ()=>{ type='bad'; document.getElementById('habitTypeBad').classList.add('active'); document.getElementById('habitTypeGood').classList.remove('active'); };
  document.getElementById('saveHabitBtn').onclick = ()=>{
    const name = document.getElementById('newHabitName').value.trim();
    if(!name) return;
    addHabit(name, type);
    closeModal();
    renderAll();
    showToast('اتضافت العادة 🌱');
  };
}

/* =========================================================
   HABITS PAGE
   ========================================================= */
function wireHabits(){
  document.getElementById('addHabitBtn2').addEventListener('click', openAddHabitModal);

  document.querySelectorAll('.tab-sub').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.tab-sub').forEach(b=>b.classList.toggle('active', b===btn));
      renderHabitsPage(btn.dataset.f);
    });
  });

  document.getElementById('predictHabitBtn').addEventListener('click', async ()=>{
    const id = document.getElementById('predictHabitSelect').value;
    const h = STATE.habits.find(x=>x.id===id);
    const resultEl = document.getElementById('predictResult');
    if(!h){ showToast('ضيف عادة الأول'); return; }
    showAiLoading(resultEl);
    try{
      const text = await aiPredictHabit(h);
      showAiResult(resultEl, text);
    }catch(err){ showAiError(resultEl, err); }
  });
}

/* =========================================================
   GOALS PAGE
   ========================================================= */
function wireGoals(){
  document.getElementById('addGoalBtn').addEventListener('click', ()=>{
    openModal(`
      <div class="modal-title">هدف جديد للشهر</div>
      <input class="input-full" id="newGoalInput" placeholder="اكتب الهدف">
      <div class="modal-actions">
        <button class="btn btn-ghost" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" id="saveGoalBtn">إضافة</button>
      </div>
    `);
    document.getElementById('saveGoalBtn').onclick = ()=>{
      const v = document.getElementById('newGoalInput').value.trim();
      if(!v) return;
      addGoal(v);
      closeModal(); renderAll(); showToast('اتضاف الهدف 🎯');
    };
  });

  document.getElementById('addSavingBtn').addEventListener('click', ()=>{
    openModal(`
      <div class="modal-title">هدف ادخار جديد</div>
      <input class="input-full" id="savingName" placeholder="اسم الهدف (مثلاً: آيفون جديد)">
      <div style="height:10px"></div>
      <input class="input-full" id="savingTarget" type="number" placeholder="المبلغ المطلوب (ج.م)">
      <div class="modal-actions">
        <button class="btn btn-ghost" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" id="saveSavingBtn">إضافة</button>
      </div>
    `);
    document.getElementById('saveSavingBtn').onclick = ()=>{
      const n = document.getElementById('savingName').value.trim();
      const t = document.getElementById('savingTarget').value;
      if(!n || !t) return;
      addSaving(n, t);
      closeModal(); renderAll(); showToast('اتضاف هدف الادخار 💰');
    };
  });

  document.getElementById('addDreamBtn').addEventListener('click', ()=>{
    openModal(`
      <div class="modal-title">حلم جديد</div>
      <textarea class="input-full" id="dreamInput" placeholder="اكتب حلمك بالتفصيل"></textarea>
      <div class="modal-actions">
        <button class="btn btn-ghost" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" id="saveDreamBtn">إضافة</button>
      </div>
    `);
    document.getElementById('saveDreamBtn').onclick = ()=>{
      const v = document.getElementById('dreamInput').value.trim();
      if(!v) return;
      addDream(v);
      closeModal(); renderAll(); showToast('اتضاف الحلم 💫');
    };
  });

  document.getElementById('content').addEventListener('input', (e)=>{
    const range = e.target.closest('[data-goal]');
    if(range){
      setGoalProgress(range.dataset.goal, Number(range.value));
      const card = range.closest('.goal-card');
      card.querySelector('.goal-pct span:last-child').textContent = range.value+'%';
    }
  });
}

/* =========================================================
   LIFE PAGE (time / money / health / job)
   ========================================================= */
function wireLife(){
  document.getElementById('socialInsightBtn').addEventListener('click', async ()=>{
    const mins = Number(document.getElementById('socialMinutesInput').value)||0;
    setSocial(mins);
    renderAll();
    const resultEl = document.getElementById('socialInsightResult');
    showAiLoading(resultEl);
    try{
      const text = await aiSocialInsight(mins);
      showAiResult(resultEl, text);
    }catch(err){ showAiError(resultEl, err); }
  });

  document.getElementById('saveFriendsHours').addEventListener('click', ()=>{
    const h = Number(document.getElementById('friendsHoursInput').value)||0;
    setFriendsHours(h);
    showToast('اتحفظ ✅');
  });

  document.getElementById('addSubBtn').addEventListener('click', ()=>{
    openModal(`
      <div class="modal-title">اشتراك جديد</div>
      <input class="input-full" id="subName" placeholder="اسم الاشتراك (مثلاً Netflix)">
      <div style="height:10px"></div>
      <input class="input-full" id="subCost" type="number" placeholder="التكلفة الشهرية (ج.م)">
      <div class="modal-actions">
        <button class="btn btn-ghost" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" id="saveSubBtn">إضافة</button>
      </div>
    `);
    document.getElementById('saveSubBtn').onclick = ()=>{
      const n = document.getElementById('subName').value.trim();
      const c = document.getElementById('subCost').value;
      if(!n||!c) return;
      addSubscription(n,c);
      closeModal(); renderAll(); showToast('اتضاف الاشتراك 📺');
    };
  });

  document.getElementById('saveSleepBtn').addEventListener('click', ()=>{
    const h = Number(document.getElementById('sleepHoursInput').value)||0;
    setSleep(h);
    renderLifePage();
    showToast('اتحفظ النوم 😴');
  });

  document.getElementById('content').addEventListener('click', (e)=>{
    if(e.target.id==='saveJobBtn'){
      const count = Number(document.getElementById('jobCountInput').value)||0;
      const earnings = Number(document.getElementById('jobEarningsInput').value)||0;
      addJobEntry({ count, earnings });
      showToast('اتحفظ شغل النهاردة ✅');
    }
  });

  document.querySelectorAll('#trendRange .seg').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('#trendRange .seg').forEach(b=>b.classList.toggle('active', b===btn));
    });
  });
  document.getElementById('trendBtn').addEventListener('click', async ()=>{
    const id = document.getElementById('trendHabitSelect').value;
    const h = STATE.habits.find(x=>x.id===id);
    const range = document.querySelector('#trendRange .seg.active').dataset.r;
    const resultEl = document.getElementById('trendResult');
    if(!h){ showToast('ضيف عادة الأول'); return; }
    showAiLoading(resultEl);
    try{
      const text = await aiTrendProjection(h, range);
      showAiResult(resultEl, text);
    }catch(err){ showAiError(resultEl, err); }
  });
}

/* =========================================================
   ME PAGE
   ========================================================= */
function wireMe(){
  document.getElementById('editProfileBtn').addEventListener('click', ()=>{
    const p = STATE.profile;
    openModal(`
      <div class="modal-title">تعديل الملف الشخصي</div>
      <label class="field-label">الاسم</label>
      <input class="input-full" id="editName" value="${escapeHtml(p.name)}">
      <div style="height:10px"></div>
      <label class="field-label">الطول (سم)</label>
      <input class="input-full" id="editHeight" type="number" value="${p.height||''}">
      <div style="height:10px"></div>
      <label class="field-label">الوزن (كجم)</label>
      <input class="input-full" id="editWeight" type="number" value="${p.weight||''}">
      <div style="height:10px"></div>
      <label class="field-label">الشغل</label>
      <input class="input-full" id="editJob" value="${escapeHtml(p.jobLabel)}">
      <div style="height:10px"></div>
      <label class="field-label">الهوايات</label>
      <input class="input-full" id="editHobbies" value="${escapeHtml(p.hobbies)}">
      <div style="height:10px"></div>
      <label class="field-label">نبذة عنك</label>
      <textarea class="input-full" id="editBio">${escapeHtml(p.bio)}</textarea>
      <div class="modal-actions">
        <button class="btn btn-ghost" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" id="saveProfileBtn">حفظ</button>
      </div>
    `);
    document.getElementById('saveProfileBtn').onclick = ()=>{
      p.name = document.getElementById('editName').value.trim();
      p.height = Number(document.getElementById('editHeight').value)||null;
      p.weight = Number(document.getElementById('editWeight').value)||null;
      p.jobLabel = document.getElementById('editJob').value.trim();
      p.hobbies = document.getElementById('editHobbies').value.trim();
      p.bio = document.getElementById('editBio').value.trim();
      save();
      closeModal(); renderAll(); showToast('اتحفظ ✅');
    };
  });

  document.getElementById('btnPersonality').addEventListener('click', ()=> runAiMenu(aiPersonalityAnalysis));
  document.getElementById('btnWeeklyMeeting').addEventListener('click', ()=> runAiMenu(aiWeeklyMeeting));
  document.getElementById('btnAiReport').addEventListener('click', ()=> runAiMenu(aiTaskReport));

  document.getElementById('geminiLink').addEventListener('click', ()=>{
    window.open('https://aistudio.google.com/apikey','_blank');
  });

  document.getElementById('saveApiKeyBtn').addEventListener('click', ()=>{
    STATE.apiKey = document.getElementById('apiKeyInput').value.trim();
    save();
    document.getElementById('apiKeyStatus').textContent = STATE.apiKey ? '✅ المفتاح متسجل' : 'لسه معملتش ربط بمفتاح Gemini';
    showToast('اتحفظ المفتاح 🔐');
  });

  document.getElementById('exportBtn').addEventListener('click', ()=>{
    const blob = new Blob([exportState()], { type:'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'liv-backup-'+todayStr()+'.json';
    a.click();
    URL.revokeObjectURL(url);
  });
  document.getElementById('importBtn').addEventListener('click', ()=> document.getElementById('importFile').click());
  document.getElementById('importFile').addEventListener('change', (e)=>{
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = ()=>{
      try{ importState(reader.result); renderAll(); showToast('اترجعت البيانات ✅'); }
      catch(err){ showToast('الملف مش سليم'); }
    };
    reader.readAsText(file);
  });
  document.getElementById('resetBtn').addEventListener('click', ()=>{
    if(confirm('متأكد؟ ده هيمسح كل البيانات نهائيًا.')){
      resetState();
      location.reload();
    }
  });
}

async function runAiMenu(fn){
  const resultEl = document.getElementById('meAiResult');
  showAiLoading(resultEl);
  try{
    const text = await fn();
    showAiResult(resultEl, text);
  }catch(err){ showAiError(resultEl, err); }
}

/* =========================================================
   VOICE
   ========================================================= */
function wireVoice(){
  document.getElementById('micBtn').addEventListener('click', ()=>{
    document.getElementById('micOverlay').classList.remove('hidden');
    document.getElementById('micText').textContent = 'بتسمع دلوقتي… قول اللي عملته';
    startVoiceCommand(handleVoiceResult, ()=>{
      setTimeout(()=> document.getElementById('micOverlay').classList.add('hidden'), 1200);
    });
  });
  document.getElementById('micCancel').addEventListener('click', ()=>{
    stopVoiceCommand();
    document.getElementById('micOverlay').classList.add('hidden');
  });
}

function handleVoiceResult(res){
  document.getElementById('micText').textContent = res.message;
  if(!res.ok) return;

  if(res.kind==='did_activity'){
    const h = STATE.habits.find(x=> x.name.replace(/[أإآ]/g,'ا').includes(res.activity) || res.activity.includes(x.name.replace(/[أإآ]/g,'ا')));
    if(h && h.type==='good' && !h.history[todayStr()]){
      toggleHabitToday(h.id);
      document.getElementById('micText').textContent = `تمام سجلتلك "${h.name}" ✅ +${h.points} نقطة`;
      renderAll();
    }
  } else if(res.kind==='bad_action'){
    addPoints(-10);
    loseHeart();
    save();
    renderAll();
  } else if(res.kind==='dream'){
    addDream(res.dream);
    renderAll();
  } else if(res.kind==='timer_end'){
    showToast(`${res.activity}: ${res.minutes} دقيقة`);
  }
}
