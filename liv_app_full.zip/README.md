# Liv v1.3

تطبيق Flutter لإدارة الحياة: عادات، مهام، أهداف، قلوب، ونقاط + Gemini AI.

## Gemini (مجاني)

1. https://aistudio.google.com/apikey
2. Create API key
3. الصقه من البروفايل أو الأونبوردنج
4. الموديل الافتراضي: `gemini-flash-lite-latest`

لو ظهر 429: استنى دقيقة أو غيّر الموديل.

## تحديث APK بدون مسح

- زوّدنا `versionCode` (1.3.0+5)
- ثبّت الـ APK الجديد **فوق** القديم (Install / Update) من نفس التوقيع
- لو طلب منك Uninstall: غالباً التوقيع مختلف (keystore) — ثبّت نفس signing في GitHub Actions

## البناء

```bash
flutter pub get
flutter build apk --release
```
