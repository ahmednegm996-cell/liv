import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/l10n.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final l = L10n(state.profile.locale);
    final accent = Theme.of(context).colorScheme.primary;
    final goodHabits = state.habits.where((h) => h.isGood).toList();
    final doneGood = goodHabits.where((h) => h.doneToday).length;
    final weekTasks = state.thisWeekTasks;
    final doneTasks = weekTasks.where((t) => t.isDone).length;
    final progress = _todayProgress(goodHabits.length, doneGood, weekTasks.length, doneTasks);
    final level = (state.profile.totalPoints / 100).floor() + 1;
    final hour = DateTime.now().hour;
    final greet = hour < 12
        ? l.t('good_morning')
        : (hour < 18 ? l.t('good_afternoon') : l.t('good_evening'));

    final lastSleep = state.sleepLogs.isEmpty
        ? (state.profile.typicalSleepHours ?? 0)
        : state.sleepLogs.last.value;

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 10, 18, 24),
          children: [
            // ===== Header: hearts + greeting =====
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      HeartsRow(hearts: state.profile.hearts),
                      Gaps.h4,
                      Text(
                        _heartsResetLabel(state, l),
                        style: TextStyle(fontSize: 11, color: secondaryText(context)),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.wb_twilight_rounded, size: 16, color: accent.withOpacity(0.85)),
                        const SizedBox(width: 4),
                        Text(greet, style: TextStyle(fontSize: 13, color: secondaryText(context))),
                      ],
                    ),
                    Gaps.h4,
                    Text(
                      state.profile.name.isEmpty ? 'Liv' : state.profile.name,
                      style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
                    ),
                  ],
                ),
              ],
            ),
            Gaps.h18,

            // ===== Progress card =====
            SectionCard(
              padding: const EdgeInsets.all(18),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l.t('today_progress'),
                            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                        Gaps.h6,
                        Text(
                          '${l.t('level')} $level  •  ${state.profile.totalPoints} ${l.t('points')}',
                          style: TextStyle(fontSize: 12, color: secondaryText(context)),
                        ),
                        Gaps.h12,
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: LinearProgressIndicator(
                            value: progress,
                            minHeight: 7,
                            backgroundColor: accent.withOpacity(0.12),
                            valueColor: AlwaysStoppedAnimation(accent),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  SizedBox(
                    width: 78,
                    height: 78,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        CircularProgressIndicator(
                          value: progress,
                          strokeWidth: 7,
                          backgroundColor: accent.withOpacity(0.15),
                          valueColor: AlwaysStoppedAnimation(accent),
                        ),
                        Text(
                          '${(progress * 100).round()}%',
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                            color: accent,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Gaps.h14,

            // ===== Daily challenge =====
            SectionCard(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: AppColors.orange.withOpacity(0.18),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.bolt_rounded, color: AppColors.orange),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l.t('daily_challenge'),
                            style: TextStyle(fontSize: 12, color: secondaryText(context))),
                        Gaps.h4,
                        Text(state.dailyChallenge,
                            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: Text(l.t('done'), style: TextStyle(color: accent, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
            Gaps.h14,

            // ===== Quick stats =====
            Row(
              children: [
                Expanded(
                  child: _statTile(
                    context,
                    icon: Icons.nightlight_round,
                    value: lastSleep > 0 ? '${lastSleep.toStringAsFixed(0)}${l.t('hour_short')}' : '—',
                    label: l.t('sleep'),
                    accent: accent,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _statTile(
                    context,
                    icon: Icons.autorenew_rounded,
                    value: '$doneGood',
                    label: l.t('habits_label'),
                    accent: accent,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _statTile(
                    context,
                    icon: Icons.check_circle_outline_rounded,
                    value: '${doneTasks}/${weekTasks.length}',
                    label: l.t('tasks_label'),
                    accent: accent,
                  ),
                ),
              ],
            ),
            Gaps.h20,

            // ===== Today's good habits =====
            Text(l.t('good_habits'),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            Gaps.h10,
            if (goodHabits.isEmpty)
              SectionCard(child: Text(l.t('no_habits'), style: TextStyle(color: secondaryText(context))))
            else
              ...goodHabits.map((h) {
                final done = h.doneToday;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: SectionCard(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    child: Row(
                      children: [
                        Checkbox(
                          value: done,
                          activeColor: accent,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                          onChanged: done
                              ? null
                              : (_) => context.read<AppState>().markHabitToday(h),
                        ),
                        Expanded(
                          child: Text(
                            h.name,
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              decoration: done ? TextDecoration.lineThrough : null,
                              color: done ? secondaryText(context) : null,
                            ),
                          ),
                        ),
                        Text(
                          '+${h.pointsValue}',
                          style: TextStyle(
                            color: done ? secondaryText(context) : AppColors.teal,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            Gaps.h16,

            // ===== Tasks =====
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(l.t('today_tasks'),
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                IconButton(
                  icon: Icon(Icons.add_circle_outline, color: accent),
                  onPressed: () => _addTask(context, l),
                ),
              ],
            ),
            if (weekTasks.isEmpty)
              SectionCard(child: Text(l.t('no_tasks'), style: TextStyle(color: secondaryText(context))))
            else
              ...weekTasks.map((t) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: SectionCard(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    child: Row(
                      children: [
                        Checkbox(
                          value: t.isDone,
                          activeColor: accent,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                          onChanged: (_) => context.read<AppState>().toggleWeeklyTask(t),
                        ),
                        Expanded(
                          child: Text(
                            t.title,
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              decoration: t.isDone ? TextDecoration.lineThrough : null,
                              color: t.isDone ? secondaryText(context) : null,
                            ),
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.edit_outlined, size: 18, color: subtleIcon(context)),
                          onPressed: () => _editTask(context, l, t),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete_outline, size: 18, color: subtleIcon(context)),
                          onPressed: () => context.read<AppState>().deleteWeeklyTask(t),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            Gaps.h16,

            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.smart_toy_outlined),
                label: Text(l.t('weekly_meeting')),
                onPressed: () => _openWeeklyMeeting(context, l),
              ),
            ),
          ],
        ),
      ),
    );
  }

  double _todayProgress(int totalGood, int doneGood, int totalTasks, int doneTasks) {
    final total = totalGood + totalTasks;
    if (total == 0) return 0;
    return ((doneGood + doneTasks) / total).clamp(0.0, 1.0);
  }

  String _heartsResetLabel(AppState state, L10n l) {
    final wake = state.profile.wakeHour ?? 7;
    final now = DateTime.now();
    var resetAt = DateTime(now.year, now.month, now.day, wake);
    if (!resetAt.isAfter(now)) {
      resetAt = resetAt.add(const Duration(days: 1));
    }
    final d = resetAt.difference(now);
    final h = d.inHours;
    final m = d.inMinutes % 60;
    return '${l.t('reset_in')} ${h}س ${m}د';
  }

  Widget _statTile(
    BuildContext context, {
    required IconData icon,
    required String value,
    required String label,
    required Color accent,
  }) {
    return SectionCard(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      child: Column(
        children: [
          Icon(icon, color: accent, size: 22),
          Gaps.h8,
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
          Gaps.h4,
          Text(label, style: TextStyle(fontSize: 11, color: secondaryText(context))),
        ],
      ),
    );
  }

  void _addTask(BuildContext context, L10n l) async {
    final v = await showTextInputDialog(context, title: l.t('add_task'));
    if (v != null && v.isNotEmpty && context.mounted) {
      context.read<AppState>().addWeeklyTask(v);
    }
  }

  void _editTask(BuildContext context, L10n l, dynamic t) async {
    final v = await showTextInputDialog(context, title: l.t('edit'), initial: t.title);
    if (v != null && v.isNotEmpty && context.mounted) {
      context.read<AppState>().editWeeklyTask(t, v);
    }
  }

  void _openWeeklyMeeting(BuildContext context, L10n l) async {
    final state = context.read<AppState>();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    String result;
    try {
      result = await state.runWeeklyMeeting();
    } catch (e) {
      result = '${l.t('error')}: $e';
    }
    if (!context.mounted) return;
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text(l.t('weekly_meeting')),
        content: SingleChildScrollView(child: Text(result)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(l.t('ok'))),
        ],
      ),
    );
  }
}
