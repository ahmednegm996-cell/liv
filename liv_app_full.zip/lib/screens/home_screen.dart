import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final goodHabits = state.habits.where((h) => h.isGood).toList();
    final weekTasks = state.thisWeekTasks;
    final doneWeekTasks = weekTasks.where((t) => t.isDone).length;

    return Scaffold(
      appBar: AppBar(
        title: Text(state.profile.name.isEmpty
            ? 'أهلاً بيك في Liv'
            : 'أهلاً، ${state.profile.name}'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(left: 16),
            child: Center(child: PointsChip(points: state.profile.totalPoints, accent: Theme.of(context).colorScheme.primary)),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Builder(builder: (context) {
            final accent = Theme.of(context).colorScheme.primary;
            final accentDark = Color.lerp(accent, Colors.black, 0.25)!;
            return Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [accent, accentDark],
              ),
              borderRadius: BorderRadius.circular(26),
              boxShadow: [
                BoxShadow(
                  color: accent.withOpacity(.28),
                  blurRadius: 28,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'نسخة أحسن منك، بس على مهلك ✨',
                  style: TextStyle(color: Colors.white.withOpacity(.78), fontSize: 13),
                ),
                Gaps.h8,
                Text(
                  '${state.profile.name.isEmpty ? 'يا صديقي' : state.profile.name}، نركز على إيه النهارده؟',
                  style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900),
                ),
                Gaps.h16,
                Row(
                  children: [
                    Expanded(
                      child: _miniStat('نقط', '${state.profile.totalPoints}'),
                    ),
                    Expanded(
                      child: _miniStat('قلوب', '${state.profile.hearts}/3'),
                    ),
                    Expanded(
                      child: _miniStat('مهام', '$doneWeekTasks/${weekTasks.length}'),
                    ),
                  ],
                ),
              ],
            ),
          );
          }),
          Gaps.h16,
          _MeetingsCard(),
          Gaps.h16,
          SectionCard(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('قلوبك النهاردة',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                HeartsRow(hearts: state.profile.hearts),
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    Icon(Icons.bolt_rounded, color: AppColors.orange),
                    Gaps.w8,
                    Text('تحدي اليوم',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  ],
                ),
                Gaps.h8,
                Text(state.dailyChallenge, style: const TextStyle(fontSize: 15)),
              ],
            ),
          ),
          Gaps.h16,
          Text('عاداتك الكويسة النهاردة',
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w700)),
          Gaps.h8,
          if (goodHabits.isEmpty)
            const SectionCard(child: Text('ضيف عادات كويسة من تبويب "العادات"'))
          else
            ...goodHabits.map((h) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: SectionCard(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(
                      children: [
                        Checkbox(
                          value: h.doneToday,
                          activeColor: Theme.of(context).colorScheme.primary,
                          onChanged: h.doneToday
                              ? null
                              : (_) => context.read<AppState>().markHabitToday(h),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(h.name,
                                  style: const TextStyle(fontWeight: FontWeight.w600)),
                              Text('استمرار: ${h.currentStreak} يوم',
                                  style: TextStyle(
                                      fontSize: 12, color: secondaryText(context))),
                            ],
                          ),
                        ),
                        Text('+${h.pointsValue}',
                            style: const TextStyle(
                                color: AppColors.accentTeal,
                                fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                )),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('مهام الأسبوع',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    Row(
                      children: [
                        Text('$doneWeekTasks/${weekTasks.length}'),
                        IconButton(
                          icon: const Icon(Icons.add_circle_outline, size: 20),
                          onPressed: () => _addWeeklyTask(context),
                        ),
                      ],
                    ),
                  ],
                ),
                Gaps.h8,
                if (weekTasks.isEmpty)
                  Text('مفيش مهام أسبوعية لسه',
                      style: TextStyle(color: secondaryText(context)))
                else
                  ...weekTasks.map((t) => CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        controlAffinity: ListTileControlAffinity.leading,
                        value: t.isDone,
                        activeColor: Theme.of(context).colorScheme.primary,
                        title: Text(t.title),
                        onChanged: (_) => context.read<AppState>().toggleWeeklyTask(t),
                      )),
              ],
            ),
          ),
          Gaps.h16,
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.smart_toy_outlined),
              label: const Text('ميتنج أسبوعي مع الـ AI'),
              onPressed: () => _openWeeklyMeeting(context),
            ),
          ),
          Gaps.h24,
        ],
      ),
    );
  }


  Widget _miniStat(String label, String value) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(value, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
      Text(label, style: TextStyle(color: Colors.white.withOpacity(.72), fontSize: 11)),
    ],
  );

  void _addWeeklyTask(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'مهمة أسبوعية جديدة');
    if (v != null && v.isNotEmpty && context.mounted) {
      context.read<AppState>().addWeeklyTask(v);
    }
  }

  void _openWeeklyMeeting(BuildContext context) async {
    final state = context.read<AppState>();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    String result;
    try {
      result = await state.runWeeklyMeeting();
    } catch (e) {
      result = 'حصل خطأ: $e';
    }
    if (!context.mounted) return;
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('ميتنج الأسبوع مع Liv AI'),
        content: SingleChildScrollView(child: Text(result)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('تمام')),
        ],
      ),
    );
  }
}


class _MeetingsCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final now = DateTime.now();
    // ميتنج يومي: ساعة قبل ميعاد النوم أو 21:00
    final bed = state.profile.bedHour ?? 21;
    var dailyAt = DateTime(now.year, now.month, now.day, bed >= 1 ? bed - 1 : 21);
    if (dailyAt.isBefore(now)) {
      dailyAt = dailyAt.add(const Duration(days: 1));
    }
    final dailyLeft = dailyAt.difference(now);

    // ميتنج أسبوعي: يوم محدد (افتراضي الأحد = 7)
    final targetWeekday = state.profile.weeklyMeetingWeekday; // 1=Mon..7=Sun
    var weeklyAt = DateTime(now.year, now.month, now.day, 18);
    while (weeklyAt.weekday != targetWeekday || weeklyAt.isBefore(now)) {
      weeklyAt = weeklyAt.add(const Duration(days: 1));
      weeklyAt = DateTime(weeklyAt.year, weeklyAt.month, weeklyAt.day, 18);
    }
    final weeklyLeft = weeklyAt.difference(now);

    String fmt(Duration d) {
      if (d.inDays >= 1) return '${d.inDays}ي ${d.inHours % 24}س';
      return '${d.inHours}س ${d.inMinutes % 60}د';
    }

    return SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('ميتنجات Liv AI',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          Gaps.h12,
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.nightlight_round, color: Theme.of(context).colorScheme.primary),
            title: const Text('ميتنج سريع آخر اليوم'),
            subtitle: Text('باقي ${fmt(dailyLeft)}'),
            trailing: TextButton(
              child: const Text('ابدأ'),
              onPressed: () => _runDaily(context),
            ),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.calendar_month_rounded, color: AppColors.teal),
            title: const Text('ميتنج أسبوعي'),
            subtitle: Text('باقي ${fmt(weeklyLeft)}'),
            trailing: TextButton(
              child: const Text('ابدأ'),
              onPressed: () => _runWeekly(context),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _runDaily(BuildContext context) async {
    final state = context.read<AppState>();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    String result;
    try {
      result = await state.ai.dailyMeeting(dailySummary: state.buildWeeklySummary());
      await state.updateProfile((p) {
        p.lastDailyMeetingDate =
            '${DateTime.now().year}-${DateTime.now().month}-${DateTime.now().day}';
        return p;
      });
    } catch (e) {
      result = 'خطأ: $e';
    }
    if (!context.mounted) return;
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ميتنج اليوم'),
        content: SingleChildScrollView(child: Text(result)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('تمام')),
        ],
      ),
    );
  }

  Future<void> _runWeekly(BuildContext context) async {
    final state = context.read<AppState>();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    String result;
    try {
      result = await state.runWeeklyMeeting();
    } catch (e) {
      result = 'خطأ: $e';
    }
    if (!context.mounted) return;
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('الميتنج الأسبوعي'),
        content: SingleChildScrollView(child: Text(result)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('تمام')),
        ],
      ),
    );
  }
}
