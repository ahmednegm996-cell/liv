import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/l10n.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final l = L10n(state.profile.locale);
    final accent = Theme.of(context).colorScheme.primary;
    final accentDark = Color.lerp(accent, Colors.black, 0.25)!;
    final goodHabits = state.habits.where((h) => h.isGood).toList();
    final weekTasks = state.thisWeekTasks;
    final doneWeekTasks = weekTasks.where((t) => t.isDone).length;
    final doneGood = goodHabits.where((h) => h.doneToday).length;
    final progress = _todayProgress(
        goodHabits.length, doneGood, weekTasks.length, doneWeekTasks);
    final level = (state.profile.totalPoints / 100).floor() + 1;
    final hour = DateTime.now().hour;
    final greet = hour < 12
        ? l.t('good_morning')
        : (hour < 18 ? l.t('good_afternoon') : l.t('good_evening'));

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            // Header: hearts + greeting (من الصورة) مع الحفاظ على روح Liv
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      HeartsRow(hearts: state.profile.hearts),
                      Gaps.h4,
                      Text(
                        _heartsResetLabel(state, l),
                        style: TextStyle(
                            fontSize: 11, color: secondaryText(context)),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.wb_twilight_rounded,
                            size: 16, color: accent.withOpacity(0.9)),
                        const SizedBox(width: 4),
                        Text(greet,
                            style: TextStyle(
                                fontSize: 13, color: secondaryText(context))),
                      ],
                    ),
                    Gaps.h4,
                    Text(
                      state.profile.name.isEmpty
                          ? l.t('app_name')
                          : state.profile.name,
                      style: const TextStyle(
                          fontSize: 24, fontWeight: FontWeight.w900),
                    ),
                  ],
                ),
              ],
            ),
            Gaps.h16,

            // Hero card (من التصميم الأصلي لـ Liv)
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [accent, accentDark],
                ),
                borderRadius: BorderRadius.circular(26),
                boxShadow: [
                  BoxShadow(
                    color: accent.withOpacity(0.28),
                    blurRadius: 24,
                    offset: const Offset(0, 12),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    state.profile.locale == 'en'
                        ? 'A better version of you, at your pace ✨'
                        : 'نسخة أحسن منك، بس على مهلك ✨',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.78), fontSize: 13),
                  ),
                  Gaps.h8,
                  Text(
                    state.profile.locale == 'en'
                        ? '${state.profile.name.isEmpty ? 'Friend' : state.profile.name}, what do we focus on today?'
                        : '${state.profile.name.isEmpty ? 'يا صديقي' : state.profile.name}، نركز على إيه النهارده؟',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w900),
                  ),
                  Gaps.h16,
                  Row(
                    children: [
                      Expanded(
                          child: _miniStat(
                              l.t('points'), '${state.profile.totalPoints}')),
                      Expanded(
                          child: _miniStat(l.t('hearts'),
                              '${state.profile.hearts}/3')),
                      Expanded(
                          child: _miniStat(l.t('tasks_label'),
                              '$doneWeekTasks/${weekTasks.length}')),
                    ],
                  ),
                ],
              ),
            ),
            Gaps.h14,

            // Progress (من الصورة)
            SectionCard(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l.t('today_progress'),
                            style: const TextStyle(
                                fontWeight: FontWeight.w800, fontSize: 15)),
                        Gaps.h6,
                        Text(
                          '${l.t('level')} $level  •  ${state.profile.totalPoints} ${l.t('points')}',
                          style: TextStyle(
                              fontSize: 12, color: secondaryText(context)),
                        ),
                        Gaps.h12,
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: LinearProgressIndicator(
                            value: progress,
                            minHeight: 7,
                            backgroundColor: accent.withOpacity(0.12),
                            valueColor: AlwaysStoppedAnimation(accent),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 14),
                  SizedBox(
                    width: 70,
                    height: 70,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        CircularProgressIndicator(
                          value: progress,
                          strokeWidth: 6,
                          backgroundColor: accent.withOpacity(0.15),
                          valueColor: AlwaysStoppedAnimation(accent),
                        ),
                        Text(
                          '${(progress * 100).round()}%',
                          style: TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 14,
                              color: accent),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Gaps.h14,

            // Daily challenge
            SectionCard(
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: AppColors.orange.withOpacity(0.18),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.bolt_rounded,
                        color: AppColors.orange, size: 22),
                  ),
                  Gaps.w12,
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l.t('daily_challenge'),
                            style: const TextStyle(
                                fontWeight: FontWeight.w700, fontSize: 15)),
                        Gaps.h4,
                        Text(state.dailyChallenge,
                            style: const TextStyle(fontSize: 14)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Gaps.h16,

            // Good habits
            Text(l.t('good_habits'),
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.w700)),
            Gaps.h8,
            if (goodHabits.isEmpty)
              SectionCard(
                  child: Text(l.t('no_habits'),
                      style: TextStyle(color: secondaryText(context))))
            else
              ...goodHabits.map((h) {
                final done = h.doneToday;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: SectionCard(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    child: Row(
                      children: [
                        Checkbox(
                          value: done,
                          activeColor: accent,
                          onChanged: done
                              ? null
                              : (_) =>
                                  context.read<AppState>().markHabitToday(h),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                h.name,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  decoration: done
                                      ? TextDecoration.lineThrough
                                      : null,
                                  color: done ? secondaryText(context) : null,
                                ),
                              ),
                              Text(
                                '${l.t('streak')}: ${h.currentStreak} ${l.t('days')}',
                                style: TextStyle(
                                    fontSize: 12,
                                    color: secondaryText(context)),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          '+${h.pointsValue}',
                          style: TextStyle(
                            color: done ? secondaryText(context) : AppColors.teal,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            Gaps.h16,

            // Weekly tasks
            SectionCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(l.t('today_tasks'),
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 16)),
                      Row(
                        children: [
                          Text('$doneWeekTasks/${weekTasks.length}'),
                          IconButton(
                            icon: const Icon(Icons.add_circle_outline, size: 20),
                            onPressed: () => _addWeeklyTask(context, l),
                          ),
                        ],
                      ),
                    ],
                  ),
                  Gaps.h8,
                  if (weekTasks.isEmpty)
                    Text(l.t('no_tasks'),
                        style: TextStyle(color: secondaryText(context)))
                  else
                    ...weekTasks.map((t) => Row(
                          children: [
                            Expanded(
                              child: CheckboxListTile(
                                contentPadding: EdgeInsets.zero,
                                controlAffinity:
                                    ListTileControlAffinity.leading,
                                value: t.isDone,
                                activeColor: accent,
                                title: Text(
                                  t.title,
                                  style: TextStyle(
                                    decoration: t.isDone
                                        ? TextDecoration.lineThrough
                                        : null,
                                    color: t.isDone
                                        ? secondaryText(context)
                                        : null,
                                  ),
                                ),
                                onChanged: (_) => context
                                    .read<AppState>()
                                    .toggleWeeklyTask(t),
                              ),
                            ),
                            IconButton(
                              icon: Icon(Icons.edit_outlined,
                                  size: 18, color: subtleIcon(context)),
                              onPressed: () => _editTask(context, l, t),
                            ),
                            IconButton(
                              icon: Icon(Icons.delete_outline,
                                  size: 18, color: subtleIcon(context)),
                              onPressed: () => context
                                  .read<AppState>()
                                  .deleteWeeklyTask(t),
                            ),
                          ],
                        )),
                ],
              ),
            ),
            Gaps.h16,

            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.smart_toy_outlined),
                label: Text(l.t('weekly_meeting')),
                onPressed: () => _openWeeklyMeeting(context, l),
              ),
            ),
          ],
        ),
      ),
    );
  }

  double _todayProgress(
      int totalGood, int doneGood, int totalTasks, int doneTasks) {
    final total = totalGood + totalTasks;
    if (total == 0) return 0;
    return ((doneGood + doneTasks) / total).clamp(0.0, 1.0);
  }

  String _heartsResetLabel(AppState state, L10n l) {
    final wake = state.profile.wakeHour ?? 7;
    final now = DateTime.now();
    var resetAt = DateTime(now.year, now.month, now.day, wake);
    if (!resetAt.isAfter(now)) {
      resetAt = resetAt.add(const Duration(days: 1));
    }
    final d = resetAt.difference(now);
    return '${l.t('reset_in')} ${d.inHours}س ${d.inMinutes % 60}د';
  }

  Widget _miniStat(String label, String value) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w900)),
          Text(label,
              style:
                  TextStyle(color: Colors.white.withOpacity(0.72), fontSize: 11)),
        ],
      );

  void _addWeeklyTask(BuildContext context, L10n l) async {
    final v = await showTextInputDialog(context, title: l.t('add_task'));
    if (v != null && v.isNotEmpty && context.mounted) {
      context.read<AppState>().addWeeklyTask(v);
    }
  }

  void _editTask(BuildContext context, L10n l, dynamic t) async {
    final v =
        await showTextInputDialog(context, title: l.t('edit'), initial: t.title);
    if (v != null && v.isNotEmpty && context.mounted) {
      context.read<AppState>().editWeeklyTask(t, v);
    }
  }

  void _openWeeklyMeeting(BuildContext context, L10n l) async {
    final state = context.read<AppState>();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    String result;
    try {
      result = await state.runWeeklyMeeting();
    } catch (e) {
      result = '${l.t('error')}: $e';
    }
    if (!context.mounted) return;
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text(l.t('weekly_meeting')),
        content: SingleChildScrollView(child: Text(result)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: Text(l.t('ok'))),
        ],
      ),
    );
  }
}
