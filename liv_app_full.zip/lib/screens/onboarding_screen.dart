import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/audio_service.dart';
import '../services/l10n.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _page = PageController();
  int _step = 0;
  bool _loading = false;

  final _name = TextEditingController();
  final _api = TextEditingController();
  final _other = TextEditingController();

  String _locale = 'ar_eg';
  String? _gender;
  String? _job;
  final Set<String> _goals = {};
  final Set<String> _habitWant = {};
  final Set<String> _habitQuit = {};
  int _age = 22;

  // 12-hour clock
  int _bedHour12 = 11; // 1-12
  int _bedMinute = 0;
  bool _bedIsPm = true;
  int _wakeHour12 = 7;
  int _wakeMinute = 0;
  bool _wakeIsPm = false;

  static const jobsEg = ['طالب', 'موظف', 'فريلانسر', 'رائد أعمال', 'سائق / توصيل', 'ربة منزل', 'بدون عمل حالياً', 'أخرى'];
  static const goalsEg = ['تحسين الصحة', 'زيادة الدخل', 'تعلم مهارة', 'تنظيم الوقت', 'خسارة/زيادة وزن', 'بناء عادة يومية', 'تحسين النوم', 'تقليل التوتر', 'أخرى'];
  static const goodHabitsEg = ['رياضة يومية', 'قراءة', 'شرب مياه كفاية', 'نوم منتظم', 'مذاكرة / شغل بتركيز', 'مشي', 'تأمل', 'كتابة يوميات', 'أخرى'];
  static const badHabitsEg = ['سوشيال ميديا زيادة', 'سهر', 'أكل سريع', 'تأجيل المهام', 'تدخين', 'قهوة زيادة', 'مفيش عادة وحشة', 'أخرى'];

  int get total => 10;

  L10n get l => L10n(_locale);

  @override
  void dispose() {
    _page.dispose();
    _name.dispose();
    _api.dispose();
    _other.dispose();
    super.dispose();
  }

  int _to24(int h12, bool isPm) {
    if (h12 == 12) return isPm ? 12 : 0;
    return isPm ? h12 + 12 : h12;
  }

  Future<void> _tick() => AudioService.instance.tick();

  Future<void> _next() async {
    await _tick();
    if (_step >= total - 1) return;
    setState(() => _step++);
    _page.nextPage(duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
  }

  Future<void> _back() async {
    await _tick();
    if (_step <= 0) return;
    setState(() => _step--);
    _page.previousPage(duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Row(
                children: [
                  if (_step > 0)
                    IconButton(
                      onPressed: _back,
                      icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
                    ),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: (_step + 1) / total,
                        minHeight: 6,
                        backgroundColor: Colors.white10,
                        color: AppColors.primary,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: PageView(
                controller: _page,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _welcome(),
                  _langStep(),
                  _genderStep(),
                  _nameStep(),
                  _ageStep(),
                  _choiceMulti(title: l.t('job'), options: jobsEg, single: true, selected: _job == null ? {} : {_job!}, onChange: (s) => setState(() => _job = s.isEmpty ? null : s.first)),
                  _sleepStep(),
                  _choiceMulti(title: l.t('goals'), options: goalsEg, selected: _goals, onChange: (s) => setState(() { _goals..clear()..addAll(s); })),
                  _choiceMulti(title: l.t('habit_want'), options: goodHabitsEg, selected: _habitWant, onChange: (s) => setState(() { _habitWant..clear()..addAll(s); })),
                  _apiStep(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _shell({required Widget child}) => Padding(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(child: child),
      );

  Widget _welcome() => _shell(
        child: Column(
          children: [
            const SizedBox(height: 40),
            Container(
              width: 88,
              height: 88,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AppColors.primary, AppColors.primaryDark]),
                borderRadius: BorderRadius.circular(28),
                boxShadow: [
                  BoxShadow(color: AppColors.primary.withOpacity(0.35), blurRadius: 24, offset: const Offset(0, 10)),
                ],
              ),
              child: const Icon(Icons.auto_awesome_rounded, size: 42, color: Colors.white),
            ),
            Gaps.h20,
            const Text('Liv', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, letterSpacing: -0.5)),
            Gaps.h12,
            Text(
              'هنفهم يومك الأول، وبعدين نبني بداية بسيطة تقدر تلتزم بيها.',
              textAlign: TextAlign.center,
              style: TextStyle(color: secondaryText(context), height: 1.55, fontSize: 15),
            ),
            Gaps.h24,
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(onPressed: _next, child: Text(l.t('lets_start'))),
            ),
          ],
        ),
      );

  Widget _langStep() => _shell(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(l.t('language'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            Gaps.h16,
            for (final e in [('ar_eg', 'عربي مصري'), ('ar', 'عربي فصحى'), ('en', 'English')])
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: ChoiceChip(
                  label: SizedBox(width: double.infinity, child: Text(e.$2, textAlign: TextAlign.center)),
                  selected: _locale == e.$1,
                  onSelected: (_) async {
                    await _tick();
                    setState(() => _locale = e.$1);
                  },
                  selectedColor: AppColors.primary.withOpacity(0.25),
                ),
              ),
            Gaps.h24,
            ElevatedButton(onPressed: _next, child: Text(l.t('next'))),
          ],
        ),
      );

  Widget _genderStep() => _shell(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(l.t('gender'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            Gaps.h16,
            Row(
              children: [
                Expanded(
                  child: _genderCard(Icons.male_rounded, l.t('male'), 'male'),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _genderCard(Icons.female_rounded, l.t('female'), 'female'),
                ),
              ],
            ),
            Gaps.h24,
            ElevatedButton(
              onPressed: _gender == null ? null : _next,
              child: Text(l.t('next')),
            ),
          ],
        ),
      );

  Widget _genderCard(IconData icon, String label, String value) {
    final selected = _gender == value;
    return GestureDetector(
      onTap: () async {
        await _tick();
        setState(() => _gender = value);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 28),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary.withOpacity(0.18) : Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: selected ? AppColors.primary : Colors.transparent, width: 2),
        ),
        child: Column(
          children: [
            Icon(icon, size: 40, color: selected ? AppColors.primary : secondaryText(context)),
            Gaps.h8,
            Text(label, style: TextStyle(fontWeight: FontWeight.w700, color: selected ? AppColors.primary : null)),
          ],
        ),
      ),
    );
  }

  Widget _nameStep() => _shell(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(l.t('your_name'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            Gaps.h16,
            SectionCard(
              child: TextField(
                controller: _name,
                autofocus: true,
                decoration: const InputDecoration(hintText: 'أحمد / Sara'),
              ),
            ),
            Gaps.h24,
            ElevatedButton(onPressed: _next, child: Text(l.t('next'))),
          ],
        ),
      );

  Widget _ageStep() => _shell(
        child: Column(
          children: [
            Text(l.t('your_age'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            Gaps.h16,
            SizedBox(
              height: 180,
              child: CupertinoPicker(
                itemExtent: 40,
                scrollController: FixedExtentScrollController(initialItem: _age - 12),
                onSelectedItemChanged: (i) async {
                  await _tick();
                  setState(() => _age = i + 12);
                },
                children: [
                  for (int a = 12; a <= 80; a++)
                    Center(child: Text('$a ${l.t('years')}', style: const TextStyle(fontSize: 20))),
                ],
              ),
            ),
            Gaps.h16,
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(onPressed: _next, child: Text(l.t('next'))),
            ),
          ],
        ),
      );

  Widget _sleepStep() => _shell(
        child: Column(
          children: [
            Text(l.t('sleep_wake'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            Gaps.h8,
            Text('12-hour • AM / PM', style: TextStyle(color: secondaryText(context))),
            Gaps.h16,
            Text(l.t('bed_at'), style: const TextStyle(fontWeight: FontWeight.w700)),
            _timePicker12(
              hour: _bedHour12,
              minute: _bedMinute,
              isPm: _bedIsPm,
              onHour: (v) async { await _tick(); setState(() => _bedHour12 = v); },
              onMinute: (v) async { await _tick(); setState(() => _bedMinute = v); },
              onPm: (v) async { await _tick(); setState(() => _bedIsPm = v); },
            ),
            Gaps.h12,
            Text(l.t('wake_at'), style: const TextStyle(fontWeight: FontWeight.w700)),
            _timePicker12(
              hour: _wakeHour12,
              minute: _wakeMinute,
              isPm: _wakeIsPm,
              onHour: (v) async { await _tick(); setState(() => _wakeHour12 = v); },
              onMinute: (v) async { await _tick(); setState(() => _wakeMinute = v); },
              onPm: (v) async { await _tick(); setState(() => _wakeIsPm = v); },
            ),
            Gaps.h16,
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(onPressed: _next, child: Text(l.t('next'))),
            ),
          ],
        ),
      );

  Widget _timePicker12({
    required int hour,
    required int minute,
    required bool isPm,
    required ValueChanged<int> onHour,
    required ValueChanged<int> onMinute,
    required ValueChanged<bool> onPm,
  }) {
    return SizedBox(
      height: 120,
      child: Row(
        children: [
          Expanded(
            child: CupertinoPicker(
              itemExtent: 36,
              scrollController: FixedExtentScrollController(initialItem: hour - 1),
              onSelectedItemChanged: (i) => onHour(i + 1),
              children: [for (int h = 1; h <= 12; h++) Center(child: Text('$h'))],
            ),
          ),
          const Text(':', style: TextStyle(fontSize: 22)),
          Expanded(
            child: CupertinoPicker(
              itemExtent: 36,
              scrollController: FixedExtentScrollController(initialItem: minute),
              onSelectedItemChanged: onMinute,
              children: [for (int m = 0; m < 60; m++) Center(child: Text(m.toString().padLeft(2, '0')))],
            ),
          ),
          Expanded(
            child: CupertinoPicker(
              itemExtent: 36,
              scrollController: FixedExtentScrollController(initialItem: isPm ? 1 : 0),
              onSelectedItemChanged: (i) => onPm(i == 1),
              children: [
                Center(child: Text(l.t('am'))),
                Center(child: Text(l.t('pm'))),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _choiceMulti({
    required String title,
    required List<String> options,
    required Set<String> selected,
    required ValueChanged<Set<String>> onChange,
    bool single = false,
  }) {
    return _shell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          if (!single) ...[
            Gaps.h8,
            Text(l.t('select_multi'), style: TextStyle(color: secondaryText(context), fontSize: 13)),
          ],
          Gaps.h16,
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final o in options)
                FilterChip(
                  label: Text(o),
                  selected: selected.contains(o),
                  onSelected: (v) async {
                    await _tick();
                    final next = Set<String>.from(selected);
                    if (single) {
                      next
                        ..clear()
                        ..add(o);
                    } else {
                      v ? next.add(o) : next.remove(o);
                    }
                    onChange(next);
                  },
                  selectedColor: AppColors.primary.withOpacity(0.25),
                ),
            ],
          ),
          Gaps.h24,
          ElevatedButton(
            onPressed: selected.isEmpty ? null : _next,
            child: Text(l.t('next')),
          ),
        ],
      ),
    );
  }

  Widget _apiStep() => _shell(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.key_rounded, size: 48, color: AppColors.primary),
            Gaps.h12,
            Text(l.t('api_title'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            Gaps.h8,
            Text(
              '1) aistudio.google.com/apikey\n2) Create API key\n3) Paste here',
              textAlign: TextAlign.center,
              style: TextStyle(color: secondaryText(context), fontSize: 13, height: 1.5),
            ),
            Gaps.h16,
            TextField(
              controller: _api,
              obscureText: true,
              decoration: InputDecoration(
                hintText: l.t('api_hint'),
                prefixIcon: const Icon(Icons.lock_outline),
              ),
            ),
            Gaps.h24,
            if (_loading)
              const Center(child: CircularProgressIndicator())
            else ...[
              ElevatedButton(onPressed: _finish, child: Text(l.t('build_start'))),
              TextButton(onPressed: _finish, child: Text(l.t('skip_api'))),
            ],
          ],
        ),
      );

  double _sleepHours() {
    final bed = _to24(_bedHour12, _bedIsPm) * 60 + _bedMinute;
    final wake = _to24(_wakeHour12, _wakeIsPm) * 60 + _wakeMinute;
    int diff = wake - bed;
    if (diff <= 0) diff += 24 * 60;
    return diff / 60.0;
  }

  Future<void> _finish() async {
    setState(() => _loading = true);
    final state = context.read<AppState>();
    final name = _name.text.trim().isEmpty ? 'Friend' : _name.text.trim();
    final hours = _sleepHours();
    final bed24 = _to24(_bedHour12, _bedIsPm);
    final wake24 = _to24(_wakeHour12, _wakeIsPm);

    await state.updateProfile((p) {
      p.name = name;
      p.age = _age;
      p.gender = _gender ?? '';
      p.locale = _locale;
      p.jobType = _job;
      p.bedHour = bed24;
      p.wakeHour = wake24;
      p.typicalSleepHours = hours;
      p.geminiApiKey = _api.text.trim();
      p.geminiModel = 'gemini-flash-lite-latest';
      p.aiProvider = 'gemini';
      p.goals = _goals.toList();
      return p;
    });

    await state.logSleep(hours);

    for (final h in _habitWant) {
      if (h != 'أخرى') await state.addHabit(h, true);
    }
    // bad habits from a previous step - we skipped dedicated bad step for length; optional
    for (final h in _habitQuit) {
      if (h != 'أخرى' && h != 'مفيش عادة وحشة') await state.addHabit(h, false);
    }

    final answers = <String, String>{
      'اسمك': name,
      'النوع': _gender ?? '',
      'العمر': '$_age',
      'الشغل': _job ?? '',
      'الأهداف': _goals.join('، '),
      'عادات كويسة': _habitWant.join('، '),
    };

    if (_api.text.trim().isNotEmpty) {
      try {
        await state.buildStarterPlan(answers);
      } catch (_) {}
    }

    await state.completeOnboarding(name);
    if (mounted) setState(() => _loading = false);
  }
}
