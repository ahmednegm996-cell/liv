import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _page = PageController();
  int _step = 0;
  bool _loading = false;

  final _name = TextEditingController();
  final _api = TextEditingController();
  final _other = TextEditingController();

  // اختيارات
  String? _job;
  String? _goal;
  String? _habitWant;
  String? _habitQuit;
  int _age = 22;
  int _bedHour = 23;
  int _bedMinute = 0;
  int _wakeHour = 7;
  int _wakeMinute = 0;

  static const jobs = [
    'طالب',
    'موظف',
    'فريلانسر',
    'رائد أعمال',
    'سائق / توصيل',
    'بدون عمل حالياً',
    'أخرى',
  ];
  static const goals = [
    'تحسين الصحة',
    'زيادة الدخل',
    'تعلم مهارة',
    'تنظيم الوقت',
    'خسارة/زيادة وزن',
    'بناء عادة يومية',
    'أخرى',
  ];
  static const goodHabits = [
    'رياضة يومية',
    'قراءة',
    'شرب مياه كفاية',
    'نوم منتظم',
    'مذاكرة / شغل بتركيز',
    'أخرى',
  ];
  static const badHabits = [
    'سوشيال ميديا زيادة',
    'سهر',
    'أكل سريع',
    'تأجيل المهام',
    'تدخين',
    'مفيش عادة وحشة',
    'أخرى',
  ];

  int get total => 9; // welcome, name, age, job, sleep, goal, good, bad, api, finish handled as last

  @override
  void dispose() {
    _page.dispose();
    _name.dispose();
    _api.dispose();
    _other.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Row(
                children: [
                  if (_step > 0)
                    IconButton(
                      onPressed: _back,
                      icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
                    ),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: (_step + 1) / total,
                        minHeight: 6,
                        backgroundColor: Colors.white10,
                        color: AppColors.primary,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: PageView(
                controller: _page,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _welcome(),
                  _nameStep(),
                  _ageStep(),
                  _choiceStep(
                    title: 'بتعمل إيه؟',
                    options: jobs,
                    selected: _job,
                    onSelect: (v) => setState(() {
                      _job = v;
                      _other.clear();
                    }),
                  ),
                  _sleepStep(),
                  _choiceStep(
                    title: 'أهدافك دلوقتي؟',
                    options: goals,
                    selected: _goal,
                    onSelect: (v) => setState(() {
                      _goal = v;
                      _other.clear();
                    }),
                  ),
                  _choiceStep(
                    title: 'عادة عايز تثبتها؟',
                    options: goodHabits,
                    selected: _habitWant,
                    onSelect: (v) => setState(() {
                      _habitWant = v;
                      _other.clear();
                    }),
                  ),
                  _choiceStep(
                    title: 'عادة عايز تقللها؟',
                    options: badHabits,
                    selected: _habitQuit,
                    onSelect: (v) => setState(() {
                      _habitQuit = v;
                      _other.clear();
                    }),
                  ),
                  _apiStep(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _shell({required Widget child}) => Padding(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(child: child),
      );

  Widget _welcome() => _shell(
        child: Column(
          children: [
            const SizedBox(height: 40),
            Container(
              width: 88,
              height: 88,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppColors.primary, AppColors.primaryDark],
                ),
                borderRadius: BorderRadius.circular(28),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primary.withOpacity(0.35),
                    blurRadius: 24,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: const Icon(Icons.auto_awesome_rounded, size: 42, color: Colors.white),
            ),
            Gaps.h20,
            const Text('Liv',
                style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, letterSpacing: -0.5)),
            Gaps.h12,
            Text(
              'هنفهم يومك الأول، وبعدين نبني بداية بسيطة تقدر تلتزم بيها.',
              textAlign: TextAlign.center,
              style: TextStyle(color: secondaryText(context), height: 1.55, fontSize: 15),
            ),
            Gaps.h24,
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _next,
                child: const Text('يلا نبدأ'),
              ),
            ),
          ],
        ),
      );

  Widget _nameStep() => _shell(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('اسمك إيه؟',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            Gaps.h16,
            SectionCard(
              child: TextField(
                controller: _name,
                autofocus: true,
                decoration: const InputDecoration(hintText: 'مثال: أحمد'),
              ),
            ),
            Gaps.h24,
            ElevatedButton(onPressed: _next, child: const Text('التالي')),
          ],
        ),
      );

  Widget _ageStep() => _shell(
        child: Column(
          children: [
            const Text('عمرك؟',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            Gaps.h16,
            SizedBox(
              height: 180,
              child: CupertinoPicker(
                itemExtent: 40,
                scrollController:
                    FixedExtentScrollController(initialItem: _age - 12),
                onSelectedItemChanged: (i) => setState(() => _age = i + 12),
                children: [
                  for (int a = 12; a <= 80; a++)
                    Center(child: Text('$a سنة', style: const TextStyle(fontSize: 20))),
                ],
              ),
            ),
            Gaps.h16,
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(onPressed: _next, child: const Text('التالي')),
            ),
          ],
        ),
      );

  Widget _sleepStep() => _shell(
        child: Column(
          children: [
            const Text('النوم والصحيان',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            Gaps.h8,
            Text('زي ساعة Apple — حرّك العجلة',
                style: TextStyle(color: secondaryText(context))),
            Gaps.h16,
            const Text('بنام الساعة', style: TextStyle(fontWeight: FontWeight.w700)),
            SizedBox(
              height: 120,
              child: Row(
                children: [
                  Expanded(
                    child: CupertinoPicker(
                      itemExtent: 36,
                      scrollController:
                          FixedExtentScrollController(initialItem: _bedHour),
                      onSelectedItemChanged: (i) =>
                          setState(() => _bedHour = i),
                      children: [
                        for (int h = 0; h < 24; h++)
                          Center(child: Text(h.toString().padLeft(2, '0'))),
                      ],
                    ),
                  ),
                  const Text(':', style: TextStyle(fontSize: 22)),
                  Expanded(
                    child: CupertinoPicker(
                      itemExtent: 36,
                      scrollController:
                          FixedExtentScrollController(initialItem: _bedMinute),
                      onSelectedItemChanged: (i) =>
                          setState(() => _bedMinute = i),
                      children: [
                        for (int m = 0; m < 60; m++)
                          Center(child: Text(m.toString().padLeft(2, '0'))),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Gaps.h12,
            const Text('بصحى الساعة', style: TextStyle(fontWeight: FontWeight.w700)),
            SizedBox(
              height: 120,
              child: Row(
                children: [
                  Expanded(
                    child: CupertinoPicker(
                      itemExtent: 36,
                      scrollController:
                          FixedExtentScrollController(initialItem: _wakeHour),
                      onSelectedItemChanged: (i) =>
                          setState(() => _wakeHour = i),
                      children: [
                        for (int h = 0; h < 24; h++)
                          Center(child: Text(h.toString().padLeft(2, '0'))),
                      ],
                    ),
                  ),
                  const Text(':', style: TextStyle(fontSize: 22)),
                  Expanded(
                    child: CupertinoPicker(
                      itemExtent: 36,
                      scrollController: FixedExtentScrollController(
                          initialItem: _wakeMinute),
                      onSelectedItemChanged: (i) =>
                          setState(() => _wakeMinute = i),
                      children: [
                        for (int m = 0; m < 60; m++)
                          Center(child: Text(m.toString().padLeft(2, '0'))),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Gaps.h16,
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(onPressed: _next, child: const Text('التالي')),
            ),
          ],
        ),
      );

  Widget _choiceStep({
    required String title,
    required List<String> options,
    required String? selected,
    required ValueChanged<String> onSelect,
  }) {
    final isOther = selected == 'أخرى';
    return _shell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(title,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          Gaps.h16,
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final o in options)
                ChoiceChip(
                  label: Text(o),
                  selected: selected == o,
                  onSelected: (_) => onSelect(o),
                  selectedColor: AppColors.primary.withOpacity(0.25),
                ),
            ],
          ),
          if (isOther) ...[
            Gaps.h12,
            TextField(
              controller: _other,
              decoration: const InputDecoration(hintText: 'اكتب هنا...'),
            ),
          ],
          Gaps.h24,
          ElevatedButton(
            onPressed: selected == null
                ? null
                : () {
                    if (isOther && _other.text.trim().isEmpty) return;
                    _next();
                  },
            child: const Text('التالي'),
          ),
        ],
      ),
    );
  }

  Widget _apiStep() => _shell(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.key_rounded, size: 48, color: AppColors.primary),
            Gaps.h12,
            const Text('Gemini API (مجاني)',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            Gaps.h8,
            Text(
              '1) افتح aistudio.google.com/apikey\n'
              '2) اعمل API Key مجاني\n'
              '3) الصقه هنا — تقدر تسيبه فاضي وتكمّل بعدين',
              textAlign: TextAlign.center,
              style: TextStyle(color: secondaryText(context), fontSize: 13, height: 1.5),
            ),
            Gaps.h16,
            TextField(
              controller: _api,
              obscureText: true,
              decoration: const InputDecoration(
                hintText: 'الصق المفتاح هنا',
                prefixIcon: Icon(Icons.lock_outline),
              ),
            ),
            Gaps.h24,
            if (_loading)
              const Center(child: CircularProgressIndicator())
            else ...[
              ElevatedButton(
                onPressed: _finish,
                child: const Text('ابني لي البداية'),
              ),
              TextButton(
                onPressed: _finish,
                child: const Text('تخطي — هحط المفتاح بعدين'),
              ),
            ],
          ],
        ),
      );

  void _next() {
    if (_step >= total - 1) return;
    setState(() => _step++);
    _page.nextPage(
        duration: const Duration(milliseconds: 280), curve: Curves.easeOutCubic);
  }

  void _back() {
    if (_step <= 0) return;
    setState(() => _step--);
    _page.previousPage(
        duration: const Duration(milliseconds: 280), curve: Curves.easeOutCubic);
  }

  String _resolve(String? selected) {
    if (selected == null) return '';
    if (selected == 'أخرى') return _other.text.trim();
    return selected;
  }

  double _sleepHours() {
    final bed = _bedHour * 60 + _bedMinute;
    final wake = _wakeHour * 60 + _wakeMinute;
    int diff = wake - bed;
    if (diff <= 0) diff += 24 * 60;
    return diff / 60.0;
  }

  Future<void> _finish() async {
    setState(() => _loading = true);
    final state = context.read<AppState>();
    final name = _name.text.trim().isEmpty ? 'صديقي' : _name.text.trim();
    final job = _resolve(_job);
    final goal = _resolve(_goal);
    final good = _resolve(_habitWant);
    final bad = _resolve(_habitQuit);
    final hours = _sleepHours();

    await state.updateProfile((p) {
      p.name = name;
      p.age = _age;
      p.jobType = job.isEmpty ? null : job;
      p.bedHour = _bedHour;
      p.wakeHour = _wakeHour;
      p.typicalSleepHours = hours;
      p.geminiApiKey = _api.text.trim();
      p.geminiModel = 'gemini-2.5-flash';
      if (goal.isNotEmpty) p.goals = [goal];
      return p;
    });

    await state.logSleep(hours);

    if (good.isNotEmpty) {
      await state.addHabit(good, true);
    }
    if (bad.isNotEmpty && bad != 'مفيش عادة وحشة') {
      await state.addHabit(bad, false);
    }

    final answers = <String, String>{
      'اسمك': name,
      'العمر': '$_age',
      'الشغل/الدراسة': job,
      'النوم': 'من $_bedHour:${_bedMinute.toString().padLeft(2, '0')} لـ $_wakeHour:${_wakeMinute.toString().padLeft(2, '0')} ($hours ساعة)',
      'الحلم الأكبر': goal,
      'عادات عايز تثبتها': good,
      'حاجات عايز تقللها': bad,
    };

    if (_api.text.trim().isNotEmpty) {
      try {
        await state.buildStarterPlan(answers);
      } catch (_) {}
    }

    await state.completeOnboarding(name);
    if (mounted) setState(() => _loading = false);
  }
}
