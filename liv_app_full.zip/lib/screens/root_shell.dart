import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/audio_service.dart';
import '../services/l10n.dart';
import 'home_screen.dart';
import 'habits_screen.dart';
import 'dreams_screen.dart';
import 'stats_screen.dart';
import 'profile_screen.dart';
import 'ai_chat_screen.dart';

class RootShell extends StatefulWidget {
  const RootShell({super.key});
  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final l = L10n(context.watch<AppState>().profile.locale);
    // ترتيب زي الصورة: الرئيسية، مهام(إحصائيات مختصرة عبر home)، عادات، أهداف، AI، حسابي
    // نستخدم: 0 home, 1 habits, 2 dreams, 3 stats, 4 ai, 5 profile
    final screens = [
      const HomeScreen(),
      const HabitsScreen(),
      const DreamsScreen(),
      const StatsScreen(),
      AIChatScreen(active: _index == 4),
      const ProfileScreen(),
    ];

    return Scaffold(
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 320),
        switchInCurve: Curves.easeOutCubic,
        switchOutCurve: Curves.easeInCubic,
        transitionBuilder: (child, anim) {
          final offset = Tween<Offset>(
            begin: const Offset(0.04, 0),
            end: Offset.zero,
          ).animate(anim);
          return FadeTransition(
            opacity: anim,
            child: SlideTransition(position: offset, child: child),
          );
        },
        child: KeyedSubtree(
          key: ValueKey(_index),
          child: screens[_index],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) {
          if (_index == 4 && i != 4) {
            AudioService.instance.stop();
          }
          setState(() => _index = i);
        },
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.home_outlined),
            selectedIcon: const Icon(Icons.home_rounded),
            label: l.t('home'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.autorenew_outlined),
            selectedIcon: const Icon(Icons.autorenew_rounded),
            label: l.t('habits'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.flag_outlined),
            selectedIcon: const Icon(Icons.flag_rounded),
            label: l.t('dreams'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.check_circle_outline),
            selectedIcon: const Icon(Icons.check_circle_rounded),
            label: l.t('tasks'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.auto_awesome_outlined),
            selectedIcon: const Icon(Icons.auto_awesome_rounded),
            label: l.t('ai'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.person_outline_rounded),
            selectedIcon: const Icon(Icons.person_rounded),
            label: l.t('profile'),
          ),
        ],
      ),
    );
  }
}
