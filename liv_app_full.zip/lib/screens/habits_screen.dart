import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../services/app_state.dart';
import '../services/l10n.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class HabitsScreen extends StatelessWidget {
  const HabitsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final l = L10n(state.profile.locale);
    final accent = Theme.of(context).colorScheme.primary;
    final good = state.habits.where((h) => h.isGood).toList();
    final bad = state.habits.where((h) => !h.isGood).toList();

    return Scaffold(
      appBar: AppBar(title: Text(l.t('habits'))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addHabitDialog(context, l),
        icon: const Icon(Icons.add),
        label: Text(l.t('add_habit')),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (state.monsterOfMonth != null) ...[
            SectionCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.local_fire_department, color: Colors.deepOrange),
                      Gaps.w8,
                      Text(l.t('monster_of_month'),
                          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    ],
                  ),
                  Gaps.h8,
                  Text('"${state.monsterOfMonth!.name}" — ${l.t('monster_hint')}'),
                ],
              ),
            ),
            Gaps.h16,
          ],
          Text(l.t('good_habits'),
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
          Gaps.h8,
          if (good.isEmpty)
            Text(l.t('no_habits'), style: TextStyle(color: secondaryText(context))),
          ...good.map((h) => _habitTile(context, h, l, accent)),
          Gaps.h24,
          Text(l.t('bad_habits'),
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
          Gaps.h8,
          if (bad.isEmpty)
            Text(l.t('no_habits'), style: TextStyle(color: secondaryText(context))),
          ...bad.map((h) => _habitTile(context, h, l, accent)),
          Gaps.h24,
        ],
      ),
    );
  }

  Widget _habitTile(BuildContext context, Habit h, L10n l, Color accent) {
    final state = context.read<AppState>();
    final done = h.doneToday;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SectionCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Checkbox(
                  value: done,
                  activeColor: accent,
                  onChanged: done ? null : (_) => state.markHabitToday(h),
                ),
                Expanded(
                  child: Text(
                    h.name,
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                      decoration: done ? TextDecoration.lineThrough : null,
                      color: done ? secondaryText(context) : null,
                    ),
                  ),
                ),
                if (!h.isGood)
                  IconButton(
                    tooltip: l.t('monster_of_month'),
                    icon: Icon(Icons.local_fire_department,
                        color: h.isMonsterOfMonth ? Colors.deepOrange : subtleIcon(context)),
                    onPressed: () => state.chooseMonsterOfMonth(h),
                  ),
                IconButton(
                  icon: Icon(Icons.edit_outlined, color: subtleIcon(context)),
                  onPressed: () => _editHabit(context, l, h),
                ),
                IconButton(
                  icon: Icon(Icons.delete_outline, color: mutedText(context)),
                  onPressed: () => state.deleteHabit(h),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: Text(
                '${l.t('streak')}: ${h.currentStreak} ${l.t('days')} • ${h.isGood ? "+" : "-"}${h.pointsValue}',
                style: TextStyle(fontSize: 12, color: secondaryText(context)),
              ),
            ),
            if (h.aiAnalysis != null) ...[
              Gaps.h8,
              Text(h.aiAnalysis!, style: TextStyle(fontSize: 13, color: secondaryText(context))),
            ],
            Gaps.h8,
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: () async {
                  showDialog(
                    context: context,
                    barrierDismissible: false,
                    builder: (_) => const Center(child: CircularProgressIndicator()),
                  );
                  try {
                    await state.analyzeHabitWithAI(h);
                  } catch (_) {}
                  if (context.mounted) Navigator.pop(context);
                },
                icon: const Icon(Icons.auto_awesome, size: 16),
                label: const Text('AI'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _addHabitDialog(BuildContext context, L10n l) async {
    final nameCtrl = TextEditingController();
    bool isGood = true;
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: Text(l.t('add_habit')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameCtrl, decoration: InputDecoration(hintText: l.t('add_habit'))),
              Gaps.h12,
              SegmentedButton<bool>(
                segments: [
                  ButtonSegment(value: true, label: Text(l.t('good_habits'))),
                  ButtonSegment(value: false, label: Text(l.t('bad_habits'))),
                ],
                selected: {isGood},
                onSelectionChanged: (s) => setSt(() => isGood = s.first),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(l.t('cancel'))),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, {'name': nameCtrl.text.trim(), 'isGood': isGood}),
              child: Text(l.t('save')),
            ),
          ],
        ),
      ),
    );
    if (result != null && (result['name'] as String).isNotEmpty && context.mounted) {
      context.read<AppState>().addHabit(result['name'], result['isGood'] as bool);
    }
  }

  void _editHabit(BuildContext context, L10n l, Habit h) async {
    final v = await showTextInputDialog(context, title: l.t('edit'), initial: h.name);
    if (v != null && v.isNotEmpty && context.mounted) {
      context.read<AppState>().editHabit(h, name: v);
    }
  }
}
