import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final p = state.profile;

    return Scaffold(
      appBar: AppBar(title: const Text('البروفايل والإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('شكل التطبيق', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                Gaps.h12,
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'system', label: Text('النظام'), icon: Icon(Icons.brightness_auto)),
                    ButtonSegment(value: 'light', label: Text('فاتح'), icon: Icon(Icons.light_mode)),
                    ButtonSegment(value: 'dark', label: Text('غامق'), icon: Icon(Icons.dark_mode)),
                  ],
                  selected: {p.themeMode},
                  onSelectionChanged: (selection) {
                    state.updateProfile((prof) {
                      prof.themeMode = selection.first;
                      return prof;
                    });
                  },
                ),
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('بياناتك', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                Gaps.h12,
                _infoRow(context, 'الاسم', p.name.isEmpty ? '—' : p.name,
                    () => _editName(context)),
                _infoRow(context, 'الطول (سم)', p.heightCm?.toString() ?? '—',
                    () => _editHeight(context)),
                _infoRow(context, 'الوزن (كجم)', p.weightKg?.toString() ?? '—',
                    () => _editWeight(context)),
                _infoRow(context, 'مجال الشغل', p.jobType ?? '—',
                    () => _editJob(context)),
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('هواياتك', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    IconButton(icon: const Icon(Icons.add), onPressed: () => _addToList(context, isHobby: true)),
                  ],
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: p.hobbies
                      .map((h) => Chip(label: Text(h), onDeleted: () => _removeFromList(context, h, isHobby: true)))
                      .toList(),
                ),
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('أهدافك', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    IconButton(icon: const Icon(Icons.add), onPressed: () => _addToList(context, isHobby: false)),
                  ],
                ),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: p.goals
                      .map((g) => Chip(label: Text(g), onDeleted: () => _removeFromList(context, g, isHobby: false)))
                      .toList(),
                ),
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('الاشتراكات الشهرية', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    TextButton.icon(
                      icon: const Icon(Icons.add, size: 18),
                      label: const Text('اشتراك'),
                      onPressed: () => _addSub(context),
                    ),
                  ],
                ),
                Gaps.h8,
                ...state.subs.map((s) => ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(s.name),
                      subtitle: Text('${s.price.toStringAsFixed(0)} جنيه / شهريًا'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => state.deleteSub(s),
                      ),
                    )),
                if (state.subs.isNotEmpty) ...[
                  const Divider(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('الإجمالي الشهري', style: TextStyle(fontWeight: FontWeight.w700)),
                      Text('${state.monthlySubsTotal.toStringAsFixed(0)} جنيه',
                          style: TextStyle(fontWeight: FontWeight.w700, color: Theme.of(context).colorScheme.primary)),
                    ],
                  ),
                ],
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.auto_awesome_rounded, color: Theme.of(context).colorScheme.primary, size: 22),
                    Gaps.w8,
                    const Text('إعدادات الذكاء الاصطناعي',
                        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  ],
                ),
                Gaps.h8,
                Text(
                  'Gemini مجاني 100% من aistudio.google.com/apikey',
                  style: TextStyle(fontSize: 12, color: secondaryText(context), height: 1.4),
                ),
                Gaps.h12,
                DropdownButtonFormField<String>(
                  value: ['gemini', 'grok', 'groq'].contains(p.aiProvider)
                      ? p.aiProvider
                      : 'gemini',
                  decoration: const InputDecoration(labelText: 'المزوّد'),
                  items: const [
                    DropdownMenuItem(value: 'gemini', child: Text('Google Gemini (مجاني)')),
                    DropdownMenuItem(value: 'grok', child: Text('Grok (xAI)')),
                    DropdownMenuItem(value: 'groq', child: Text('Groq')),
                  ],
                  onChanged: (v) {
                    if (v == null) return;
                    context.read<AppState>().updateProfile((pr) {
                      pr.aiProvider = v;
                      if (v == 'grok' && (pr.geminiModel.startsWith('gemini') || pr.geminiModel.isEmpty)) {
                        pr.geminiModel = 'grok-2-latest';
                      }
                      if (v == 'gemini' && !pr.geminiModel.startsWith('gemini')) {
                        pr.geminiModel = 'gemini-flash-lite-latest';
                      }
                      if (v == 'groq' && pr.geminiModel.startsWith('gemini')) {
                        pr.geminiModel = 'llama-3.3-70b-versatile';
                      }
                      return pr;
                    });
                  },
                ),
                Gaps.h12,
                _apiKeyField(context, p),
                Gaps.h12,
                if (p.aiProvider == 'gemini') ...[
                  DropdownButtonFormField<String>(
                    value: _modelValue(p.geminiModel),
                    decoration: const InputDecoration(labelText: 'الموديل (مجاني)'),
                    items: const [
                      DropdownMenuItem(value: 'gemini-flash-lite-latest', child: Text('Flash-Lite Latest — موصى به')),
                      DropdownMenuItem(value: 'gemini-flash-latest', child: Text('Flash Latest')),
                      DropdownMenuItem(value: 'gemini-2.0-flash-lite', child: Text('2.0 Flash-Lite')),
                      DropdownMenuItem(value: 'gemini-2.0-flash', child: Text('2.0 Flash')),
                      DropdownMenuItem(value: 'gemini-2.5-flash', child: Text('2.5 Flash')),
                      DropdownMenuItem(value: 'gemini-3.5-flash-lite', child: Text('3.5 Flash-Lite')),
                      DropdownMenuItem(value: 'custom', child: Text('موديل مخصص...')),
                    ],
                    onChanged: (v) {
                      if (v == null) return;
                      if (v == 'custom') {
                        _editModel(context);
                        return;
                      }
                      context.read<AppState>().updateProfile((pr) {
                        pr.geminiModel = v;
                        return pr;
                      });
                    },
                  ),
                ] else
                  _infoRow(context, 'الموديل', p.geminiModel, () => _editModel(context)),
                Gaps.h12,
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () => _testAI(context),
                    icon: const Icon(Icons.wifi_tethering_rounded),
                    label: const Text('اختبار الاتصال'),
                  ),
                ),
              ],
            ),
          ),
          Gaps.h16,
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('لون الثيم', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                Gaps.h12,
                Wrap(
                  spacing: 10,
                  children: [
                    for (final e in {
                      'purple': AppColors.purple,
                      'teal': AppColors.teal,
                      'blue': AppColors.blue,
                      'orange': AppColors.orange,
                      'pink': AppColors.pink,
                    }.entries)
                      GestureDetector(
                        onTap: () => context.read<AppState>().updateProfile((pr) {
                          pr.accentColor = e.key;
                          return pr;
                        }),
                        child: Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: e.value,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: p.accentColor == e.key
                                  ? Colors.white
                                  : Colors.transparent,
                              width: 3,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                Gaps.h16,
                const Text('اللغة', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                Gaps.h8,
                DropdownButtonFormField<String>(
                  value: ['ar_eg', 'ar', 'en'].contains(p.locale) ? p.locale : 'ar_eg',
                  items: const [
                    DropdownMenuItem(value: 'ar_eg', child: Text('عربي مصري')),
                    DropdownMenuItem(value: 'ar', child: Text('عربي فصحى')),
                    DropdownMenuItem(value: 'en', child: Text('English')),
                  ],
                  onChanged: (v) {
                    if (v == null) return;
                    context.read<AppState>().updateProfile((pr) {
                      pr.locale = v;
                      return pr;
                    });
                  },
                ),
              ],
            ),
          ),
          Gaps.h24,
        ],
      ),
    );
  }


  String _modelValue(String model) {
    const known = {
      'gemini-flash-lite-latest',
      'gemini-flash-latest',
      'gemini-2.0-flash-lite',
      'gemini-2.0-flash',
      'gemini-2.5-flash',
      'gemini-3.5-flash-lite',
    };
    return known.contains(model) ? model : 'custom';
  }

  Widget _infoRow(BuildContext context, String label, String value, VoidCallback onEdit) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(child: Text(label, style: TextStyle(color: secondaryText(context)))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          IconButton(
            icon: const Icon(Icons.edit_outlined, size: 18),
            onPressed: onEdit,
          ),
        ],
      ),
    );
  }

  Widget _apiKeyField(BuildContext context, UserProfile p) {
    final controller = TextEditingController(text: p.geminiApiKey);
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: controller,
            obscureText: true,
            decoration: const InputDecoration(hintText: 'الصق مفتاح Gemini API هنا'),
          ),
        ),
        Gaps.w8,
        ElevatedButton(
          onPressed: () {
            context.read<AppState>().updateProfile((p) {
              p.geminiApiKey = controller.text.trim();
              return p;
            });
            ScaffoldMessenger.of(context)
                .showSnackBar(const SnackBar(content: Text('تم حفظ المفتاح')));
          },
          child: const Text('حفظ'),
        ),
      ],
    );
  }


  Future<void> _testAI(BuildContext context) async {
    final state = context.read<AppState>();
    if (!state.ai.isConfigured) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('حط API Key الأول.')),
      );
      return;
    }
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    try {
      await state.testAIConnection();
      if (context.mounted) Navigator.pop(context);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('الاتصال شغال ✅')),
        );
      }
    } catch (e) {
      if (context.mounted) Navigator.pop(context);
      if (context.mounted) {
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('مشكلة الاتصال'),
            content: Text(e.toString()),
            actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('تمام'))],
          ),
        );
      }
    }
  }

  void _editName(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'اسمك', initial: context.read<AppState>().profile.name);
    if (v != null && context.mounted) {
      context.read<AppState>().updateProfile((p) { p.name = v; return p; });
    }
  }

  void _editHeight(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'طولك بالسم', hint: 'مثلا 175');
    final parsed = double.tryParse((v ?? '').replaceAll(',', '.'));
    if (parsed != null && context.mounted) {
      context.read<AppState>().updateProfile((p) { p.heightCm = parsed; return p; });
    }
  }

  void _editWeight(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'وزنك بالكيلو', hint: 'مثلا 75');
    final parsed = double.tryParse((v ?? '').replaceAll(',', '.'));
    if (parsed != null && context.mounted) {
      context.read<AppState>().updateProfile((p) { p.weightKg = parsed; return p; });
    }
  }

  void _editJob(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'مجال شغلك', hint: 'مثلا أوبر / عقارات / موظف');
    if (v != null && context.mounted) {
      context.read<AppState>().updateProfile((p) { p.jobType = v; return p; });
    }
  }

  void _editModel(BuildContext context) async {
    final v = await showTextInputDialog(context, title: 'اسم الموديل', hint: 'gemini-flash-lite-latest', initial: context.read<AppState>().profile.geminiModel);
    if (v != null && v.isNotEmpty && context.mounted) {
      context.read<AppState>().updateProfile((p) { p.geminiModel = v; return p; });
    }
  }

  void _addToList(BuildContext context, {required bool isHobby}) async {
    final v = await showTextInputDialog(context, title: isHobby ? 'هواية جديدة' : 'هدف جديد');
    if (v != null && v.isNotEmpty && context.mounted) {
      context.read<AppState>().updateProfile((p) {
        if (isHobby) {
          p.hobbies.add(v);
        } else {
          p.goals.add(v);
        }
        return p;
      });
    }
  }

  void _removeFromList(BuildContext context, String value, {required bool isHobby}) {
    context.read<AppState>().updateProfile((p) {
      if (isHobby) {
        p.hobbies.remove(value);
      } else {
        p.goals.remove(value);
      }
      return p;
    });
  }

  void _addSub(BuildContext context) async {
    final nameController = TextEditingController();
    final priceController = TextEditingController();
    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('اشتراك جديد'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: nameController, decoration: const InputDecoration(hintText: 'مثلا Netflix')),
            Gaps.h12,
            TextField(
              controller: priceController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(hintText: 'السعر الشهري بالجنيه'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, {
              'name': nameController.text.trim(),
              'price': priceController.text.trim(),
            }),
            child: const Text('إضافة'),
          ),
        ],
      ),
    );
    if (result != null && (result['name'] ?? '').isNotEmpty) {
      final price = double.tryParse((result['price'] ?? '0').replaceAll(',', '.')) ?? 0;
      if (context.mounted) {
        context.read<AppState>().addSub(result['name']!, price, 1);
      }
    }
  }
}
