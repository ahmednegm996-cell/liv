import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// كارت أساسي بتصميم احترافي موحد
class SectionCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? color;
  final Border? border;
  const SectionCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.color,
    this.border,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? (isDark ? AppColors.cardDark : AppColors.cardLight),
        borderRadius: BorderRadius.circular(22),
        border: border ??
            Border.all(
              color: isDark
                  ? Colors.white.withOpacity(0.06)
                  : Colors.black.withOpacity(0.04),
            ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDark ? 0.35 : 0.06),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: child,
    );
  }
}

/// عرض ٣ قلوب (متبقية النهاردة)
class HeartsRow extends StatelessWidget {
  final int hearts;
  const HeartsRow({super.key, required this.hearts});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (i) {
        final filled = i < hearts;
        return Padding(
          padding: const EdgeInsets.only(left: 4),
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 280),
            child: Icon(
              filled ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              key: ValueKey('h$i$filled'),
              color: AppColors.heartRed,
              size: 26,
            ),
          ),
        );
      }),
    );
  }
}

/// شارة النقط
class PointsChip extends StatelessWidget {
  final int points;
  final Color? accent;
  const PointsChip({super.key, required this.points, this.accent});

  @override
  Widget build(BuildContext context) {
    final c = accent ?? Theme.of(context).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [c, c.withOpacity(0.75)],
        ),
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: c.withOpacity(0.35),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.star_rounded, color: Colors.white, size: 18),
          Gaps.w8,
          Text(
            '$points نقطة',
            style: const TextStyle(
                color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14),
          ),
        ],
      ),
    );
  }
}

/// شريط تقدم بسيط بتصميم مبسّط
class ProgressBarWithLabel extends StatelessWidget {
  final double progress; // 0..1
  final String label;
  final Color? color;
  const ProgressBarWithLabel({
    super.key,
    required this.progress,
    required this.label,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? Theme.of(context).colorScheme.primary;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
            Text('${(progress * 100).round()}%',
                style: TextStyle(color: c, fontWeight: FontWeight.w700)),
          ],
        ),
        Gaps.h8,
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: LinearProgressIndicator(
            value: progress.clamp(0.0, 1.0).toDouble(),
            minHeight: 10,
            backgroundColor: Theme.of(context).brightness == Brightness.dark
                ? Colors.white.withOpacity(0.1)
                : Colors.black.withOpacity(0.06),
            valueColor: AlwaysStoppedAnimation(c),
          ),
        ),
      ],
    );
  }
}

/// رسم بياني بسيط بالأعمدة
class SimpleBarChart extends StatelessWidget {
  final List<double> values;
  final List<String> labels;
  final Color color;
  const SimpleBarChart({
    super.key,
    required this.values,
    required this.labels,
    this.color = AppColors.primary,
  });

  @override
  Widget build(BuildContext context) {
    if (values.isEmpty) {
      return const SizedBox(
        height: 120,
        child: Center(child: Text('لسه مفيش بيانات كفاية')),
      );
    }
    final maxVal = values.reduce((a, b) => a > b ? a : b);
    return SizedBox(
      height: 140,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(values.length, (i) {
          final h = maxVal == 0 ? 4.0 : (values[i] / maxVal) * 100 + 4;
          return Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(values[i].toStringAsFixed(1),
                  style: TextStyle(fontSize: 10, color: secondaryText(context))),
              Gaps.h4,
              Container(
                width: 18,
                height: h,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [color, color.withOpacity(0.7)],
                  ),
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
              Gaps.h4,
              Text(labels[i], style: const TextStyle(fontSize: 10)),
            ],
          );
        }),
      ),
    );
  }
}

Future<String?> showTextInputDialog(
  BuildContext context, {
  required String title,
  String hint = '',
  String initial = '',
}) async {
  final controller = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      content: TextField(
        controller: controller,
        autofocus: true,
        decoration: InputDecoration(hintText: hint),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        ElevatedButton(
          onPressed: () => Navigator.pop(ctx, controller.text.trim()),
          child: const Text('حفظ'),
        ),
      ],
    ),
  );
}
