// الحالة المركزية للتطبيق - بتوصل كل الشاشات ببعض وبتتعامل مع التخزين و AI.
import 'package:flutter/foundation.dart';
import '../models.dart';
import 'storage_service.dart';
import 'gemini_service.dart';
import 'challenges.dart';

class AppState extends ChangeNotifier {
  final StorageService _storage = StorageService();

  UserProfile profile = UserProfile();
  List<Habit> habits = [];
  List<Dream> dreams = [];
  List<WeeklyTask> tasks = [];
  List<Subscription> subs = [];
  List<DailyLog> sleepLogs = [];
  List<DailyLog> weightLogs = [];
  List<DailyLog> socialLogs = [];

  String dailyChallenge = '';
  bool isLoading = true;

  GeminiService get ai => GeminiService(
        apiKey: profile.geminiApiKey,
        model: profile.geminiModel,
        provider: profile.aiProvider,
      );

  Future<void> load() async {
    profile = await _storage.loadProfile();
    // ترقية الموديلات القديمة/غير المتاحة
    final legacy = {
      'gemini-1.5-flash',
      'gemini-1.5-flash-latest',
      'gemini-1.5-flash-8b',
      'gemini-1.5-pro',
      'gemini-pro',
      'gemini-2.5-flash-lite', // no longer for new users
      '',
    };
    if (legacy.contains(profile.geminiModel) ||
        profile.geminiModel.startsWith('gemini-1.')) {
      profile.geminiModel = 'gemini-flash-lite-latest';
      await _saveProfile();
    }
    habits = await _storage.loadHabits();
    dreams = await _storage.loadDreams();
    tasks = await _storage.loadTasks();
    subs = await _storage.loadSubs();
    sleepLogs = await _storage.loadSleepLogs();
    weightLogs = await _storage.loadWeightLogs();
    socialLogs = await _storage.loadSocialLogs();

    _resetHeartsIfNewDay();
    _pickDailyChallenge();
    _ensureMonsterOfMonth();

    isLoading = false;
    notifyListeners();
  }

  // ---------- القلوب والنقط ----------

  void _resetHeartsIfNewDay() {
    if (profile.lastHeartsResetDate != todayKey()) {
      profile.hearts = 3;
      profile.lastHeartsResetDate = todayKey();
      _saveProfile();
    }
  }

  void addPoints(int amount) {
    profile.totalPoints += amount;
    _saveProfile();
    notifyListeners();
  }

  void loseHeart() {
    if (profile.hearts > 0) {
      profile.hearts -= 1;
      _saveProfile();
      notifyListeners();
    }
  }

  Future<void> _saveProfile() => _storage.saveProfile(profile);

  Future<void> updateProfile(UserProfile Function(UserProfile) updater) async {
    profile = updater(profile);
    await _saveProfile();
    notifyListeners();
  }

  Future<void> completeOnboarding(String name) async {
    profile.name = name;
    profile.hasOnboarded = true;
    await _saveProfile();
    notifyListeners();
  }

  // ---------- تحدي اليوم ----------

  void _pickDailyChallenge() {
    final key = todayKey();
    dailyChallenge = dailyChallengeFor(key);
  }

  // ---------- وحش الشهر ----------

  String get _monthKey =>
      "${DateTime.now().year}-${DateTime.now().month.toString().padLeft(2, '0')}";

  void _ensureMonsterOfMonth() {
    if (profile.monsterMonthKey != _monthKey) {
      for (final h in habits) {
        h.isMonsterOfMonth = false;
      }
      profile.monsterMonthKey = '';
    }
  }

  Habit? get monsterOfMonth {
    try {
      return habits.firstWhere((h) => h.isMonsterOfMonth && !h.isGood);
    } catch (_) {
      return null;
    }
  }

  Future<void> chooseMonsterOfMonth(Habit habit) async {
    // دوس تاني على نفس العادة = إلغاء وحش الشهر
    if (habit.isMonsterOfMonth) {
      habit.isMonsterOfMonth = false;
      profile.monsterMonthKey = '';
    } else {
      for (final h in habits) {
        h.isMonsterOfMonth = false;
      }
      habit.isMonsterOfMonth = true;
      profile.monsterMonthKey = _monthKey;
    }
    await _storage.saveHabits(habits);
    await _saveProfile();
    notifyListeners();
  }

  // ---------- العادات ----------

  Future<void> addHabit(String name, bool isGood, {int points = 10}) async {
    habits.add(Habit(name: name, isGood: isGood, pointsValue: points));
    await _storage.saveHabits(habits);
    notifyListeners();
  }

  Future<void> deleteHabit(Habit h) async {
    habits.removeWhere((x) => x.id == h.id);
    await _storage.saveHabits(habits);
    notifyListeners();
  }

  /// تسجيل إن العادة اتعملت النهاردة (كويسة أو وحشة)
  Future<void> markHabitToday(Habit h) async {
    final key = todayKey();
    if (h.completedDates.contains(key)) return;
    h.completedDates.add(key);

    if (h.isGood) {
      addPoints(h.pointsValue);
    } else {
      // عادة وحشة اتعملت = بتخسر نقط وقلب
      profile.totalPoints =
          (profile.totalPoints - h.pointsValue).clamp(0, 1 << 30).toInt();
      loseHeart();
    }
    await _storage.saveHabits(habits);
    await _saveProfile();
    notifyListeners();
  }

  Future<void> analyzeHabitWithAI(Habit h) async {
    final result = await ai.analyzeHabitImpact(
      habitName: h.name,
      isGood: h.isGood,
      currentStreakDays: h.currentStreak,
    );
    h.aiAnalysis = result;
    await _storage.saveHabits(habits);
    notifyListeners();
  }

  /// تطبيق خصم نقط/قلوب على العادات الكويسة اللي معملتهاش النهاردة (يتنادى آخر اليوم)
  Future<void> applyMissedGoodHabitsPenalty() async {
    bool changed = false;
    for (final h in habits) {
      if (h.isGood && !h.doneToday) {
        loseHeart();
        changed = true;
      }
    }
    if (changed) {
      await _storage.saveHabits(habits);
    }
  }

  // ---------- الأحلام ----------

  Future<void> addDreamWithAISteps(String title, String description) async {
    List<String> stepTexts = [];
    try {
      stepTexts =
          await ai.generateDreamSteps(title: title, description: description);
    } catch (_) {
      stepTexts = [];
    }
    final dream = Dream(
      title: title,
      description: description,
      steps: stepTexts.map((t) => DreamStep(text: t)).toList(),
    );
    dreams.add(dream);
    await _storage.saveDreams(dreams);
    notifyListeners();
  }

  Future<void> addAIStepsToDream(Dream d) async {
    final steps =
        await ai.generateDreamSteps(title: d.title, description: d.description);
    d.steps.addAll(steps.map((t) => DreamStep(text: t)));
    await _storage.saveDreams(dreams);
    notifyListeners();
  }

  Future<void> toggleDreamStep(Dream d, DreamStep s) async {
    s.isDone = !s.isDone;
    await _storage.saveDreams(dreams);
    if (s.isDone) addPoints(15);
    notifyListeners();
  }

  Future<void> deleteDream(Dream d) async {
    dreams.removeWhere((x) => x.id == d.id);
    await _storage.saveDreams(dreams);
    notifyListeners();
  }

  // ---------- المهام الأسبوعية ----------

  String get currentWeekKey {
    final now = DateTime.now();
    final firstDayOfYear = DateTime(now.year, 1, 1);
    final days = now.difference(firstDayOfYear).inDays;
    final weekNum = ((days + firstDayOfYear.weekday) / 7).ceil();
    return "${now.year}-W$weekNum";
  }

  List<WeeklyTask> get thisWeekTasks =>
      tasks.where((t) => t.weekKey == currentWeekKey).toList();

  Future<void> addWeeklyTask(String title) async {
    tasks.add(WeeklyTask(title: title, weekKey: currentWeekKey));
    await _storage.saveTasks(tasks);
    notifyListeners();
  }

  Future<void> toggleWeeklyTask(WeeklyTask t) async {
    t.isDone = !t.isDone;
    if (t.isDone) addPoints(20);
    await _storage.saveTasks(tasks);
    notifyListeners();
  }

  // ---------- الاشتراكات ----------

  double get monthlySubsTotal => subs.fold(0, (sum, s) => sum + s.price);

  Future<void> addSub(String name, double price, int day) async {
    subs.add(Subscription(name: name, price: price, billingDay: day));
    await _storage.saveSubs(subs);
    notifyListeners();
  }

  Future<void> deleteSub(Subscription s) async {
    subs.removeWhere((x) => x.id == s.id);
    await _storage.saveSubs(subs);
    notifyListeners();
  }

  // ---------- النوم / الوزن / السوشيال ميديا ----------

  Future<void> logSleep(double hours) async {
    sleepLogs.removeWhere((l) => l.date == todayKey());
    sleepLogs.add(DailyLog(date: todayKey(), value: hours));
    await _storage.saveSleepLogs(sleepLogs);
    notifyListeners();
  }

  Future<void> logWeight(double kg) async {
    weightLogs.removeWhere((l) => l.date == todayKey());
    weightLogs.add(DailyLog(date: todayKey(), value: kg));
    profile.weightKg = kg;
    await _storage.saveWeightLogs(weightLogs);
    await _saveProfile();
    notifyListeners();
  }

  Future<void> logSocialMinutes(double minutes) async {
    final existing = socialLogs.where((l) => l.date == todayKey());
    if (existing.isNotEmpty) {
      existing.first.value += minutes;
    } else {
      socialLogs.add(DailyLog(date: todayKey(), value: minutes));
    }
    await _storage.saveSocialLogs(socialLogs);
    notifyListeners();
  }

  String sleepFeedback(double hours) {
    if (hours < 6) return 'قليل شوية - جسمك محتاج راحة أكتر عشان تركيزك يفضل كويس.';
    if (hours <= 9) return 'كويس! دا معدل نوم صحي.';
    return 'كتير شوية - النوم الزيادة عن اللزوم برضو بيأثر على نشاطك.';
  }

  String socialMediaEquivalent(double minutes) {
    final options = [
      'ممكن تكون ذاكرت ${(minutes / 3).round()} كلمة جديدة في لغة',
      'ممكن تكون عملت تمرين رياضي ${minutes.round()} دقيقة',
      'ممكن تكون قريت ${(minutes / 2).round()} صفحة من كتاب',
      'ممكن تكون خلصت خطوة من حلمك',
    ];
    return options[(minutes.round()) % options.length];
  }

  // ---------- ملخص أسبوعي للـ AI ----------

  String buildWeeklySummary() {
    final doneGood = habits
        .where((h) => h.isGood)
        .map((h) => '${h.name}: ${h.currentStreak} يوم متتالي')
        .join('، ');
    final badDone = habits
        .where((h) => !h.isGood)
        .map((h) =>
            '${h.name}: اتعملت ${h.completedDates.length} مرة إجمالي')
        .join('، ');
    final doneTasks = thisWeekTasks.where((t) => t.isDone).length;
    final totalTasks = thisWeekTasks.length;
    return '''
النقط الحالية: ${profile.totalPoints}
القلوب المتبقية: ${profile.hearts}/3
العادات الكويسة: ${doneGood.isEmpty ? 'لا يوجد' : doneGood}
العادات الوحشة: ${badDone.isEmpty ? 'لا يوجد' : badDone}
المهام الأسبوعية: $doneTasks من $totalTasks خلصت
عدد الأحلام النشطة: ${dreams.length}
''';
  }

  Future<String> runWeeklyMeeting() {
    return ai.weeklyMeeting(weeklySummary: buildWeeklySummary());
  }

  String get aiContext => '''
الاسم: ${profile.name}
الشغل/الدراسة: ${profile.jobType ?? 'غير محدد'}
الهوايات: ${profile.hobbies.join('، ')}
الأهداف: ${profile.goals.join('، ')}
العادات: ${habits.map((h) => h.name).join('، ')}
الأحلام: ${dreams.map((d) => d.title).join('، ')}
النقط: ${profile.totalPoints}
''';

  Future<bool> testAIConnection() async {
    await ai.testConnection();
    return true;
  }

  Future<void> buildStarterPlan(Map<String, String> answers) async {
    // حاول نستخرج ساعات النوم من إجابات الأونبوردنج
    for (final e in answers.entries) {
      if (e.key.contains('نوم') || e.value.contains('بنام') || e.value.contains('ساعة')) {
        final m = RegExp(r'(\d+(?:[\\.,]\d+)?)').firstMatch(e.value);
        if (m != null) {
          final hours = double.tryParse(m.group(1)!.replaceAll(',', '.'));
          if (hours != null && hours > 0 && hours < 20) {
            profile.typicalSleepHours = hours;
            await logSleep(hours);
          }
        }
      }
    }

    try {
      final plan = await ai.generateStarterPlan(answers: answers);
      final good = (plan['good_habits'] as List? ?? [])
          .map((e) => e.toString().trim()).where((e) => e.isNotEmpty);
      final bad = (plan['bad_habits'] as List? ?? [])
          .map((e) => e.toString().trim()).where((e) => e.isNotEmpty);
      final weekly = (plan['weekly_tasks'] as List? ?? [])
          .map((e) => e.toString().trim()).where((e) => e.isNotEmpty);

      for (final name in good) {
        if (!habits.any((h) => h.name == name)) {
          habits.add(Habit(name: name, isGood: true, pointsValue: 10));
        }
      }
      for (final name in bad) {
        if (!habits.any((h) => h.name == name)) {
          habits.add(Habit(name: name, isGood: false, pointsValue: 10));
        }
      }
      for (final title in weekly) {
        if (!thisWeekTasks.any((t) => t.title == title)) {
          tasks.add(WeeklyTask(title: title, weekKey: currentWeekKey));
        }
      }

      final dreamTitle = (plan['dream_title'] ?? '').toString().trim();
      final dreamDescription = (plan['dream_description'] ?? '').toString().trim();
      if (dreamTitle.isNotEmpty && !dreams.any((d) => d.title == dreamTitle)) {
        dreams.add(Dream(title: dreamTitle, description: dreamDescription));
      }

      await _storage.saveHabits(habits);
      await _storage.saveTasks(tasks);
      await _storage.saveDreams(dreams);
      notifyListeners();
    } catch (_) {
      final good = answers['عادات عايز تثبتها'] ?? '';
      final bad = answers['حاجات عايز تقللها'] ?? '';
      if (good.isNotEmpty) {
        for (final item in good.split(RegExp(r'[,،\n]')).map((e) => e.trim()).where((e) => e.isNotEmpty).take(3)) {
          if (!habits.any((h) => h.name == item)) habits.add(Habit(name: item, isGood: true));
        }
      }
      if (bad.isNotEmpty) {
        for (final item in bad.split(RegExp(r'[,،\n]')).map((e) => e.trim()).where((e) => e.isNotEmpty).take(2)) {
          if (!habits.any((h) => h.name == item)) habits.add(Habit(name: item, isGood: false));
        }
      }
      await _storage.saveHabits(habits);
      notifyListeners();
    }
  }

  Future<void> editHabit(Habit h, {String? name, int? points}) async {
    if (name != null && name.trim().isNotEmpty) h.name = name.trim();
    if (points != null) h.pointsValue = points;
    await _storage.saveHabits(habits);
    notifyListeners();
  }

  Future<void> clearMonsterOfMonth() async {
    for (final h in habits) {
      h.isMonsterOfMonth = false;
    }
    profile.monsterMonthKey = '';
    await _storage.saveHabits(habits);
    await _saveProfile();
    notifyListeners();
  }

  Future<void> editWeeklyTask(WeeklyTask t, String title) async {
    t.title = title.trim();
    await _storage.saveTasks(tasks);
    notifyListeners();
  }

  Future<void> deleteWeeklyTask(WeeklyTask t) async {
    tasks.removeWhere((x) => x.id == t.id);
    await _storage.saveTasks(tasks);
    notifyListeners();
  }

}
