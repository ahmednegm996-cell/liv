import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class GeminiService {
  final String apiKey;
  final String model;
  final String provider;

  GeminiService({
    required this.apiKey,
    this.model = 'gemini-flash-lite-latest',
    this.provider = 'gemini',
  });

  bool get isConfigured => apiKey.trim().isNotEmpty;

  /// موديلات مجانية مستقرة (الأولوية لللي شغالين فعلاً على المفاتيح الجديدة)
  static const List<String> freeGeminiModels = [
    'gemini-flash-lite-latest',
    'gemini-flash-latest',
    'gemini-2.0-flash-lite',
    'gemini-2.0-flash',
    'gemini-2.5-flash',
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-2.5-flash-lite',
  ];

  static Future<void> _chain = Future.value();
  static DateTime _lastCall = DateTime.fromMillisecondsSinceEpoch(0);
  static int _consecutive429 = 0;

  static Duration get _minGap {
    if (_consecutive429 >= 3) return const Duration(seconds: 18);
    if (_consecutive429 >= 1) return const Duration(seconds: 8);
    return const Duration(seconds: 2);
  }

  Future<T> _enqueue<T>(Future<T> Function() job) {
    final c = Completer<T>();
    _chain = _chain.then((_) async {
      final gap = _minGap - DateTime.now().difference(_lastCall);
      if (gap > Duration.zero) await Future.delayed(gap);
      try {
        final r = await job();
        _lastCall = DateTime.now();
        _consecutive429 = 0;
        c.complete(r);
      } catch (e) {
        _lastCall = DateTime.now();
        c.completeError(e);
      }
    });
    return c.future;
  }

  Future<String> generateText(String prompt) {
    if (!isConfigured) {
      throw Exception(
        'محتاج تحط مفتاح API من البروفايل الأول.\n'
        'روح aistudio.google.com/apikey وخذ مفتاح مجاني.',
      );
    }
    return _enqueue(() => _generateWithRetry(prompt));
  }

  Future<String> _generateWithRetry(String prompt, {int attempt = 0}) async {
    try {
      if (provider == 'grok' || provider == 'groq') {
        return await _openAiCompatible(prompt);
      }
      return await _gemini(prompt);
    } catch (e) {
      final msg = e.toString();
      final is429 = msg.contains('429') ||
          msg.contains('حد الطلبات') ||
          msg.contains('RESOURCE_EXHAUSTED') ||
          msg.contains('quota') ||
          msg.contains('exceeded');
      final retriable = is429 ||
          msg.contains('Timeout') ||
          msg.contains('وقت طويل') ||
          msg.contains('500') ||
          msg.contains('503');

      if (is429) _consecutive429++;

      if (retriable && attempt < 4) {
        final waitSec = is429 ? (8 + attempt * 12) : (2 + attempt * 4);
        await Future.delayed(Duration(seconds: waitSec));
        return _generateWithRetry(prompt, attempt: attempt + 1);
      }

      if (is429) {
        throw Exception(
          'وصلت للحد المجاني (429).\n'
          'استنى دقيقة أو دقيقتين وجرب تاني.\n'
          'أو غيّر الموديل لـ gemini-flash-lite-latest من الإعدادات.',
        );
      }
      rethrow;
    }
  }

  Future<String> _gemini(String prompt) async {
    final models = <String>[
      if (model.isNotEmpty &&
          !model.startsWith('grok') &&
          !model.startsWith('llama'))
        model,
      ...freeGeminiModels,
    ];

    Object? lastErr;
    for (final m in models.toSet()) {
      try {
        final url = Uri.parse(
          'https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent',
        );
        final res = await http
            .post(
              url,
              headers: {
                'Content-Type': 'application/json',
                'x-goog-api-key': apiKey.trim(),
              },
              body: jsonEncode({
                'contents': [
                  {
                    'role': 'user',
                    'parts': [
                      {'text': prompt}
                    ]
                  }
                ],
                'generationConfig': {
                  'temperature': 0.75,
                  'maxOutputTokens': 1024,
                  'topP': 0.95,
                },
              }),
            )
            .timeout(const Duration(seconds: 50));

        if (res.statusCode == 429) throw Exception('429 حد الطلبات');
        if (res.statusCode == 401 || res.statusCode == 403) {
          final body = utf8.decode(res.bodyBytes);
          if (body.contains('API_KEY_INVALID') ||
              body.contains('API key not valid')) {
            throw Exception(
              'مفتاح Gemini غير صحيح.\n'
              'تأكد إنك نسخته كامل من aistudio.google.com/apikey',
            );
          }
          throw Exception(
            'المفتاح مش مفعّل أو مفيش صلاحية.\n'
            'افتح AI Studio وتأكد إن Generative Language API شغال.',
          );
        }
        if (res.statusCode == 404) {
          lastErr = Exception('الموديل $m مش متاح');
          continue;
        }
        if (res.statusCode >= 500) {
          throw Exception(
              'خدمة Gemini فيها مشكلة مؤقتة (${res.statusCode}).');
        }
        if (res.statusCode != 200) {
          final body = utf8.decode(res.bodyBytes);
          if (body.contains('RESOURCE_EXHAUSTED') || body.contains('quota')) {
            throw Exception('429 حد الطلبات');
          }
          lastErr = Exception('Gemini رجّع ${res.statusCode}');
          continue;
        }

        final data = jsonDecode(utf8.decode(res.bodyBytes));
        final candidates = data['candidates'];
        if (candidates is List && candidates.isNotEmpty) {
          final content = candidates[0]['content'];
          final parts = content is Map ? content['parts'] : null;
          if (parts is List) {
            final text = parts
                .map((p) => p is Map ? (p['text'] ?? '') : '')
                .where((x) => x.toString().trim().isNotEmpty)
                .join('\n')
                .trim();
            if (text.isNotEmpty) return text;
          }
        }
        final block = data['promptFeedback']?['blockReason'];
        if (block != null) {
          throw Exception('الطلب اترفض من Google ($block).');
        }
        throw Exception('Gemini رجّع رد فاضي.');
      } on TimeoutException {
        lastErr = Exception('الاتصال أخد وقت طويل. تأكد من النت.');
      } on SocketException {
        throw Exception('مفيش إنترنت. تأكد إن Wi‑Fi أو البيانات شغالة.');
      } on HandshakeException {
        throw Exception('مشكلة أمان في الاتصال. جرّب شبكة تانية.');
      } catch (e) {
        lastErr = e;
        final s = e.toString();
        if (s.contains('429') ||
            s.contains('غير صحيح') ||
            s.contains('إنترنت') ||
            s.contains('حد الطلبات') ||
            s.contains('صلاحية')) {
          rethrow;
        }
      }
    }
    throw lastErr ??
        Exception('فشل الاتصال بـ Gemini. جرب موديل تاني من الإعدادات.');
  }

  Future<String> _openAiCompatible(String prompt) async {
    final isGrok = provider == 'grok';
    final base = isGrok
        ? 'https://api.x.ai/v1/chat/completions'
        : 'https://api.groq.com/openai/v1/chat/completions';
    final mdl = isGrok
        ? (model.isEmpty || model.startsWith('gemini')
            ? 'grok-2-latest'
            : model)
        : (model.isEmpty || model.startsWith('gemini')
            ? 'llama-3.3-70b-versatile'
            : model);

    final res = await http
        .post(
          Uri.parse(base),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${apiKey.trim()}',
          },
          body: jsonEncode({
            'model': mdl,
            'messages': [
              {'role': 'user', 'content': prompt}
            ],
            'temperature': 0.7,
            'max_tokens': 1024,
          }),
        )
        .timeout(const Duration(seconds: 50));

    if (res.statusCode == 429) throw Exception('429 حد الطلبات');
    if (res.statusCode == 401 || res.statusCode == 403) {
      throw Exception('مفتاح ${isGrok ? 'Grok' : 'Groq'} غير صحيح.');
    }
    if (res.statusCode != 200) {
      throw Exception('API رجّع ${res.statusCode}');
    }
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    final text = data['choices']?[0]?['message']?['content'];
    if (text == null || (text as String).trim().isEmpty) {
      throw Exception('رد فاضي من الـ API.');
    }
    return text.trim();
  }

  Future<String> testConnection() =>
      generateText('Reply with one word only: OK');

  Future<List<String>> generateDreamSteps({
    required String title,
    required String description,
  }) async {
    final text = await generateText('''
أنت مخطط أهداف عملي. حلم المستخدم: "$title".
التفاصيل: "$description".
اكتب 6 خطوات زمنية عملية، كل خطوة سطر واحد:
(يوم 1-3) فعل...
(الأسبوع 2) فعل...
بدون مقدمات.
''');
    return text
        .split('\n')
        .map((l) => l.replaceFirst(RegExp(r'^[\-\*\d\.\)\s]+'), '').trim())
        .where((l) => l.isNotEmpty)
        .take(8)
        .toList();
  }

  Future<String> weeklyMeeting({required String weeklySummary}) =>
      generateText('''
ميتنج أسبوعي. الملخص:
$weeklySummary
باختصار: 1) إنجاز 2) مشكلة 3) خطوة واحدة للأسبوع الجاي.
''');

  Future<String> dailyMeeting({required String dailySummary}) =>
      generateText('''
ميتنج سريع آخر اليوم:
$dailySummary
في 4 أسطر: اللي اتعمل، اللي اتأجل، حاجة واحدة بكرة.
''');

  Future<String> analyzeHabitImpact({
    required String habitName,
    required bool isGood,
    required int currentStreakDays,
  }) =>
      generateText(
        'عادة ${isGood ? 'كويسة' : 'وحشة'}: "$habitName" — $currentStreakDays يوم. '
        'تأثير 3-12 شهر + نصيحة. 5 جمل.',
      );

  Future<Map<String, dynamic>> generateStarterPlan({
    required Map<String, String> answers,
  }) async {
    final context =
        answers.entries.map((e) => '${e.key}: ${e.value}').join('\n');
    final text = await generateText('''
بيانات مستخدم Liv:
$context
JSON فقط:
{"good_habits":[".."],"bad_habits":[".."],"weekly_tasks":[".."],"dream_title":"..","dream_description":".."}
''');
    final cleaned = text
        .replaceFirst(RegExp(r'^```json\s*', multiLine: true), '')
        .replaceFirst(RegExp(r'^```\s*', multiLine: true), '')
        .replaceFirst(RegExp(r'\s*```$', multiLine: true), '')
        .trim();
    final start = cleaned.indexOf('{');
    final end = cleaned.lastIndexOf('}');
    final jsonStr = (start >= 0 && end > start)
        ? cleaned.substring(start, end + 1)
        : cleaned;
    final decoded = jsonDecode(jsonStr);
    if (decoded is! Map<String, dynamic>) {
      throw Exception('خطة البداية غير مفهومة.');
    }
    return decoded;
  }

  Future<String> chat({
    required String userMessage,
    required String context,
    List<Map<String, String>> history = const [],
  }) {
    final previous = history.take(8).map((m) {
      final who = m['role'] == 'user' ? 'مستخدم' : 'Liv';
      return '$who: ${m['text']}';
    }).join('\n');
    return generateText('''
أنت Liv AI — مساعد حياة هادئ، ودود، عملي، مختصر. صوتك مطمئن مش مخيف.
سياق: $context
محادثة: $previous
رسالة: $userMessage
رد بهدوء ووضوح.
''');
  }
}
