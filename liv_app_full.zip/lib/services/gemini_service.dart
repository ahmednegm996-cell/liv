import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

/// خدمة AI قوية لـ Gemini (مجاني) + Grok + Groq
/// - موديلات مجانية حديثة 2026
/// - طابور طلبات + backoff ذكي لـ 429
/// - fallback تلقائي بين الموديلات
class GeminiService {
  final String apiKey;
  final String model;
  final String provider; // gemini | grok | groq

  GeminiService({
    required this.apiKey,
    this.model = 'gemini-2.5-flash',
    this.provider = 'gemini',
  });

  bool get isConfigured => apiKey.trim().isNotEmpty;

  /// موديلات مجانية مستقرة (مرتبة من الأفضل للباقة المجانية)
  static const List<String> freeGeminiModels = [
    'gemini-2.5-flash',
    'gemini-2.5-flash-lite',
    'gemini-3.5-flash-lite',
    'gemini-3.6-flash',
    'gemini-3.5-flash',
    'gemini-2.0-flash',
    'gemini-flash-latest',
    'gemini-flash-lite-latest',
  ];

  // طابور عام لكل الطلبات عشان ما نضربش الحد
  static Future<void> _chain = Future.value();
  static DateTime _lastCall = DateTime.fromMillisecondsSinceEpoch(0);
  static int _consecutive429 = 0;

  static Duration get _minGap {
    if (_consecutive429 >= 3) return const Duration(seconds: 15);
    if (_consecutive429 >= 1) return const Duration(seconds: 8);
    return const Duration(seconds: 2);
  }

  Future<T> _enqueue<T>(Future<T> Function() job) {
    final c = Completer<T>();
    _chain = _chain.then((_) async {
      final gap = _minGap - DateTime.now().difference(_lastCall);
      if (gap > Duration.zero) {
        await Future.delayed(gap);
      }
      try {
        final r = await job();
        _lastCall = DateTime.now();
        _consecutive429 = 0;
        c.complete(r);
      } catch (e) {
        _lastCall = DateTime.now();
        c.completeError(e);
      }
    });
    return c.future;
  }

  Future<String> generateText(String prompt) {
    if (!isConfigured) {
      throw Exception(
        'محتاج تحط مفتاح API من البروفايل الأول.\n'
        'روح aistudio.google.com/apikey وخذ مفتاح مجاني.',
      );
    }
    return _enqueue(() => _generateWithRetry(prompt));
  }

  Future<String> _generateWithRetry(String prompt, {int attempt = 0}) async {
    try {
      if (provider == 'grok' || provider == 'groq') {
        return await _openAiCompatible(prompt);
      }
      return await _gemini(prompt);
    } catch (e) {
      final msg = e.toString();
      final is429 = msg.contains('429') ||
          msg.contains('حد الطلبات') ||
          msg.contains('RESOURCE_EXHAUSTED') ||
          msg.contains('quota');
      final retriable = is429 ||
          msg.contains('Timeout') ||
          msg.contains('وقت طويل') ||
          msg.contains('500') ||
          msg.contains('503') ||
          msg.contains('UNAVAILABLE');

      if (is429) _consecutive429++;

      if (retriable && attempt < 4) {
        final waitSec = is429 ? (6 + attempt * 12) : (2 + attempt * 4);
        await Future.delayed(Duration(seconds: waitSec));
        return _generateWithRetry(prompt, attempt: attempt + 1);
      }

      if (is429) {
        throw Exception(
          'وصلت للحد المجاني من Google (خطأ 429).\n'
          'استنى دقيقة أو دقيقتين وجرب تاني.\n'
          'نصيحة: جرّب موديل gemini-2.5-flash-lite من الإعدادات — حده أعلى.',
        );
      }
      rethrow;
    }
  }

  Future<String> _gemini(String prompt) async {
    // ترتيب ذكي: الموديل المختار أولاً، بعدين أفضل الموديلات المجانية
    final models = <String>[
      if (model.isNotEmpty && !model.startsWith('grok') && !model.startsWith('llama'))
        model,
      ...freeGeminiModels,
    ];

    Object? lastErr;
    for (final m in models.toSet()) {
      try {
        final url = Uri.parse(
          'https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent',
        );
        final res = await http
            .post(
              url,
              headers: {
                'Content-Type': 'application/json',
                'x-goog-api-key': apiKey.trim(),
              },
              body: jsonEncode({
                'contents': [
                  {
                    'role': 'user',
                    'parts': [
                      {'text': prompt}
                    ]
                  }
                ],
                'generationConfig': {
                  'temperature': 0.75,
                  'maxOutputTokens': 1024,
                  'topP': 0.95,
                },
              }),
            )
            .timeout(const Duration(seconds: 50));

        if (res.statusCode == 429) {
          throw Exception('429 حد الطلبات');
        }
        if (res.statusCode == 401 || res.statusCode == 403) {
          final body = utf8.decode(res.bodyBytes);
          if (body.contains('API_KEY_INVALID') || body.contains('API key not valid')) {
            throw Exception(
              'مفتاح Gemini غير صحيح.\n'
              'تأكد إنك نسخته كامل من aistudio.google.com/apikey',
            );
          }
          throw Exception(
            'المفتاح مش مفعّل أو مفيش صلاحية للـ API.\n'
            'افتح AI Studio وتأكد إن الـ Generative Language API شغال.',
          );
        }
        if (res.statusCode == 404) {
          lastErr = Exception('الموديل $m مش متاح على حسابك');
          continue;
        }
        if (res.statusCode >= 500) {
          throw Exception('خدمة Gemini فيها مشكلة مؤقتة (${res.statusCode}). جرب بعد شوية.');
        }
        if (res.statusCode != 200) {
          final body = utf8.decode(res.bodyBytes);
          if (body.contains('RESOURCE_EXHAUSTED') || body.contains('quota')) {
            throw Exception('429 حد الطلبات');
          }
          lastErr = Exception('Gemini رجّع ${res.statusCode}');
          continue;
        }

        final data = jsonDecode(utf8.decode(res.bodyBytes));
        final candidates = data['candidates'];
        if (candidates is List && candidates.isNotEmpty) {
          final content = candidates[0]['content'];
          final parts = content is Map ? content['parts'] : null;
          if (parts is List) {
            final text = parts
                .map((p) => p is Map ? (p['text'] ?? '') : '')
                .where((x) => x.toString().trim().isNotEmpty)
                .join('\n')
                .trim();
            if (text.isNotEmpty) return text;
          }
        }

        final block = data['promptFeedback']?['blockReason'];
        if (block != null) {
          throw Exception('الطلب اترفض من Google ($block). غيّر صيغة السؤال.');
        }
        final finish = candidates is List && candidates.isNotEmpty
            ? candidates[0]['finishReason']
            : null;
        if (finish == 'SAFETY') {
          throw Exception('الرد اترفض لأسباب أمان. جرب سؤال تاني.');
        }
        throw Exception('Gemini رجّع رد فاضي.');
      } on TimeoutException {
        lastErr = Exception('الاتصال أخد وقت طويل. تأكد من النت وجرب تاني.');
      } on SocketException {
        throw Exception('مفيش إنترنت. تأكد إن Wi‑Fi أو البيانات شغالة.');
      } on HandshakeException {
        throw Exception('مشكلة أمان في الاتصال. جرّب شبكة تانية.');
      } catch (e) {
        lastErr = e;
        final s = e.toString();
        if (s.contains('429') ||
            s.contains('غير صحيح') ||
            s.contains('إنترنت') ||
            s.contains('حد الطلبات') ||
            s.contains('صلاحية')) {
          rethrow;
        }
      }
    }
    throw lastErr ?? Exception('فشل الاتصال بـ Gemini. جرب موديل تاني من الإعدادات.');
  }

  Future<String> _openAiCompatible(String prompt) async {
    final isGrok = provider == 'grok';
    final base = isGrok
        ? 'https://api.x.ai/v1/chat/completions'
        : 'https://api.groq.com/openai/v1/chat/completions';
    final mdl = isGrok
        ? (model.isEmpty || model.startsWith('gemini') ? 'grok-2-latest' : model)
        : (model.isEmpty || model.startsWith('gemini')
            ? 'llama-3.3-70b-versatile'
            : model);

    final res = await http
        .post(
          Uri.parse(base),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${apiKey.trim()}',
          },
          body: jsonEncode({
            'model': mdl,
            'messages': [
              {'role': 'user', 'content': prompt}
            ],
            'temperature': 0.7,
            'max_tokens': 1024,
          }),
        )
        .timeout(const Duration(seconds: 50));

    if (res.statusCode == 429) throw Exception('429 حد الطلبات');
    if (res.statusCode == 401 || res.statusCode == 403) {
      throw Exception('مفتاح ${isGrok ? 'Grok' : 'Groq'} غير صحيح.');
    }
    if (res.statusCode != 200) {
      throw Exception('API رجّع ${res.statusCode}');
    }
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    final text = data['choices']?[0]?['message']?['content'];
    if (text == null || (text as String).trim().isEmpty) {
      throw Exception('رد فاضي من الـ API.');
    }
    return text.trim();
  }

  Future<String> testConnection() =>
      generateText('Reply with one word only: OK');

  Future<List<String>> generateDreamSteps({
    required String title,
    required String description,
  }) async {
    final text = await generateText('''
أنت مخطط أهداف عملي. حلم المستخدم: "$title".
التفاصيل: "$description".
اكتب 6 خطوات زمنية عملية بالعربي المصري، كل خطوة في سطر واحد فقط بهذا الشكل:
(يوم 1-3) فعل واضح...
(الأسبوع 2) فعل واضح...
بدون كلام تحفيزي فاضي أو مقدمات.
''');
    return text
        .split('\n')
        .map((l) => l.replaceFirst(RegExp(r'^[\-\*\d\.\)\s]+'), '').trim())
        .where((l) => l.isNotEmpty)
        .take(8)
        .toList();
  }

  Future<String> weeklyMeeting({required String weeklySummary}) =>
      generateText('''
ميتنج أسبوعي مع المستخدم. الملخص:
$weeklySummary
بالعربي المصري المختصر جداً:
1) إنجاز واضح
2) مشكلة أو عائق
3) خطوة واحدة فقط للأسبوع الجاي
بدون مقدمات.
''');

  Future<String> dailyMeeting({required String dailySummary}) =>
      generateText('''
ميتنج سريع آخر اليوم:
$dailySummary
بالعربي المصري في 4 أسطر كحد أقصى: اللي اتعمل، اللي اتأجل، حاجة واحدة بكرة.
''');

  Future<String> personalityInsight({required String profileSummary}) =>
      generateText('بيانات:\n$profileSummary\nتحليل بنّاء وعملي في 5 جمل بالعربي المصري.');

  Future<String> analyzeHabitImpact({
    required String habitName,
    required bool isGood,
    required int currentStreakDays,
  }) =>
      generateText(
        'عادة ${isGood ? 'كويسة' : 'وحشة'}: "$habitName" — استمرار $currentStreakDays يوم.\n'
        'اكتب تأثيرها خلال 3–12 شهر + نصيحة عملية واحدة. 5 جمل بالعربي المصري.',
      );

  Future<Map<String, dynamic>> generateStarterPlan({
    required Map<String, String> answers,
  }) async {
    final context =
        answers.entries.map((e) => '${e.key}: ${e.value}').join('\n');
    final text = await generateText('''
بيانات مستخدم تطبيق Liv:
$context
رجّع JSON فقط بدون أي نص قبله أو بعده:
{"good_habits":["عادة1","عادة2"],"bad_habits":["عادة1"],"weekly_tasks":["مهمة1","مهمة2"],"dream_title":"عنوان","dream_description":"وصف قصير"}
''');
    final cleaned = text
        .replaceFirst(RegExp(r'^```json\s*', multiLine: true), '')
        .replaceFirst(RegExp(r'^```\s*', multiLine: true), '')
        .replaceFirst(RegExp(r'\s*```$', multiLine: true), '')
        .trim();
    // استخراج أول object JSON لو في كلام زيادة
    final start = cleaned.indexOf('{');
    final end = cleaned.lastIndexOf('}');
    final jsonStr = (start >= 0 && end > start)
        ? cleaned.substring(start, end + 1)
        : cleaned;
    final decoded = jsonDecode(jsonStr);
    if (decoded is! Map<String, dynamic>) {
      throw Exception('خطة البداية غير مفهومة.');
    }
    return decoded;
  }

  Future<String> chat({
    required String userMessage,
    required String context,
    List<Map<String, String>> history = const [],
  }) {
    final previous = history.take(8).map((m) {
      final who = m['role'] == 'user' ? 'مستخدم' : 'Liv';
      return '$who: ${m['text']}';
    }).join('\n');
    return generateText('''
أنت Liv AI — مساعد حياة شخصي مصري، مختصر، عملي، ودود بدون مبالغة.
سياق المستخدم: $context
محادثة سابقة:
$previous
رسالة المستخدم: $userMessage
رد باختصار ووضوح.
''');
  }
}
