
import 'package:audioplayers/audioplayers.dart';

class AudioService {
  AudioService._();
  static final AudioService instance = AudioService._();

  final AudioPlayer _player = AudioPlayer();
  String? _currentAsset;

  Future<void> playLoop(String assetPath) async {
    if (_currentAsset == assetPath && _player.state == PlayerState.playing) return;
    await _player.stop();
    _currentAsset = assetPath;
    await _player.setReleaseMode(ReleaseMode.loop);
    await _player.setVolume(0.16);
    await _player.play(AssetSource(assetPath.replaceFirst('assets/', '')));
  }

  Future<void> stop() async {
    _currentAsset = null;
    await _player.stop();
  }
}
