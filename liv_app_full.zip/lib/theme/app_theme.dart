import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  // accents
  static const purple = Color(0xFF8B5CF6);
  static const purpleDark = Color(0xFF6D28D9);
  static const teal = Color(0xFF14B8A6);
  static const blue = Color(0xFF3B82F6);
  static const orange = Color(0xFFF59E0B);
  static const pink = Color(0xFFEC4899);

  // danger (قلوب خلصت)
  static const danger = Color(0xFFE11D48);
  static const dangerDark = Color(0xFF9F1239);
  static const dangerBg = Color(0xFF1A0A0E);
  static const dangerCard = Color(0xFF2A1218);

  static const bgLight = Color(0xFFF5F6FA);
  static const cardLight = Color(0xFFFFFFFF);
  static const bgDark = Color(0xFF0F0F16);
  static const cardDark = Color(0xFF1A1A26);
  static const heartRed = Color(0xFFFF4D6D);

  // backward-compat aliases
  static const primary = purple;
  static const primaryDark = purpleDark;
  static const accentTeal = teal;
  static const accentPink = pink;
  static const accentOrange = orange;

  static Color accentFrom(String key) {
    switch (key) {
      case 'teal':
        return teal;
      case 'blue':
        return blue;
      case 'orange':
        return orange;
      case 'pink':
        return pink;
      case 'purple':
      default:
        return purple;
    }
  }

  static Color accentDarkFrom(String key) {
    switch (key) {
      case 'teal':
        return const Color(0xFF0D9488);
      case 'blue':
        return const Color(0xFF2563EB);
      case 'orange':
        return const Color(0xFFD97706);
      case 'pink':
        return const Color(0xFFDB2777);
      case 'purple':
      default:
        return purpleDark;
    }
  }
}

class AppTheme {
  static ThemeData light({String accent = 'purple', bool danger = false}) {
    final primary = danger ? AppColors.danger : AppColors.accentFrom(accent);
    final base = ThemeData.light(useMaterial3: true);
    final textTheme = GoogleFonts.plusJakartaSansTextTheme(base.textTheme);
    return base.copyWith(
      scaffoldBackgroundColor: danger ? const Color(0xFFFFF1F2) : AppColors.bgLight,
      textTheme: textTheme.apply(
        bodyColor: const Color(0xFF1A1A2E),
        displayColor: const Color(0xFF1A1A2E),
      ),
      colorScheme: base.colorScheme.copyWith(
        primary: primary,
        secondary: AppColors.teal,
        error: AppColors.danger,
        surface: AppColors.cardLight,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: danger ? const Color(0xFFFFF1F2) : AppColors.bgLight,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: const Color(0xFF1A1A2E),
        titleTextStyle: GoogleFonts.plusJakartaSans(
          fontSize: 20, fontWeight: FontWeight.w700, color: const Color(0xFF1A1A2E),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: AppColors.cardLight,
        indicatorColor: primary.withOpacity(0.14),
        elevation: 8,
        shadowColor: Colors.black12,
        height: 70,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return GoogleFonts.plusJakartaSans(fontSize: 12, fontWeight: FontWeight.w700, color: primary);
          }
          return GoogleFonts.plusJakartaSans(fontSize: 11, fontWeight: FontWeight.w500, color: Colors.black45);
        }),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 15),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 0,
          textStyle: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w700, fontSize: 15),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: primary,
          side: BorderSide(color: primary.withOpacity(0.4)),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: primary,
        foregroundColor: Colors.white,
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.black.withOpacity(0.04),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: primary, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      chipTheme: ChipThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        side: BorderSide.none,
      ),
      cardColor: AppColors.cardLight,
      dividerColor: Colors.black.withOpacity(0.06),
    );
  }

  static ThemeData dark({String accent = 'purple', bool danger = false}) {
    final primary = danger ? AppColors.danger : AppColors.accentFrom(accent);
    final bg = danger ? AppColors.dangerBg : AppColors.bgDark;
    final card = danger ? AppColors.dangerCard : AppColors.cardDark;
    final base = ThemeData.dark(useMaterial3: true);
    final textTheme = GoogleFonts.plusJakartaSansTextTheme(base.textTheme);
    return base.copyWith(
      scaffoldBackgroundColor: bg,
      textTheme: textTheme.apply(
        bodyColor: Colors.white,
        displayColor: Colors.white,
      ),
      colorScheme: base.colorScheme.copyWith(
        primary: primary,
        secondary: AppColors.teal,
        surface: card,
        error: AppColors.danger,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: bg,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: Colors.white,
        titleTextStyle: GoogleFonts.plusJakartaSans(
          fontSize: 20, fontWeight: FontWeight.w700, color: Colors.white,
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: card,
        indicatorColor: primary.withOpacity(0.22),
        elevation: 0,
        height: 70,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return GoogleFonts.plusJakartaSans(fontSize: 12, fontWeight: FontWeight.w700, color: primary);
          }
          return GoogleFonts.plusJakartaSans(fontSize: 11, fontWeight: FontWeight.w500, color: Colors.white54);
        }),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 15),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 0,
          textStyle: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w700, fontSize: 15),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: primary,
          side: BorderSide(color: primary.withOpacity(0.45)),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: primary,
        foregroundColor: Colors.white,
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white.withOpacity(0.06),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: primary, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      chipTheme: ChipThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        side: BorderSide.none,
      ),
      cardColor: card,
      dividerColor: Colors.white.withOpacity(0.08),
    );
  }
}

Color secondaryText(BuildContext context) {
  return Theme.of(context).brightness == Brightness.dark
      ? Colors.white60
      : Colors.black54;
}

Color mutedText(BuildContext context) => secondaryText(context);

Color strongText(BuildContext context) {
  return Theme.of(context).brightness == Brightness.dark
      ? Colors.white
      : Colors.black87;
}

Color subtleIcon(BuildContext context) {
  return Theme.of(context).brightness == Brightness.dark
      ? Colors.white54
      : Colors.black45;
}

class Gaps {
  static const h4 = SizedBox(height: 4);
  static const h8 = SizedBox(height: 8);
  static const h10 = SizedBox(height: 10);
  static const h12 = SizedBox(height: 12);
  static const h16 = SizedBox(height: 16);
  static const h18 = SizedBox(height: 18);
  static const h20 = SizedBox(height: 20);
  static const h24 = SizedBox(height: 24);
  static const h32 = SizedBox(height: 32);
  static const w8 = SizedBox(width: 8);
  static const w12 = SizedBox(width: 12);
}
