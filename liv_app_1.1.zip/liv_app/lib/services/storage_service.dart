// خدمة تخزين محلية بسيطة على الجهاز (SharedPreferences) بدون سيرفر.
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models.dart';

class StorageService {
  static const _kProfile = 'liv_profile';
  static const _kHabits = 'liv_habits';
  static const _kDreams = 'liv_dreams';
  static const _kTasks = 'liv_tasks';
  static const _kSubs = 'liv_subs';
  static const _kSleep = 'liv_sleep';
  static const _kWeight = 'liv_weight';
  static const _kSocial = 'liv_social';
  static const _kDailyTasks = 'liv_daily_tasks';
  static const _kChat = 'liv_chat_history';

  Future<UserProfile> loadProfile() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kProfile);
    if (raw == null) return UserProfile();
    return UserProfile.fromJson(jsonDecode(raw));
  }

  Future<void> saveProfile(UserProfile p) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kProfile, jsonEncode(p.toJson()));
  }

  Future<List<Habit>> loadHabits() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_kHabits) ?? [];
    return raw.map((s) => Habit.fromJson(jsonDecode(s))).toList();
  }

  Future<void> saveHabits(List<Habit> habits) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
        _kHabits, habits.map((h) => jsonEncode(h.toJson())).toList());
  }

  Future<List<Dream>> loadDreams() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_kDreams) ?? [];
    return raw.map((s) => Dream.fromJson(jsonDecode(s))).toList();
  }

  Future<void> saveDreams(List<Dream> dreams) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
        _kDreams, dreams.map((d) => jsonEncode(d.toJson())).toList());
  }

  Future<List<WeeklyTask>> loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_kTasks) ?? [];
    return raw.map((s) => WeeklyTask.fromJson(jsonDecode(s))).toList();
  }

  Future<void> saveTasks(List<WeeklyTask> tasks) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
        _kTasks, tasks.map((t) => jsonEncode(t.toJson())).toList());
  }

  Future<List<Subscription>> loadSubs() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_kSubs) ?? [];
    return raw.map((s) => Subscription.fromJson(jsonDecode(s))).toList();
  }

  Future<void> saveSubs(List<Subscription> subs) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
        _kSubs, subs.map((s) => jsonEncode(s.toJson())).toList());
  }

  Future<List<DailyLog>> _loadLog(String key) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(key) ?? [];
    return raw.map((s) => DailyLog.fromJson(jsonDecode(s))).toList();
  }

  Future<void> _saveLog(String key, List<DailyLog> logs) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
        key, logs.map((l) => jsonEncode(l.toJson())).toList());
  }


  Future<List<DailyTask>> loadDailyTasks() async { final prefs=await SharedPreferences.getInstance(); final raw=prefs.getStringList(_kDailyTasks)??[]; return raw.map((s)=>DailyTask.fromJson(jsonDecode(s))).toList(); }
  Future<void> saveDailyTasks(List<DailyTask> tasks) async { final prefs=await SharedPreferences.getInstance(); await prefs.setStringList(_kDailyTasks,tasks.map((t)=>jsonEncode(t.toJson())).toList()); }
  Future<List<ChatMessage>> loadChat() async { final prefs=await SharedPreferences.getInstance(); final raw=prefs.getStringList(_kChat)??[]; return raw.map((s)=>ChatMessage.fromJson(jsonDecode(s))).toList(); }
  Future<void> saveChat(List<ChatMessage> messages) async { final prefs=await SharedPreferences.getInstance(); await prefs.setStringList(_kChat,messages.map((m)=>jsonEncode(m.toJson())).toList()); }
  Future<void> clearChat() async { final prefs=await SharedPreferences.getInstance(); await prefs.remove(_kChat); }

  Future<List<DailyLog>> loadSleepLogs() => _loadLog(_kSleep);
  Future<void> saveSleepLogs(List<DailyLog> l) => _saveLog(_kSleep, l);

  Future<List<DailyLog>> loadWeightLogs() => _loadLog(_kWeight);
  Future<void> saveWeightLogs(List<DailyLog> l) => _saveLog(_kWeight, l);

  Future<List<DailyLog>> loadSocialLogs() => _loadLog(_kSocial);
  Future<void> saveSocialLogs(List<DailyLog> l) => _saveLog(_kSocial, l);
}
