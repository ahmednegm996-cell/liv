import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// كارت أساسي بتصميم موحد في كل التطبيق
class SectionCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const SectionCard(
      {super.key, required this.child, this.padding = const EdgeInsets.all(18)});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: isDark ? AppColors.cardDark : AppColors.cardLight,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDark ? 0.3 : 0.05),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: child,
    );
  }
}

/// عرض ٣ قلوب (متبقية النهاردة)
class HeartsRow extends StatelessWidget {
  final int hearts;
  const HeartsRow({super.key, required this.hearts});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (i) {
        final filled = i < hearts;
        return Padding(
          padding: const EdgeInsets.only(left: 4),
          child: Icon(
            filled ? Icons.favorite : Icons.favorite_border,
            color: AppColors.heartRed,
            size: 26,
          ),
        );
      }),
    );
  }
}

/// شارة النقط
class PointsChip extends StatelessWidget {
  final int points;
  const PointsChip({super.key, required this.points});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Theme.of(context).colorScheme.primary, Theme.of(context).colorScheme.secondary],
        ),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.star_rounded, color: Colors.white, size: 18),
          Gaps.w8,
          Text(
            '$points نقطة',
            style: const TextStyle(
                color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14),
          ),
        ],
      ),
    );
  }
}

/// شريط تقدم بسيط بتصميم مبسّط
class ProgressBarWithLabel extends StatelessWidget {
  final double progress; // 0..1
  final String label;
  const ProgressBarWithLabel(
      {super.key, required this.progress, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
            Text('${(progress * 100).round()}%',
                style: TextStyle(
                    color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w700)),
          ],
        ),
        Gaps.h8,
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: LinearProgressIndicator(
            value: progress.clamp(0.0, 1.0).toDouble(),
            minHeight: 10,
            backgroundColor: Theme.of(context).brightness == Brightness.dark
                ? Colors.white.withOpacity(0.1)
                : Colors.black.withOpacity(0.06),
            valueColor: AlwaysStoppedAnimation(Theme.of(context).colorScheme.primary),
          ),
        ),
      ],
    );
  }
}

/// رسم بياني بسيط بالأعمدة (بدون مكتبات خارجية) لعرض اتجاه قيم زمنية
class SimpleBarChart extends StatelessWidget {
  final List<double> values;
  final List<String> labels;
  final Color color;
  const SimpleBarChart(
      {super.key, required this.values, required this.labels, this.color = AppColors.primary});

  @override
  Widget build(BuildContext context) {
    if (values.isEmpty) {
      return const SizedBox(
        height: 120,
        child: Center(child: Text('لسه مفيش بيانات كفاية')),
      );
    }
    final maxVal = values.reduce((a, b) => a > b ? a : b);
    return SizedBox(
      height: 140,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(values.length, (i) {
          final h = maxVal == 0 ? 4.0 : (values[i] / maxVal) * 100 + 4;
          return Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(values[i].toStringAsFixed(1),
                  style: TextStyle(fontSize: 10, color: secondaryText(context))),
              Gaps.h4,
              Container(
                width: 18,
                height: h,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
              Gaps.h4,
              Text(labels[i], style: const TextStyle(fontSize: 10)),
            ],
          );
        }),
      ),
    );
  }
}

Future<String?> showTextInputDialog(
  BuildContext context, {
  required String title,
  String hint = '',
  String initial = '',
}) async {
  final controller = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      title: Text(title),
      content: TextField(
        controller: controller,
        autofocus: true,
        decoration: InputDecoration(hintText: hint),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        ElevatedButton(
          onPressed: () => Navigator.pop(ctx, controller.text.trim()),
          child: const Text('حفظ'),
        ),
      ],
    ),
  );
}
