// كل الموديلات (نماذج البيانات) بتاعة تطبيق Liv في مكان واحد للتبسيط.
import 'package:uuid/uuid.dart';

const _uuid = Uuid();
String newId() => _uuid.v4();

String todayKey([DateTime? d]) {
  final date = d ?? DateTime.now();
  return "${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";
}

/// عادة يومية (كويسة أو وحشة)
class Habit {
  String id;
  String name;
  bool isGood; // true = عادة كويسة، false = عادة وحشة
  int pointsValue; // النقط اللي بتتكسب/بتتخسر
  List<String> completedDates; // تواريخ (yyyy-MM-dd) اتعملت/اتكسرت فيها العادة
  String? aiAnalysis; // آخر تحليل AI لتأثير العادة
  DateTime createdAt;
  bool isMonsterOfMonth; // هل دي "وحش الشهر" اللي بنحاول نتخلص منه

  Habit({
    String? id,
    required this.name,
    required this.isGood,
    this.pointsValue = 10,
    List<String>? completedDates,
    this.aiAnalysis,
    DateTime? createdAt,
    this.isMonsterOfMonth = false,
  })  : id = id ?? newId(),
        completedDates = completedDates ?? [],
        createdAt = createdAt ?? DateTime.now();

  bool get doneToday => completedDates.contains(todayKey());

  int get currentStreak {
    int streak = 0;
    DateTime d = DateTime.now();
    while (completedDates.contains(todayKey(d))) {
      streak++;
      d = d.subtract(const Duration(days: 1));
    }
    return streak;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'isGood': isGood,
        'pointsValue': pointsValue,
        'completedDates': completedDates,
        'aiAnalysis': aiAnalysis,
        'createdAt': createdAt.toIso8601String(),
        'isMonsterOfMonth': isMonsterOfMonth,
      };

  factory Habit.fromJson(Map<String, dynamic> j) => Habit(
        id: j['id'],
        name: j['name'],
        isGood: j['isGood'],
        pointsValue: j['pointsValue'] ?? 10,
        completedDates: List<String>.from(j['completedDates'] ?? []),
        aiAnalysis: j['aiAnalysis'],
        createdAt: DateTime.tryParse(j['createdAt'] ?? '') ?? DateTime.now(),
        isMonsterOfMonth: j['isMonsterOfMonth'] ?? false,
      );
}

/// خطوة من خطوات تحقيق حلم
class DreamStep {
  String id;
  String text;
  bool isDone;

  DreamStep({String? id, required this.text, this.isDone = false})
      : id = id ?? newId();

  Map<String, dynamic> toJson() => {'id': id, 'text': text, 'isDone': isDone};
  factory DreamStep.fromJson(Map<String, dynamic> j) =>
      DreamStep(id: j['id'], text: j['text'], isDone: j['isDone'] ?? false);
}

/// حلم مستقبلي بخطوات لتحقيقه
class Dream {
  String id;
  String title;
  String description;
  List<DreamStep> steps;
  DateTime createdAt;

  Dream({
    String? id,
    required this.title,
    this.description = '',
    List<DreamStep>? steps,
    DateTime? createdAt,
  })  : id = id ?? newId(),
        steps = steps ?? [],
        createdAt = createdAt ?? DateTime.now();

  double get progress {
    if (steps.isEmpty) return 0;
    final done = steps.where((s) => s.isDone).length;
    return done / steps.length;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'steps': steps.map((s) => s.toJson()).toList(),
        'createdAt': createdAt.toIso8601String(),
      };

  factory Dream.fromJson(Map<String, dynamic> j) => Dream(
        id: j['id'],
        title: j['title'],
        description: j['description'] ?? '',
        steps: (j['steps'] as List? ?? [])
            .map((e) => DreamStep.fromJson(e))
            .toList(),
        createdAt: DateTime.tryParse(j['createdAt'] ?? '') ?? DateTime.now(),
      );
}

/// مهمة أسبوعية
class WeeklyTask {
  String id;
  String title;
  bool isDone;
  String weekKey; // مثلا 2026-W32

  WeeklyTask({
    String? id,
    required this.title,
    this.isDone = false,
    required this.weekKey,
  }) : id = id ?? newId();

  Map<String, dynamic> toJson() =>
      {'id': id, 'title': title, 'isDone': isDone, 'weekKey': weekKey};
  factory WeeklyTask.fromJson(Map<String, dynamic> j) => WeeklyTask(
        id: j['id'],
        title: j['title'],
        isDone: j['isDone'] ?? false,
        weekKey: j['weekKey'] ?? '',
      );
}

/// اشتراك شهري (نتفليكس وغيره)
class Subscription {
  String id;
  String name;
  double price;
  int billingDay;

  Subscription({
    String? id,
    required this.name,
    required this.price,
    this.billingDay = 1,
  }) : id = id ?? newId();

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'price': price, 'billingDay': billingDay};
  factory Subscription.fromJson(Map<String, dynamic> j) => Subscription(
        id: j['id'],
        name: j['name'],
        price: (j['price'] ?? 0).toDouble(),
        billingDay: j['billingDay'] ?? 1,
      );
}

/// تسجيل يومي بسيط (نوم / وزن / وقت سوشيال ميديا)
class DailyLog {
  String date; // yyyy-MM-dd
  double value;

  DailyLog({required this.date, required this.value});

  Map<String, dynamic> toJson() => {'date': date, 'value': value};
  factory DailyLog.fromJson(Map<String, dynamic> j) =>
      DailyLog(date: j['date'], value: (j['value'] ?? 0).toDouble());
}

/// بيانات المستخدم الشخصية + النقط + القلوب
class UserProfile {
  String name; int? age; double? heightCm; double? weightKg; List<String> hobbies; List<String> goals; String? jobType;
  String geminiApiKey; String geminiModel; String grokApiKey; String grokModel; String aiProvider;
  int totalPoints; int hearts; String lastHeartsResetDate; String monsterMonthKey; String themeMode; String accentTheme; String language;
  double sleepTargetHours; String wakeTime; String sleepTime; int weeklyMeetingWeekday; int weeklyMeetingHour; int weeklyMeetingMinute; bool hasOnboarded;
  UserProfile({this.name='',this.age,this.heightCm,this.weightKg,List<String>? hobbies,List<String>? goals,this.jobType,this.geminiApiKey='',this.geminiModel='gemini-3.6-flash',this.grokApiKey='',this.grokModel='grok-4.5',this.aiProvider='gemini',this.totalPoints=0,this.hearts=3,String? lastHeartsResetDate,this.monsterMonthKey='',this.themeMode='system',this.accentTheme='purple',this.language='egyptian',this.sleepTargetHours=8,this.wakeTime='08:00',this.sleepTime='00:00',this.weeklyMeetingWeekday=7,this.weeklyMeetingHour=18,this.weeklyMeetingMinute=0,this.hasOnboarded=false}) : hobbies=hobbies??[], goals=goals??[], lastHeartsResetDate=lastHeartsResetDate??todayKey();
  Map<String,dynamic> toJson()=>{'name':name,'age':age,'heightCm':heightCm,'weightKg':weightKg,'hobbies':hobbies,'goals':goals,'jobType':jobType,'geminiApiKey':geminiApiKey,'geminiModel':geminiModel,'grokApiKey':grokApiKey,'grokModel':grokModel,'aiProvider':aiProvider,'totalPoints':totalPoints,'hearts':hearts,'lastHeartsResetDate':lastHeartsResetDate,'monsterMonthKey':monsterMonthKey,'themeMode':themeMode,'accentTheme':accentTheme,'language':language,'sleepTargetHours':sleepTargetHours,'wakeTime':wakeTime,'sleepTime':sleepTime,'weeklyMeetingWeekday':weeklyMeetingWeekday,'weeklyMeetingHour':weeklyMeetingHour,'weeklyMeetingMinute':weeklyMeetingMinute,'hasOnboarded':hasOnboarded};
  factory UserProfile.fromJson(Map<String,dynamic> j)=>UserProfile(name:j['name']??'',age:(j['age'] as num?)?.toInt(),heightCm:(j['heightCm'] as num?)?.toDouble(),weightKg:(j['weightKg'] as num?)?.toDouble(),hobbies:List<String>.from(j['hobbies']??[]),goals:List<String>.from(j['goals']??[]),jobType:j['jobType'],geminiApiKey:j['geminiApiKey']??'',geminiModel:j['geminiModel']??'gemini-3.6-flash',grokApiKey:j['grokApiKey']??'',grokModel:j['grokModel']??'grok-4.5',aiProvider:j['aiProvider']??'gemini',totalPoints:j['totalPoints']??0,hearts:j['hearts']??3,lastHeartsResetDate:j['lastHeartsResetDate']??todayKey(),monsterMonthKey:j['monsterMonthKey']??'',themeMode:j['themeMode']??'system',accentTheme:j['accentTheme']??'purple',language:j['language']??'egyptian',sleepTargetHours:(j['sleepTargetHours']??8).toDouble(),wakeTime:j['wakeTime']??'08:00',sleepTime:j['sleepTime']??'00:00',weeklyMeetingWeekday:j['weeklyMeetingWeekday']??7,weeklyMeetingHour:j['weeklyMeetingHour']??18,weeklyMeetingMinute:j['weeklyMeetingMinute']??0,hasOnboarded:j['hasOnboarded']??false);
}
class DailyTask { String id,title,date; bool isDone; DailyTask({String? id,required this.title,required this.date,this.isDone=false}):id=id??newId(); Map<String,dynamic> toJson()=>{'id':id,'title':title,'date':date,'isDone':isDone}; factory DailyTask.fromJson(Map<String,dynamic> j)=>DailyTask(id:j['id'],title:j['title'],date:j['date'],isDone:j['isDone']??false); }
class ChatMessage { String role,text,createdAt; ChatMessage({required this.role,required this.text,String? createdAt}):createdAt=createdAt??DateTime.now().toIso8601String(); Map<String,dynamic> toJson()=>{'role':role,'text':text,'createdAt':createdAt}; factory ChatMessage.fromJson(Map<String,dynamic> j)=>ChatMessage(role:j['role']??'assistant',text:j['text']??'',createdAt:j['createdAt']); }
